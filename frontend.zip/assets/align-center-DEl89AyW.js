import{ao as t}from"./createLucideIcon-B8e-Mjz2.js";import"./chunk-EF7DTUVF-DLseTd5d.js";import"./grid-YQL9s_RY.js";import"./index-DFKkHzjq.js";/**
 * @license lucide-react v0.536.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const e=[["path",{d:"M17 12H7",key:"16if0g"}],["path",{d:"M19 18H5",key:"18s9l3"}],["path",{d:"M21 6H3",key:"1jwq7v"}]],n=t("align-center",e);export{e as __iconNode,n as default};
