import{ao as t}from"./createLucideIcon-B8e-Mjz2.js";import"./chunk-EF7DTUVF-DLseTd5d.js";import"./grid-YQL9s_RY.js";import"./index-DFKkHzjq.js";/**
 * @license lucide-react v0.536.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const e=[["path",{d:"M11 13H7",key:"t0o9gq"}],["path",{d:"M19 9h-4",key:"rera1j"}],["path",{d:"M3 3v16a2 2 0 0 0 2 2h16",key:"c24i48"}],["rect",{x:"15",y:"5",width:"4",height:"12",rx:"1",key:"q8uenq"}],["rect",{x:"7",y:"8",width:"4",height:"9",rx:"1",key:"sr5ea"}]],h=t("chart-column-stacked",e);export{e as __iconNode,h as default};
