

import { Fragment, useCallback, useContext, useEffect } from "react"
import { Box as RadixThemesBox, Button as RadixThemesButton, DropdownMenu as RadixThemesDropdownMenu, Flex as RadixThemesFlex, Progress as RadixThemesProgress, Slider as RadixThemesSlider, Text as RadixThemesText, TextArea as RadixThemesTextArea } from "@radix-ui/themes"
import { ColorModeContext, EventLoopContext, StateContexts } from "$/utils/context"
import { Event, isTrue } from "$/utils/state"
import DebounceInput from "react-debounce-input"
import { Helmet } from "react-helmet"
import { PrismAsyncLight as SyntaxHighlighter } from "react-syntax-highlighter"
import oneLight from "react-syntax-highlighter/dist/esm/styles/prism/one-light"
import oneDark from "react-syntax-highlighter/dist/esm/styles/prism/one-dark"
import { CircleHelp as LucideCircleHelp, Copy as LucideCopy, Download as LucideDownload, FileText as LucideFileText, Moon as LucideMoon, Play as LucidePlay, Settings as LucideSettings, Shuffle as LucideShuffle, Sparkles as LucideSparkles, Trash2 as LucideTrash2 } from "lucide-react"
import { DynamicIcon } from "lucide-react/dynamic.mjs"
import { jsx } from "@emotion/react"



function Fragment_107416381212993544032926986299069403397 () {
  
  const reflex___state____state__codechronos___components___breakout____breakout_state = useContext(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state)





  
  return (
    jsx(
Fragment,
{},
(((reflex___state____state__codechronos___components___breakout____breakout_state.auto_play_rx_state_ && reflex___state____state__codechronos___components___breakout____breakout_state.game_started_rx_state_) && !(reflex___state____state__codechronos___components___breakout____breakout_state.game_over_rx_state_)) ? (jsx(
Fragment,
{},
jsx(
RadixThemesBox,
{},
jsx(
Helmet,
{},
jsx(
"script",
{},
"\n                    setTimeout(function autoMove() {\n                        const moveButton = document.querySelector('[data-auto-move=\"true\"]');\n                        if (moveButton && moveButton.getAttribute('data-auto-play') === 'true') {\n                            moveButton.click();\n                            setTimeout(autoMove, 120); // Faster auto-play for bigger game\n                        }\n                    }, 120);\n                "
,),),jsx(Button_91664619310617359172968069625577518725,{},)
,),)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{},)
,))),)
  )
}

function Box_271755373098322324216306063844931598920 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_93b4deabba26af9115e11fef106ca384 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___breakout____breakout_state.hit_brick", ({ ["row"] : ({ ["button"] : _e["button"], ["buttons"] : _e["buttons"], ["client_x"] : _e["clientX"], ["client_y"] : _e["clientY"], ["alt_key"] : _e["altKey"], ["ctrl_key"] : _e["ctrlKey"], ["meta_key"] : _e["metaKey"], ["shift_key"] : _e["shiftKey"] }), ["col"] : 6 }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesBox,{css:({ ["width"] : "32px", ["height"] : "10px", ["background"] : "red", ["border"] : "1px solid white", ["cursor"] : "pointer" }),onClick:on_click_93b4deabba26af9115e11fef106ca384},)

  )
}

function Button_298689411568171815659606739028014288598 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_8fb0c56960463d4ea8e8225f738a5529 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___calculator____calculator_state.perform_operation", ({ ["next_operation"] : "+" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"orange",css:({ ["width"] : "60px", ["height"] : "60px", ["fontSize"] : "18px", ["fontFamily"] : "'Press Start 2P', monospace", ["--default-font-family"] : "'Press Start 2P', monospace" }),onClick:on_click_8fb0c56960463d4ea8e8225f738a5529,variant:"solid"},
"+"
,)
  )
}

function Fragment_145036749985981784651067557916830165890 () {
  
  const reflex___state____state__codechronos___components___breakout____breakout_state = useContext(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state)





  
  return (
    jsx(
Fragment,
{},
(reflex___state____state__codechronos___components___breakout____breakout_state.bricks_rx_state_.at(4).at(5) ? (jsx(
Fragment,
{},
jsx(Box_250473458978652614230870930250126683750,{},)
,)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{css:({ ["width"] : "35px", ["height"] : "10px" })},)
,))),)
  )
}

function Button_142115491237993380672031523260113740788 () {
  
  const reflex___state____state__codechronos___pages___vibecode____vibe_code_state = useContext(StateContexts.reflex___state____state__codechronos___pages___vibecode____vibe_code_state)
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_d25867d3191e2369c6f68c1bf6536d1a = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___pages___vibecode____vibe_code_state.set_ai_mode", ({ ["mode"] : "creative" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"purple",onClick:on_click_d25867d3191e2369c6f68c1bf6536d1a,size:"2",variant:((reflex___state____state__codechronos___pages___vibecode____vibe_code_state.ai_mode_rx_state_ === "creative") ? "soft" : "outline")},
"Creative"
,)
  )
}

function Box_330836859350024342471613422018380684832 () {
  
  const reflex___state____state__codechronos___components___breakout____breakout_state = useContext(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state)





  
  return (
    jsx(RadixThemesBox,{css:({ ["width"] : (reflex___state____state__codechronos___components___breakout____breakout_state.scaled_paddle_width_rx_state_+"px"), ["height"] : "8px", ["background"] : "white", ["position"] : "absolute", ["left"] : (reflex___state____state__codechronos___components___breakout____breakout_state.scaled_paddle_x_rx_state_+"px"), ["bottom"] : "20px", ["borderRadius"] : "2px" })},)

  )
}

function Text_17318465457492298815093796480195511501 () {
  
  const reflex___state____state__codechronos___pages___maccode____mac_code_state = useContext(StateContexts.reflex___state____state__codechronos___pages___maccode____mac_code_state)





  
  return (
    jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "12px", ["fontFamily"] : "'Press Start 2P', monospace", ["--default-font-family"] : "'Press Start 2P', monospace" })},
reflex___state____state__codechronos___pages___maccode____mac_code_state.current_time_rx_state_
,)
  )
}

function Button_59229357557296991053461269747165348543 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_209a3999d2087952aa37dfa97dddbc1c = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___calculator____calculator_state.perform_operation", ({ ["next_operation"] : "\u00d7" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"orange",css:({ ["width"] : "60px", ["height"] : "60px", ["fontSize"] : "18px", ["fontFamily"] : "'Press Start 2P', monospace", ["--default-font-family"] : "'Press Start 2P', monospace" }),onClick:on_click_209a3999d2087952aa37dfa97dddbc1c,variant:"solid"},
"\u00d7"
,)
  )
}

function Button_194567053326286791963899705503038379468 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_d5fcbf28aed642c39d245ae222d68eda = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___block_editor____block_editor_state.add_block", ({ ["block_type"] : "variable" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"green",css:({ ["background"] : "linear-gradient(45deg, #86EFAC, #4ADE80)", ["width"] : "120px" }),onClick:on_click_d5fcbf28aed642c39d245ae222d68eda},
"Variable"
,)
  )
}

function Fragment_244331760395190688046633131083593021775 () {
  
  const reflex___state____state__codechronos___components___breakout____breakout_state = useContext(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state)





  
  return (
    jsx(
Fragment,
{},
((!(reflex___state____state__codechronos___components___breakout____breakout_state.game_started_rx_state_) || reflex___state____state__codechronos___components___breakout____breakout_state.game_over_rx_state_) ? (jsx(
Fragment,
{},
jsx(Button_190446632744058997684187653363284335327,{},)
,)) : (jsx(
Fragment,
{},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"row",justify:"center",gap:"2"},
jsx(Button_290228358543734617405933977780323460514,{},)
,jsx(Button_265991197706029796606441258349342569510,{},)
,jsx(Button_200952239129220142680489236568300753775,{},)
,jsx(Button_321769091228358055937094733606874742740,{},)
,jsx(Button_150347914621290424289420586770849170418,{},)
,),))),)
  )
}

function Button_24491614469354119162511037219534901725 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_1e65417a673fd7adabae9044b92ea776 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___block_editor____block_editor_state.add_block", ({ ["block_type"] : "button" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"teal",css:({ ["background"] : "linear-gradient(45deg, #5EEAD4, #2DD4BF)", ["width"] : "120px" }),onClick:on_click_1e65417a673fd7adabae9044b92ea776},
"Button"
,)
  )
}

function Fragment_175590100040126101152932648127185991941 () {
  
  const reflex___state____state__codechronos___components___breakout____breakout_state = useContext(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state)





  
  return (
    jsx(
Fragment,
{},
(reflex___state____state__codechronos___components___breakout____breakout_state.bricks_rx_state_.at(1).at(2) ? (jsx(
Fragment,
{},
jsx(Box_137670690589222838856595203964645135146,{},)
,)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{css:({ ["width"] : "35px", ["height"] : "10px" })},)
,))),)
  )
}

function Fragment_203137895771630311957416667094039498967 () {
  
  const reflex___state____state__codechronos___components___breakout____breakout_state = useContext(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state)





  
  return (
    jsx(
Fragment,
{},
(reflex___state____state__codechronos___components___breakout____breakout_state.bricks_rx_state_.at(1).at(7) ? (jsx(
Fragment,
{},
jsx(Box_153186666532713597889689732847495049536,{},)
,)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{css:({ ["width"] : "35px", ["height"] : "10px" })},)
,))),)
  )
}

function Box_49321650982420396319675627088166443787 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_2e8bf688ff707f7e3a95435b7cc09a88 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___breakout____breakout_state.hit_brick", ({ ["row"] : ({ ["button"] : _e["button"], ["buttons"] : _e["buttons"], ["client_x"] : _e["clientX"], ["client_y"] : _e["clientY"], ["alt_key"] : _e["altKey"], ["ctrl_key"] : _e["ctrlKey"], ["meta_key"] : _e["metaKey"], ["shift_key"] : _e["shiftKey"] }), ["col"] : 3 }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesBox,{css:({ ["width"] : "32px", ["height"] : "10px", ["background"] : "red", ["border"] : "1px solid white", ["cursor"] : "pointer" }),onClick:on_click_2e8bf688ff707f7e3a95435b7cc09a88},)

  )
}

function Button_45378555400811391669105951096463337328 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_4ba92e3f6e376f10999dcdb1f4df41fb = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___calculator____calculator_state.input_digit", ({ ["digit"] : "4" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"gray",css:({ ["width"] : "60px", ["height"] : "60px", ["fontSize"] : "18px", ["fontFamily"] : "'Press Start 2P', monospace", ["--default-font-family"] : "'Press Start 2P', monospace" }),onClick:on_click_4ba92e3f6e376f10999dcdb1f4df41fb,variant:"solid"},
"4"
,)
  )
}

function Box_202327090064938500444632565552729142166 () {
  
  const reflex___state____state__codechronos___pages___home____home_state = useContext(StateContexts.reflex___state____state__codechronos___pages___home____home_state)





  
  return (
    jsx(RadixThemesBox,{css:({ ["width"] : "12px", ["height"] : "12px", ["borderRadius"] : "50%", ["background"] : ((reflex___state____state__codechronos___pages___home____home_state.boot_stage_rx_state_ >= 4) ? "#4ade80" : "#e5e7eb"), ["margin"] : "0 4px" })},)

  )
}

function Fragment_228141112458958928862034454185481556319 () {
  
  const reflex___state____state__codechronos___components___breakout____breakout_state = useContext(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state)





  
  return (
    jsx(
Fragment,
{},
(reflex___state____state__codechronos___components___breakout____breakout_state.bricks_rx_state_.at(1).at(6) ? (jsx(
Fragment,
{},
jsx(Box_76461757847212700994728583712960391843,{},)
,)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{css:({ ["width"] : "35px", ["height"] : "10px" })},)
,))),)
  )
}

function Box_15846118189069645654395443470850442858 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_744dbe7bd8a48de3d9a58c939e20307b = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___breakout____breakout_state.hit_brick", ({ ["row"] : ({ ["button"] : _e["button"], ["buttons"] : _e["buttons"], ["client_x"] : _e["clientX"], ["client_y"] : _e["clientY"], ["alt_key"] : _e["altKey"], ["ctrl_key"] : _e["ctrlKey"], ["meta_key"] : _e["metaKey"], ["shift_key"] : _e["shiftKey"] }), ["col"] : 4 }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesBox,{css:({ ["width"] : "32px", ["height"] : "10px", ["background"] : "blue", ["border"] : "1px solid white", ["cursor"] : "pointer" }),onClick:on_click_744dbe7bd8a48de3d9a58c939e20307b},)

  )
}

function Box_92164052058234701248659395207824117291 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_ff64f56b161807cdba4276a094786f7a = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___breakout____breakout_state.hit_brick", ({ ["row"] : ({ ["button"] : _e["button"], ["buttons"] : _e["buttons"], ["client_x"] : _e["clientX"], ["client_y"] : _e["clientY"], ["alt_key"] : _e["altKey"], ["ctrl_key"] : _e["ctrlKey"], ["meta_key"] : _e["metaKey"], ["shift_key"] : _e["shiftKey"] }), ["col"] : 2 }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesBox,{css:({ ["width"] : "32px", ["height"] : "10px", ["background"] : "red", ["border"] : "1px solid white", ["cursor"] : "pointer" }),onClick:on_click_ff64f56b161807cdba4276a094786f7a},)

  )
}

function Box_330341592596168624822101997789013760841 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_93b4deabba26af9115e11fef106ca384 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___breakout____breakout_state.hit_brick", ({ ["row"] : ({ ["button"] : _e["button"], ["buttons"] : _e["buttons"], ["client_x"] : _e["clientX"], ["client_y"] : _e["clientY"], ["alt_key"] : _e["altKey"], ["ctrl_key"] : _e["ctrlKey"], ["meta_key"] : _e["metaKey"], ["shift_key"] : _e["shiftKey"] }), ["col"] : 6 }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesBox,{css:({ ["width"] : "32px", ["height"] : "10px", ["background"] : "blue", ["border"] : "1px solid white", ["cursor"] : "pointer" }),onClick:on_click_93b4deabba26af9115e11fef106ca384},)

  )
}

function Flex_296659786278355488451140423243399174933 () {
  
  const reflex___state____state__codechronos___pages___blockcode____block_code_state = useContext(StateContexts.reflex___state____state__codechronos___pages___blockcode____block_code_state)





  
  return (
    jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["width"] : "100%" }),direction:"column",gap:"1"},
reflex___state____state__codechronos___pages___blockcode____block_code_state.saved_projects_rx_state_.map((project_rx_state_,index_542d4cf9cff027c4)=>(jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["&:hover"] : ({ ["background"] : "#f3f4f6" }), ["width"] : "100%", ["padding"] : "0.5rem", ["borderRadius"] : "6px" }),direction:"row",key:index_542d4cf9cff027c4,gap:"3"},
jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "16px" })},
"\ud83d\udcc1"
,),jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "14px" })},
project_rx_state_
,),jsx(RadixThemesFlex,{css:({ ["flex"] : 1, ["justifySelf"] : "stretch", ["alignSelf"] : "stretch" })},)
,jsx(
RadixThemesButton,
{size:"1",variant:"ghost"},
"Load"
,),))),)
  )
}

function Box_227703894152580005284030535514100030749 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_2e8bf688ff707f7e3a95435b7cc09a88 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___breakout____breakout_state.hit_brick", ({ ["row"] : ({ ["button"] : _e["button"], ["buttons"] : _e["buttons"], ["client_x"] : _e["clientX"], ["client_y"] : _e["clientY"], ["alt_key"] : _e["altKey"], ["ctrl_key"] : _e["ctrlKey"], ["meta_key"] : _e["metaKey"], ["shift_key"] : _e["shiftKey"] }), ["col"] : 3 }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesBox,{css:({ ["width"] : "32px", ["height"] : "10px", ["background"] : "orange", ["border"] : "1px solid white", ["cursor"] : "pointer" }),onClick:on_click_2e8bf688ff707f7e3a95435b7cc09a88},)

  )
}

function Fragment_77948588433464054912189938212274897940 () {
  
  const reflex___state____state__codechronos___components___breakout____breakout_state = useContext(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state)





  
  return (
    jsx(
Fragment,
{},
(reflex___state____state__codechronos___components___breakout____breakout_state.bricks_rx_state_.at(0).at(0) ? (jsx(
Fragment,
{},
jsx(Box_110906838594077264925931370970077868636,{},)
,)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{css:({ ["width"] : "35px", ["height"] : "10px" })},)
,))),)
  )
}

function Button_327477273375628708267864272299376041086 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_e0c1dfa489236b70e30843398d4aac1b = useCallback(((_e) => (addEvents([(Event("_redirect", ({ ["path"] : "/vibecode", ["external"] : false, ["replace"] : false }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"purple",css:({ ["marginTop"] : "1rem" }),onClick:on_click_e0c1dfa489236b70e30843398d4aac1b,size:"3"},
"Enter 2025"
,)
  )
}

function Button_15639044930373040832261154066130265087 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_ee1ccdcd93b14b1e742232b408f50bf7 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___calculator____calculator_state.perform_operation", ({ ["next_operation"] : "" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"orange",css:({ ["width"] : "60px", ["height"] : "60px", ["fontSize"] : "18px", ["fontFamily"] : "'Press Start 2P', monospace", ["--default-font-family"] : "'Press Start 2P', monospace" }),onClick:on_click_ee1ccdcd93b14b1e742232b408f50bf7,variant:"solid"},
"="
,)
  )
}

function Dropdownmenu__item_65423782002938546488162407450771898675 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_72b29f9bcab4efc8ac3efc575e3ebed9 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___notepad____notepad_state.new_file", ({  }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesDropdownMenu.Item,
{onClick:on_click_72b29f9bcab4efc8ac3efc575e3ebed9},
"New"
,)
  )
}

function Box_162425234561815824708044268781489656343 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_2e8bf688ff707f7e3a95435b7cc09a88 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___breakout____breakout_state.hit_brick", ({ ["row"] : ({ ["button"] : _e["button"], ["buttons"] : _e["buttons"], ["client_x"] : _e["clientX"], ["client_y"] : _e["clientY"], ["alt_key"] : _e["altKey"], ["ctrl_key"] : _e["ctrlKey"], ["meta_key"] : _e["metaKey"], ["shift_key"] : _e["shiftKey"] }), ["col"] : 3 }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesBox,{css:({ ["width"] : "32px", ["height"] : "10px", ["background"] : "green", ["border"] : "1px solid white", ["cursor"] : "pointer" }),onClick:on_click_2e8bf688ff707f7e3a95435b7cc09a88},)

  )
}

function Button_10963579034772078003108102700277173357 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_4ff3475c34f6e3600c8a2e5bf69fcf6b = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___block_editor____block_editor_state.add_block", ({ ["block_type"] : "slider" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"pink",css:({ ["background"] : "linear-gradient(45deg, #F9A8D4, #EC4899)", ["width"] : "120px" }),onClick:on_click_4ff3475c34f6e3600c8a2e5bf69fcf6b},
"Slider"
,)
  )
}

function Box_51862575769477078468271210557758139272 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_8d23cc0139ac5591548fb9cef1d1466d = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___breakout____breakout_state.hit_brick", ({ ["row"] : ({ ["button"] : _e["button"], ["buttons"] : _e["buttons"], ["client_x"] : _e["clientX"], ["client_y"] : _e["clientY"], ["alt_key"] : _e["altKey"], ["ctrl_key"] : _e["ctrlKey"], ["meta_key"] : _e["metaKey"], ["shift_key"] : _e["shiftKey"] }), ["col"] : 7 }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesBox,{css:({ ["width"] : "32px", ["height"] : "10px", ["background"] : "blue", ["border"] : "1px solid white", ["cursor"] : "pointer" }),onClick:on_click_8d23cc0139ac5591548fb9cef1d1466d},)

  )
}

function Dropdownmenu__item_234667224340087336626630737971996976654 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_cf4f88fd326d3d620849fcba2a8b8e6c = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___notepad____notepad_state.change_font_size", ({ ["size"] : 12 }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesDropdownMenu.Item,
{onClick:on_click_cf4f88fd326d3d620849fcba2a8b8e6c},
"Font Size 12"
,)
  )
}

function Fragment_67815087002477998303590497307249083175 () {
  
  const reflex___state____state__codechronos___components___breakout____breakout_state = useContext(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state)





  
  return (
    jsx(
Fragment,
{},
(reflex___state____state__codechronos___components___breakout____breakout_state.bricks_rx_state_.at(3).at(0) ? (jsx(
Fragment,
{},
jsx(Box_15574553660387982587710182216981296690,{},)
,)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{css:({ ["width"] : "35px", ["height"] : "10px" })},)
,))),)
  )
}

function Box_300868416019252206017803967801989547754 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_ff64f56b161807cdba4276a094786f7a = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___breakout____breakout_state.hit_brick", ({ ["row"] : ({ ["button"] : _e["button"], ["buttons"] : _e["buttons"], ["client_x"] : _e["clientX"], ["client_y"] : _e["clientY"], ["alt_key"] : _e["altKey"], ["ctrl_key"] : _e["ctrlKey"], ["meta_key"] : _e["metaKey"], ["shift_key"] : _e["shiftKey"] }), ["col"] : 2 }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesBox,{css:({ ["width"] : "32px", ["height"] : "10px", ["background"] : "green", ["border"] : "1px solid white", ["cursor"] : "pointer" }),onClick:on_click_ff64f56b161807cdba4276a094786f7a},)

  )
}

function Fragment_137726666656477169414202711157332512708 () {
  
  const reflex___state____state__codechronos___components___breakout____breakout_state = useContext(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state)





  
  return (
    jsx(
Fragment,
{},
(reflex___state____state__codechronos___components___breakout____breakout_state.bricks_rx_state_.at(0).at(6) ? (jsx(
Fragment,
{},
jsx(Box_271755373098322324216306063844931598920,{},)
,)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{css:({ ["width"] : "35px", ["height"] : "10px" })},)
,))),)
  )
}

function Button_140678343358233532601229815492277362548 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_b91eb22d73e5fe5b05139d45dacac330 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___pages___maccode____mac_code_state.open_notepad", ({  }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{css:({ ["whiteSpace"] : "pre-line", ["textAlign"] : "center", ["&:hover"] : ({ ["background"] : "rgba(0,0,0,0.1)" }), ["position"] : "absolute", ["left"] : "20px", ["top"] : "140px", ["width"] : "80px", ["height"] : "60px", ["background"] : "#e0e0e0", ["border"] : "1px solid black", ["fontSize"] : "10px", ["fontFamily"] : "'Press Start 2P', monospace", ["--default-font-family"] : "'Press Start 2P', monospace", ["color"] : "black", ["cursor"] : "pointer", ["zIndex"] : "100" }),onClick:on_click_b91eb22d73e5fe5b05139d45dacac330},
"\ud83d\udcdd\nNotepad"
,)
  )
}

function Fragment_252761261593685100367128669135228531778 () {
  
  const reflex___state____state__codechronos___codechronos____state = useContext(StateContexts.reflex___state____state__codechronos___codechronos____state)





  
  return (
    jsx(
Fragment,
{},
((reflex___state____state__codechronos___codechronos____state.current_era_rx_state_ === "2015") ? (jsx(
Fragment,
{},
jsx(
RadixThemesBox,
{css:({ ["width"] : "100vw", ["height"] : "100vh", ["background"] : "#ffffff", ["fontFamily"] : "system-ui, -apple-system, sans-serif", ["--default-font-family"] : "system-ui, -apple-system, sans-serif" })},
jsx(Fragment_287278809950046042776360904378504354677,{},)
,jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"column",gap:"0"},
jsx(
RadixThemesFlex,
{align:"center",className:"rx-Stack",css:({ ["width"] : "100%", ["padding"] : "1rem 2rem", ["background"] : "white", ["borderBottom"] : "2px solid #e5e7eb" }),direction:"row",gap:"3"},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"row",gap:"2"},
jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "24px" })},
"\ud83e\uddf1"
,),jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "24px", ["fontWeight"] : "bold", ["color"] : "#2563eb" })},
"BlockCode 2015"
,),),jsx(RadixThemesFlex,{css:({ ["flex"] : 1, ["justifySelf"] : "stretch", ["alignSelf"] : "stretch" })},)
,jsx(Text_336104500564292434712161161494157494909,{},)
,jsx(RadixThemesFlex,{css:({ ["flex"] : 1, ["justifySelf"] : "stretch", ["alignSelf"] : "stretch" })},)
,jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"row",gap:"2"},
jsx(Button_98629922982460100273507996140430467626,{},)
,jsx(Button_233983167859275500955157979568693967623,{},)
,jsx(
RadixThemesButton,
{color:"purple",variant:"outline"},
"Share"
,),),),jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["width"] : "100%", ["height"] : "calc(100vh - 80px)" }),direction:"row",gap:"0"},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["width"] : "250px", ["height"] : "100%", ["padding"] : "2rem", ["background"] : "#f9fafb", ["borderRight"] : "2px solid #e5e7eb" }),direction:"column",gap:"3"},
jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "16px", ["fontWeight"] : "bold", ["color"] : "#374151" })},
"Saved Projects"
,),jsx(Flex_296659786278355488451140423243399174933,{},)
,jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "16px", ["fontWeight"] : "bold", ["color"] : "#374151", ["marginTop"] : "2rem" })},
"Quick Tips"
,),jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"column",gap:"1"},
jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "12px", ["color"] : "#6b7280" })},
"\ud83d\udca1 Drag blocks to the canvas"
,),jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "12px", ["color"] : "#6b7280" })},
"\ud83d\udd17 Snap blocks together"
,),jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "12px", ["color"] : "#6b7280" })},
"\u2699\ufe0f Click blocks to edit properties"
,),jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "12px", ["color"] : "#6b7280" })},
"\ud83d\ude80 Hit Generate to see Python code"
,),),),jsx(
RadixThemesBox,
{css:({ ["width"] : "100%", ["height"] : "100%", ["padding"] : "2rem", ["background"] : "linear-gradient(135deg, #dbeafe 0%, #ede9fe 100%)" })},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["width"] : "100%", ["height"] : "100%" }),direction:"row",gap:"4"},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["padding"] : "1rem", ["background"] : "var(--gray-1)", ["borderRadius"] : "8px" }),direction:"column",gap:"2"},
jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "blue" }),size:"3",weight:"bold"},
"Logic Blocks"
,),jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"column",gap:"2"},
jsx(Button_23612681040425350852215331782780493187,{},)
,jsx(Button_68997723321721684634029274567694848608,{},)
,jsx(Button_194567053326286791963899705503038379468,{},)
,jsx(Button_43642195342283648934813609275825279546,{},)
,jsx(Button_57382104853626552149995979237980014637,{},)
,jsx(Button_162659129934545480643767067313288100843,{},)
,),jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "teal", ["marginTop"] : "1rem" }),size:"3",weight:"bold"},
"UI Blocks"
,),jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"column",gap:"2"},
jsx(Button_24491614469354119162511037219534901725,{},)
,jsx(Button_331992761637737300190594929023979493645,{},)
,jsx(Button_10963579034772078003108102700277173357,{},)
,),jsx(Button_111650463381333800680099922953843479278,{},)
,),jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["width"] : "100%" }),direction:"column",gap:"4"},
jsx(
RadixThemesBox,
{css:({ ["width"] : "100%" })},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"column",gap:"2"},
jsx(
RadixThemesText,
{as:"p",size:"4",weight:"bold"},
"Block Canvas"
,),jsx(Box_166178522484563743585171266421621039082,{},)
,),),jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["width"] : "100%" }),direction:"column",gap:"2"},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["width"] : "100%" }),direction:"row",justify:"between",gap:"3"},
jsx(
RadixThemesText,
{as:"p",size:"4",weight:"bold"},
"Generated Code"
,),jsx(Button_127728447672871185321506785230367448006,{},)
,),jsx(Prismasynclight_135743271562277648814139370464492673590,{},)
,),),),),),),),)) : (jsx(
Fragment,
{},
jsx(
RadixThemesBox,
{css:({ ["width"] : "100vw", ["height"] : "100vh", ["background"] : "linear-gradient(135deg, #0f0f23 0%, #1a1a2e 50%, #16213e 100%)", ["color"] : "white", ["overflowX"] : "hidden" })},
jsx("div",{className:"rx-Html",dangerouslySetInnerHTML:({ ["__html"] : "\n            <style>\n                @keyframes float {\n                    0%, 100% { transform: translateY(0px) rotate(0deg); }\n                    33% { transform: translateY(-20px) rotate(5deg); }\n                    66% { transform: translateY(10px) rotate(-3deg); }\n                }\n                @keyframes pulse {\n                    0%, 100% { opacity: 1; }\n                    50% { opacity: 0.5; }\n                }\n            </style>\n            " })},)
,jsx(
RadixThemesBox,
{css:({ ["position"] : "fixed", ["top"] : "0", ["left"] : "0", ["width"] : "100%", ["height"] : "100%", ["pointerEvents"] : "none", ["zIndex"] : "-1" })},
jsx(RadixThemesBox,{css:({ ["animation"] : "float 6s ease-in-out infinite", ["width"] : "300px", ["height"] : "300px", ["borderRadius"] : "50%", ["background"] : "radial-gradient(circle, rgba(139, 92, 246, 0.3), transparent)", ["position"] : "absolute", ["top"] : "-150px", ["right"] : "-150px" })},)
,jsx(RadixThemesBox,{css:({ ["animation"] : "float 8s ease-in-out infinite reverse", ["width"] : "200px", ["height"] : "200px", ["borderRadius"] : "50%", ["background"] : "radial-gradient(circle, rgba(236, 72, 153, 0.2), transparent)", ["position"] : "absolute", ["bottom"] : "-100px", ["left"] : "-100px" })},)
,),jsx(Fragment_74836867271179415488921216589008355746,{},)
,),))),)
  )
}

function Text_336104500564292434712161161494157494909 () {
  
  const reflex___state____state__codechronos___pages___blockcode____block_code_state = useContext(StateContexts.reflex___state____state__codechronos___pages___blockcode____block_code_state)





  
  return (
    jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "18px", ["fontWeight"] : "bold" })},
reflex___state____state__codechronos___pages___blockcode____block_code_state.current_project_rx_state_
,)
  )
}

function Button_179567778243558684219367129922774199639 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_3d648d73d9a83ad7116736997136e047 = useCallback(((_e) => (addEvents([(Event("_redirect", ({ ["path"] : "/blockcode", ["external"] : false, ["replace"] : false }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"blue",css:({ ["marginTop"] : "1rem" }),onClick:on_click_3d648d73d9a83ad7116736997136e047,size:"3"},
"Enter 2015"
,)
  )
}

function Button_169960526187752535866448905230877626476 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_7fe0673e78038b95a07d96d32202e663 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___vibe_prompt____vibe_prompt_state.save_app", ({  }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{css:({ ["background"] : "white", ["color"] : "#059669", ["border"] : "1px solid #10B981", ["borderRadius"] : "4px", ["&:hover"] : ({ ["background"] : "#ECFDF5", ["color"] : "#047857" }) }),onClick:on_click_7fe0673e78038b95a07d96d32202e663,size:"1",variant:"outline"},
jsx(
RadixThemesFlex,
{align:"center",className:"rx-Stack",direction:"row",gap:"1"},
jsx(LucideDownload,{size:14},)
,jsx(
RadixThemesText,
{as:"p"},
"Save"
,),),)
  )
}

function Fragment_118809876959672875134132736037987938645 () {
  
  const reflex___state____state__codechronos___components___breakout____breakout_state = useContext(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state)





  
  return (
    jsx(
Fragment,
{},
(reflex___state____state__codechronos___components___breakout____breakout_state.bricks_rx_state_.at(4).at(6) ? (jsx(
Fragment,
{},
jsx(Box_330341592596168624822101997789013760841,{},)
,)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{css:({ ["width"] : "35px", ["height"] : "10px" })},)
,))),)
  )
}

function Box_101942607096122092040805000995394134766 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_37918d79851e0e17215df6fb92e1e31a = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___pages___maccode____mac_code_state.close_calculator", ({  }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesBox,{css:({ ["&:hover"] : ({ ["background"] : "#ff0000" }), ["width"] : "12px", ["height"] : "12px", ["borderRadius"] : "50%", ["background"] : "white", ["border"] : "1px solid #000", ["cursor"] : "pointer" }),onClick:on_click_37918d79851e0e17215df6fb92e1e31a},)

  )
}

function Box_226047848234270498720853402156659073356 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_dd19a969b5fbcd48eecfe77c8512fbec = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___breakout____breakout_state.hit_brick", ({ ["row"] : ({ ["button"] : _e["button"], ["buttons"] : _e["buttons"], ["client_x"] : _e["clientX"], ["client_y"] : _e["clientY"], ["alt_key"] : _e["altKey"], ["ctrl_key"] : _e["ctrlKey"], ["meta_key"] : _e["metaKey"], ["shift_key"] : _e["shiftKey"] }), ["col"] : 1 }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesBox,{css:({ ["width"] : "32px", ["height"] : "10px", ["background"] : "yellow", ["border"] : "1px solid white", ["cursor"] : "pointer" }),onClick:on_click_dd19a969b5fbcd48eecfe77c8512fbec},)

  )
}

function Button_286709652083013392547229448243489173845 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_4101803ee8cd80ed3ff2a3c25d15c9a7 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___codechronos____state.set_era", ({ ["era"] : "2025" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"purple",onClick:on_click_4101803ee8cd80ed3ff2a3c25d15c9a7,variant:"ghost"},
"Vibe 2025"
,)
  )
}

function Prismasynclight_3786491886571996970191929168816844084 () {
  
  const { resolvedColorMode } = useContext(ColorModeContext)
  const reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state = useContext(StateContexts.reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state)





  
  return (
    jsx(SyntaxHighlighter,{children:reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state.generated_code_rx_state_,css:({ ["width"] : "100%", ["height"] : "400px", ["background"] : "#1F2937", ["color"] : "#F9FAFB", ["borderRadius"] : "6px", ["fontSize"] : "13px", ["overflowY"] : "auto", ["padding"] : "16px" }),language:"python",style:((resolvedColorMode === "light") ? oneLight : oneDark)},)

  )
}

function Fragment_276283994395687875034826926780972372314 () {
  
  const reflex___state____state__codechronos___components___breakout____breakout_state = useContext(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state)





  
  return (
    jsx(
Fragment,
{},
(reflex___state____state__codechronos___components___breakout____breakout_state.bricks_rx_state_.at(3).at(4) ? (jsx(
Fragment,
{},
jsx(Box_47485443008836893019508577274192202125,{},)
,)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{css:({ ["width"] : "35px", ["height"] : "10px" })},)
,))),)
  )
}

function Button_228259778961687912623471529411670528391 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_ea63b02b45742348f195458f6c32c38b = useCallback(((_e) => (addEvents([(Event("_redirect", ({ ["path"] : "/maccode", ["external"] : false, ["replace"] : false }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"gray",css:({ ["marginTop"] : "1rem" }),onClick:on_click_ea63b02b45742348f195458f6c32c38b,size:"3"},
"Enter 1984"
,)
  )
}

function Fragment_46305778192283824274905980894472919992 () {
  
  const reflex___state____state__codechronos___components___breakout____breakout_state = useContext(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state)





  
  return (
    jsx(
Fragment,
{},
(reflex___state____state__codechronos___components___breakout____breakout_state.bricks_rx_state_.at(3).at(2) ? (jsx(
Fragment,
{},
jsx(Box_300868416019252206017803967801989547754,{},)
,)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{css:({ ["width"] : "35px", ["height"] : "10px" })},)
,))),)
  )
}

function Button_118634592107776375793086319586934954331 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_1930384c0f8de0169bbd6d9481937ec1 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___pages___maccode____mac_code_state.open_calculator", ({  }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{css:({ ["whiteSpace"] : "pre-line", ["textAlign"] : "center", ["&:hover"] : ({ ["background"] : "rgba(0,0,0,0.1)" }), ["position"] : "absolute", ["left"] : "20px", ["top"] : "60px", ["width"] : "80px", ["height"] : "60px", ["background"] : "#e0e0e0", ["border"] : "1px solid black", ["fontSize"] : "10px", ["fontFamily"] : "'Press Start 2P', monospace", ["--default-font-family"] : "'Press Start 2P', monospace", ["color"] : "black", ["cursor"] : "pointer", ["zIndex"] : "100" }),onClick:on_click_1930384c0f8de0169bbd6d9481937ec1},
"\ud83d\udd22\nCalculator"
,)
  )
}

function Box_317200685045713428789918334135792956980 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_6ad6bbe1c40b639532ea58cf2e424c46 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___breakout____breakout_state.hit_brick", ({ ["row"] : ({ ["button"] : _e["button"], ["buttons"] : _e["buttons"], ["client_x"] : _e["clientX"], ["client_y"] : _e["clientY"], ["alt_key"] : _e["altKey"], ["ctrl_key"] : _e["ctrlKey"], ["meta_key"] : _e["metaKey"], ["shift_key"] : _e["shiftKey"] }), ["col"] : 0 }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesBox,{css:({ ["width"] : "32px", ["height"] : "10px", ["background"] : "yellow", ["border"] : "1px solid white", ["cursor"] : "pointer" }),onClick:on_click_6ad6bbe1c40b639532ea58cf2e424c46},)

  )
}

function Fragment_218484703962293962784680057804773844321 () {
  
  const reflex___state____state__codechronos___components___breakout____breakout_state = useContext(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state)





  
  return (
    jsx(
Fragment,
{},
(reflex___state____state__codechronos___components___breakout____breakout_state.bricks_rx_state_.at(1).at(3) ? (jsx(
Fragment,
{},
jsx(Box_227703894152580005284030535514100030749,{},)
,)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{css:({ ["width"] : "35px", ["height"] : "10px" })},)
,))),)
  )
}

function Box_109040417978279600678841949870636468721 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_6ad6bbe1c40b639532ea58cf2e424c46 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___breakout____breakout_state.hit_brick", ({ ["row"] : ({ ["button"] : _e["button"], ["buttons"] : _e["buttons"], ["client_x"] : _e["clientX"], ["client_y"] : _e["clientY"], ["alt_key"] : _e["altKey"], ["ctrl_key"] : _e["ctrlKey"], ["meta_key"] : _e["metaKey"], ["shift_key"] : _e["shiftKey"] }), ["col"] : 0 }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesBox,{css:({ ["width"] : "32px", ["height"] : "10px", ["background"] : "orange", ["border"] : "1px solid white", ["cursor"] : "pointer" }),onClick:on_click_6ad6bbe1c40b639532ea58cf2e424c46},)

  )
}

function Text_104991294914002852458661333203046641368 () {
  
  const reflex___state____state__codechronos___pages___home____home_state = useContext(StateContexts.reflex___state____state__codechronos___pages___home____home_state)





  
  return (
    jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "14px", ["color"] : "#888", ["fontFamily"] : "'VT323', monospace", ["--default-font-family"] : "'VT323', monospace", ["marginTop"] : "1rem" })},
reflex___state____state__codechronos___pages___home____home_state.boot_text_rx_state_
,)
  )
}

function Fragment_192778145599263778868441823738978686007 () {
  
  const reflex___state____state__codechronos___components___breakout____breakout_state = useContext(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state)





  
  return (
    jsx(
Fragment,
{},
(reflex___state____state__codechronos___components___breakout____breakout_state.bricks_rx_state_.at(0).at(4) ? (jsx(
Fragment,
{},
jsx(Box_215545926791433575875366456909749151199,{},)
,)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{css:({ ["width"] : "35px", ["height"] : "10px" })},)
,))),)
  )
}

function Button_288783363323070480941374419687704060907 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_a12e704040edea09274957950310eee6 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___calculator____calculator_state.input_digit", ({ ["digit"] : "3" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"gray",css:({ ["width"] : "60px", ["height"] : "60px", ["fontSize"] : "18px", ["fontFamily"] : "'Press Start 2P', monospace", ["--default-font-family"] : "'Press Start 2P', monospace" }),onClick:on_click_a12e704040edea09274957950310eee6,variant:"solid"},
"3"
,)
  )
}

function Fragment_216893019725020024042768772891642711704 () {
  
  const reflex___state____state__codechronos___pages___maccode____mac_code_state = useContext(StateContexts.reflex___state____state__codechronos___pages___maccode____mac_code_state)





  
  return (
    jsx(
Fragment,
{},
(reflex___state____state__codechronos___pages___maccode____mac_code_state.calculator_active_rx_state_ ? (jsx(
Fragment,
{},
jsx(Box_319226856812488640588694577633812056254,{},)
,)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{},)
,))),)
  )
}

function Box_233118938257345465517720633045986784182 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_2881d2a714dc91a1e41304fe16288db2 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___pages___maccode____mac_code_state.close_breakout", ({  }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesBox,{css:({ ["&:hover"] : ({ ["background"] : "#ff0000" }), ["width"] : "12px", ["height"] : "12px", ["borderRadius"] : "50%", ["background"] : "white", ["border"] : "1px solid #000", ["cursor"] : "pointer" }),onClick:on_click_2881d2a714dc91a1e41304fe16288db2},)

  )
}

function Text_20212940772138548436204551964265379043 () {
  
  const reflex___state____state__codechronos___components___breakout____breakout_state = useContext(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state)





  
  return (
    jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "white" }),size:"2",weight:"bold"},
("Score: "+reflex___state____state__codechronos___components___breakout____breakout_state.score_rx_state_)
,)
  )
}

function Fragment_320675576210565781951535527049824519903 () {
  
  const reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state = useContext(StateContexts.reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state)





  
  return (
    jsx(
Fragment,
{},
(!((reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state.generated_code_rx_state_ === "")) ? (jsx(
Fragment,
{},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"row",gap:"2"},
jsx(Button_61565878414463668330901934770804114289,{},)
,jsx(Button_169960526187752535866448905230877626476,{},)
,jsx(Button_62604915975806678539581407738687706784,{},)
,),)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{},)
,))),)
  )
}

function Fragment_258652760091787945836251939543807118080 () {
  
  const reflex___state____state__codechronos___pages___home____home_state = useContext(StateContexts.reflex___state____state__codechronos___pages___home____home_state)





  
  return (
    jsx(
Fragment,
{},
(reflex___state____state__codechronos___pages___home____home_state.show_logo_rx_state_ ? (jsx(
Fragment,
{},
jsx(
RadixThemesFlex,
{css:({ ["display"] : "flex", ["alignItems"] : "center", ["justifyContent"] : "center", ["width"] : "100vw", ["height"] : "100vh", ["background"] : "linear-gradient(135deg, #fafafa 0%, #f0f0f0 100%)" })},
jsx(
RadixThemesFlex,
{align:"center",className:"rx-Stack",direction:"column",gap:"4"},
jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "36px", ["fontWeight"] : "bold", ["marginBottom"] : "3rem", ["textAlign"] : "center" })},
"Choose Your Development Era"
,),jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"row",justify:"center",gap:"4"},
jsx(
RadixThemesBox,
{css:({ ["transition"] : "all 0.3s ease", ["&:hover"] : ({ ["transform"] : "translateY(-5px)", ["boxShadow"] : "0 10px 25px rgba(0,0,0,0.1)" }), ["padding"] : "2rem", ["border"] : "2px solid #e5e7eb", ["borderRadius"] : "12px", ["background"] : "white", ["cursor"] : "pointer" })},
jsx(
RadixThemesFlex,
{align:"center",className:"rx-Stack",direction:"column",gap:"3"},
jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "80px" })},
"\ud83d\udda5\ufe0f"
,),jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "24px", ["fontWeight"] : "bold", ["color"] : "#333" })},
"Mac 1984"
,),jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "14px", ["color"] : "#666", ["textAlign"] : "center", ["maxWidth"] : "200px" })},
"Classic Macintosh interface with pixel-perfect retro charm"
,),jsx(Button_228259778961687912623471529411670528391,{},)
,),),jsx(
RadixThemesBox,
{css:({ ["transition"] : "all 0.3s ease", ["&:hover"] : ({ ["transform"] : "translateY(-5px)", ["boxShadow"] : "0 10px 25px rgba(59, 130, 246, 0.1)" }), ["padding"] : "2rem", ["border"] : "2px solid #bfdbfe", ["borderRadius"] : "12px", ["background"] : "white", ["cursor"] : "pointer" })},
jsx(
RadixThemesFlex,
{align:"center",className:"rx-Stack",direction:"column",gap:"3"},
jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "80px" })},
"\ud83e\uddf1"
,),jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "24px", ["fontWeight"] : "bold", ["color"] : "#3b82f6" })},
"Block 2015"
,),jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "14px", ["color"] : "#666", ["textAlign"] : "center", ["maxWidth"] : "200px" })},
"Visual block-based coding with drag-and-drop simplicity"
,),jsx(Button_179567778243558684219367129922774199639,{},)
,),),jsx(
RadixThemesBox,
{css:({ ["transition"] : "all 0.3s ease", ["&:hover"] : ({ ["transform"] : "translateY(-5px)", ["boxShadow"] : "0 10px 25px rgba(139, 92, 246, 0.1)" }), ["padding"] : "2rem", ["border"] : "2px solid #ddd6fe", ["borderRadius"] : "12px", ["background"] : "white", ["cursor"] : "pointer" })},
jsx(
RadixThemesFlex,
{align:"center",className:"rx-Stack",direction:"column",gap:"3"},
jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "80px" })},
"\ud83e\uddde"
,),jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "24px", ["fontWeight"] : "bold", ["color"] : "#8b5cf6" })},
"Vibe 2025"
,),jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "14px", ["color"] : "#666", ["textAlign"] : "center", ["maxWidth"] : "200px" })},
"AI-powered natural language development environment"
,),jsx(Button_327477273375628708267864272299376041086,{},)
,),),),jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "16px", ["color"] : "#888", ["textAlign"] : "center", ["marginTop"] : "3rem" })},
"Click on any era to begin your journey through software development history"
,),),),)) : (jsx(
Fragment,
{},
jsx(Box_288308436728202464397396076818127989140,{},)
,))),)
  )
}

function Fragment_316037397833011809783302444735290160233 () {
  
  const reflex___state____state__codechronos___components___breakout____breakout_state = useContext(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state)





  
  return (
    jsx(
Fragment,
{},
(reflex___state____state__codechronos___components___breakout____breakout_state.bricks_rx_state_.at(4).at(4) ? (jsx(
Fragment,
{},
jsx(Box_15846118189069645654395443470850442858,{},)
,)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{css:({ ["width"] : "35px", ["height"] : "10px" })},)
,))),)
  )
}

function Button_92345245332958014058421525449913618262 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_ffff471acb66c62cc9832cfbc66771a5 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___calculator____calculator_state.perform_operation", ({ ["next_operation"] : "-" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"orange",css:({ ["width"] : "60px", ["height"] : "60px", ["fontSize"] : "18px", ["fontFamily"] : "'Press Start 2P', monospace", ["--default-font-family"] : "'Press Start 2P', monospace" }),onClick:on_click_ffff471acb66c62cc9832cfbc66771a5,variant:"solid"},
"-"
,)
  )
}

function Box_4955592766453191096590250986939942463 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_dd19a969b5fbcd48eecfe77c8512fbec = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___breakout____breakout_state.hit_brick", ({ ["row"] : ({ ["button"] : _e["button"], ["buttons"] : _e["buttons"], ["client_x"] : _e["clientX"], ["client_y"] : _e["clientY"], ["alt_key"] : _e["altKey"], ["ctrl_key"] : _e["ctrlKey"], ["meta_key"] : _e["metaKey"], ["shift_key"] : _e["shiftKey"] }), ["col"] : 1 }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesBox,{css:({ ["width"] : "32px", ["height"] : "10px", ["background"] : "red", ["border"] : "1px solid white", ["cursor"] : "pointer" }),onClick:on_click_dd19a969b5fbcd48eecfe77c8512fbec},)

  )
}

function Dropdownmenu__item_177971289096077839513785154832145555698 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_3340be28ec5132cbb8ec28273cbcd042 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___notepad____notepad_state.change_font_size", ({ ["size"] : 10 }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesDropdownMenu.Item,
{onClick:on_click_3340be28ec5132cbb8ec28273cbcd042},
"Font Size 10"
,)
  )
}

function Box_76461757847212700994728583712960391843 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_93b4deabba26af9115e11fef106ca384 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___breakout____breakout_state.hit_brick", ({ ["row"] : ({ ["button"] : _e["button"], ["buttons"] : _e["buttons"], ["client_x"] : _e["clientX"], ["client_y"] : _e["clientY"], ["alt_key"] : _e["altKey"], ["ctrl_key"] : _e["ctrlKey"], ["meta_key"] : _e["metaKey"], ["shift_key"] : _e["shiftKey"] }), ["col"] : 6 }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesBox,{css:({ ["width"] : "32px", ["height"] : "10px", ["background"] : "orange", ["border"] : "1px solid white", ["cursor"] : "pointer" }),onClick:on_click_93b4deabba26af9115e11fef106ca384},)

  )
}

function Box_92361042885364644860426642119449720557 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_dd19a969b5fbcd48eecfe77c8512fbec = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___breakout____breakout_state.hit_brick", ({ ["row"] : ({ ["button"] : _e["button"], ["buttons"] : _e["buttons"], ["client_x"] : _e["clientX"], ["client_y"] : _e["clientY"], ["alt_key"] : _e["altKey"], ["ctrl_key"] : _e["ctrlKey"], ["meta_key"] : _e["metaKey"], ["shift_key"] : _e["shiftKey"] }), ["col"] : 1 }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesBox,{css:({ ["width"] : "32px", ["height"] : "10px", ["background"] : "blue", ["border"] : "1px solid white", ["cursor"] : "pointer" }),onClick:on_click_dd19a969b5fbcd48eecfe77c8512fbec},)

  )
}

function Fragment_236534205998239474377680445255123969201 () {
  
  const reflex___state____state__codechronos___components___breakout____breakout_state = useContext(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state)





  
  return (
    jsx(
Fragment,
{},
(reflex___state____state__codechronos___components___breakout____breakout_state.bricks_rx_state_.at(4).at(1) ? (jsx(
Fragment,
{},
jsx(Box_92361042885364644860426642119449720557,{},)
,)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{css:({ ["width"] : "35px", ["height"] : "10px" })},)
,))),)
  )
}

function Text_155305555398420155212847909347135635247 () {
  
  const reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state = useContext(StateContexts.reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state)





  
  return (
    jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "#DC2626" }),size:"3",weight:"medium"},
reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state.error_message_rx_state_
,)
  )
}

function Box_15574553660387982587710182216981296690 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_6ad6bbe1c40b639532ea58cf2e424c46 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___breakout____breakout_state.hit_brick", ({ ["row"] : ({ ["button"] : _e["button"], ["buttons"] : _e["buttons"], ["client_x"] : _e["clientX"], ["client_y"] : _e["clientY"], ["alt_key"] : _e["altKey"], ["ctrl_key"] : _e["ctrlKey"], ["meta_key"] : _e["metaKey"], ["shift_key"] : _e["shiftKey"] }), ["col"] : 0 }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesBox,{css:({ ["width"] : "32px", ["height"] : "10px", ["background"] : "green", ["border"] : "1px solid white", ["cursor"] : "pointer" }),onClick:on_click_6ad6bbe1c40b639532ea58cf2e424c46},)

  )
}

function Fragment_192686669107232756522980869459414514258 () {
  
  const reflex___state____state__codechronos___components___breakout____breakout_state = useContext(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state)





  
  return (
    jsx(
Fragment,
{},
(reflex___state____state__codechronos___components___breakout____breakout_state.game_over_rx_state_ ? (jsx(
Fragment,
{},
jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "red", ["textAlign"] : "center" }),size:"4",weight:"bold"},
"GAME OVER!"
,),)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{},)
,))),)
  )
}

function Button_267028158748701794880603063264908585018 () {
  
  const reflex___state____state__codechronos___components___mac_draw____mac_draw_state = useContext(StateContexts.reflex___state____state__codechronos___components___mac_draw____mac_draw_state)
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_16fa2c681f0e734c39392c296355bc2d = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___mac_draw____mac_draw_state.set_tool", ({ ["tool"] : "eraser" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{onClick:on_click_16fa2c681f0e734c39392c296355bc2d,size:"2",variant:((reflex___state____state__codechronos___components___mac_draw____mac_draw_state.current_tool_rx_state_ === "eraser") ? "soft" : "outline")},
"\ud83e\uddfd"
,)
  )
}

function Fragment_23773970933067659241144580748431908249 () {
  
  const reflex___state____state__codechronos___components___breakout____breakout_state = useContext(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state)





  
  return (
    jsx(
Fragment,
{},
(reflex___state____state__codechronos___components___breakout____breakout_state.bricks_rx_state_.at(2).at(5) ? (jsx(
Fragment,
{},
jsx(Box_324640009329884850979002739358294332628,{},)
,)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{css:({ ["width"] : "35px", ["height"] : "10px" })},)
,))),)
  )
}

function Button_27294360853427492673241470178741800221 () {
  
  const reflex___state____state__codechronos___pages___vibecode____vibe_code_state = useContext(StateContexts.reflex___state____state__codechronos___pages___vibecode____vibe_code_state)
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_9f6150a87d57a6f7432636cdd73e8e01 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___pages___vibecode____vibe_code_state.set_ai_mode", ({ ["mode"] : "precise" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"blue",onClick:on_click_9f6150a87d57a6f7432636cdd73e8e01,size:"2",variant:((reflex___state____state__codechronos___pages___vibecode____vibe_code_state.ai_mode_rx_state_ === "precise") ? "soft" : "outline")},
"Precise"
,)
  )
}

function Text_147055318896876021268548607481793427286 () {
  
  const reflex___state____state__codechronos___pages___vibecode____vibe_code_state = useContext(StateContexts.reflex___state____state__codechronos___pages___vibecode____vibe_code_state)





  
  return (
    jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "12px", ["color"] : "white" })},
("AI Mode: "+reflex___state____state__codechronos___pages___vibecode____vibe_code_state.ai_mode_rx_state_.split(' ').map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()).join(' '))
,)
  )
}

function Text_155840452032406156039090957037446418219 () {
  
  const reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state = useContext(StateContexts.reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state)





  
  return (
    jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "#374151" }),size:"2",weight:"medium"},
("Creativity Level: "+(reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state.creativity_level_rx_state_.toLocaleString('en-US', ((decimals) => ({minimumFractionDigits: decimals, maximumFractionDigits: decimals}))(1)).replaceAll(',', "")))
,)
  )
}

function Fragment_13727863138921468053363826573058138817 () {
  
  const reflex___state____state__codechronos___components___breakout____breakout_state = useContext(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state)





  
  return (
    jsx(
Fragment,
{},
(reflex___state____state__codechronos___components___breakout____breakout_state.bricks_rx_state_.at(4).at(7) ? (jsx(
Fragment,
{},
jsx(Box_51862575769477078468271210557758139272,{},)
,)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{css:({ ["width"] : "35px", ["height"] : "10px" })},)
,))),)
  )
}

function Fragment_287278809950046042776360904378504354677 () {
  
  const reflex___state____state__codechronos___pages___blockcode____block_code_state = useContext(StateContexts.reflex___state____state__codechronos___pages___blockcode____block_code_state)





  
  return (
    jsx(
Fragment,
{},
(reflex___state____state__codechronos___pages___blockcode____block_code_state.show_tutorial_rx_state_ ? (jsx(
Fragment,
{},
jsx(
RadixThemesBox,
{css:({ ["position"] : "fixed", ["top"] : "0", ["left"] : "0", ["width"] : "100vw", ["height"] : "100vh", ["background"] : "rgba(0,0,0,0.5)", ["zIndex"] : "9999" })},
jsx(
RadixThemesFlex,
{css:({ ["display"] : "flex", ["alignItems"] : "center", ["justifyContent"] : "center" })},
jsx(
RadixThemesBox,
{css:({ ["padding"] : "3rem", ["background"] : "white", ["borderRadius"] : "16px", ["border"] : "2px solid #e5e7eb", ["maxWidth"] : "500px", ["boxShadow"] : "0 20px 50px rgba(0,0,0,0.1)" })},
jsx(
RadixThemesFlex,
{align:"center",className:"rx-Stack",direction:"column",gap:"4"},
jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "28px", ["fontWeight"] : "bold", ["color"] : "#2563eb" })},
"Welcome to BlockCode!"
,),jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "16px", ["color"] : "#6b7280", ["textAlign"] : "center" })},
"Drag blocks from the palette to create your app visually"
,),jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"column",gap:"1"},
jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "14px" })},
"\ud83d\udccb Logic blocks: Control your app's behavior"
,),jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "14px" })},
"\ud83c\udfa8 UI blocks: Add buttons, inputs, and visual elements"
,),jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "14px" })},
"\ud83d\udd27 Connect blocks to build complex functionality"
,),jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "14px" })},
"\u26a1 Generate Python code instantly"
,),),jsx(Button_219477215464531189701437850733598902531,{},)
,),),),),)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{},)
,))),)
  )
}

function Button_13637973564106607324454656450357763492 () {
  
  const reflex___state____state__codechronos___components___mac_draw____mac_draw_state = useContext(StateContexts.reflex___state____state__codechronos___components___mac_draw____mac_draw_state)
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_ee73c300103b54c9d78f81bc1be1a0bc = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___mac_draw____mac_draw_state.set_color", ({ ["color"] : "#FFFFFF" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesButton,{css:({ ["width"] : "30px", ["height"] : "30px", ["backgroundColor"] : "#FFFFFF", ["border"] : ((reflex___state____state__codechronos___components___mac_draw____mac_draw_state.current_color_rx_state_ === "#FFFFFF") ? "2px solid #000" : "1px solid #ccc"), ["borderRadius"] : "4px" }),onClick:on_click_ee73c300103b54c9d78f81bc1be1a0bc},)

  )
}

function Button_265162515216161551365773855433709036699 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_f243c6a7ce77c251da5627a56425df48 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___calculator____calculator_state.input_digit", ({ ["digit"] : "0" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{css:({ ["width"] : "128px", ["height"] : "60px", ["fontSize"] : "18px", ["fontFamily"] : "'Press Start 2P', monospace", ["--default-font-family"] : "'Press Start 2P', monospace" }),onClick:on_click_f243c6a7ce77c251da5627a56425df48},
"0"
,)
  )
}

function Fragment_6084906993062426141309500910249554920 () {
  
  const reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state = useContext(StateContexts.reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state)





  
  return (
    jsx(
Fragment,
{},
(!((reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state.error_message_rx_state_ === "")) ? (jsx(
Fragment,
{},
jsx(
RadixThemesBox,
{css:({ ["background"] : "#FEF2F2", ["border"] : "1px solid #FCA5A5", ["borderRadius"] : "6px", ["padding"] : "12px 16px", ["width"] : "100%" })},
jsx(
RadixThemesFlex,
{align:"center",className:"rx-Stack",direction:"row",gap:"2"},
jsx(LucideCircleHelp,{css:({ ["color"] : "#DC2626" }),size:16},)
,jsx(Text_155305555398420155212847909347135635247,{},)
,),),)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{},)
,))),)
  )
}

function Button_268462628480918768805754824071657830915 () {
  
  const reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state = useContext(StateContexts.reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state)
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_b4da950997a8c93e4a2677b1356c677d = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___vibe_prompt____vibe_prompt_state.generate_code", ({  }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{css:({ ["background"] : "#3B82F6", ["color"] : "white", ["border"] : "none", ["borderRadius"] : "6px", ["boxShadow"] : "0 1px 3px rgba(0, 0, 0, 0.1)", ["&:hover"] : ({ ["background"] : "#2563EB", ["transform"] : "translateY(-1px)", ["boxShadow"] : "0 4px 6px rgba(0, 0, 0, 0.1)" }) }),loading:reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state.is_generating_rx_state_,onClick:on_click_b4da950997a8c93e4a2677b1356c677d,size:"3"},
jsx(
RadixThemesFlex,
{align:"center",className:"rx-Stack",direction:"row",gap:"2"},
jsx(LucideSparkles,{size:16},)
,jsx(
RadixThemesText,
{as:"p"},
"Generate Code"
,),),)
  )
}

function Button_43642195342283648934813609275825279546 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_adc5bd54e24101b958af5c571d0c2cd4 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___block_editor____block_editor_state.add_block", ({ ["block_type"] : "if" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"orange",css:({ ["background"] : "linear-gradient(45deg, #FCD34D, #F59E0B)", ["width"] : "120px" }),onClick:on_click_adc5bd54e24101b958af5c571d0c2cd4},
"If Statement"
,)
  )
}

function Fragment_272215153482607427745640696308614787130 () {
  
  const reflex___state____state__codechronos___components___breakout____breakout_state = useContext(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state)





  
  return (
    jsx(
Fragment,
{},
(reflex___state____state__codechronos___components___breakout____breakout_state.bricks_rx_state_.at(2).at(0) ? (jsx(
Fragment,
{},
jsx(Box_317200685045713428789918334135792956980,{},)
,)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{css:({ ["width"] : "35px", ["height"] : "10px" })},)
,))),)
  )
}

function Box_249060059608287955488031555719857623513 () {
  
  const reflex___state____state__codechronos___pages___maccode____mac_code_state = useContext(StateContexts.reflex___state____state__codechronos___pages___maccode____mac_code_state)





  
  return (
    jsx(
RadixThemesBox,
{css:({ ["position"] : "absolute", ["left"] : (reflex___state____state__codechronos___pages___maccode____mac_code_state.draw_x_rx_state_+"px"), ["top"] : (reflex___state____state__codechronos___pages___maccode____mac_code_state.draw_y_rx_state_+"px"), ["width"] : "500px", ["height"] : "400px", ["background"] : "white", ["border"] : "2px solid black", ["boxShadow"] : "4px 4px 0px rgba(0,0,0,0.5)", ["zIndex"] : "100", ["fontFamily"] : "'Press Start 2P', monospace", ["--default-font-family"] : "'Press Start 2P', monospace" })},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"column",gap:"0"},
jsx(
RadixThemesFlex,
{align:"center",className:"rx-Stack",css:({ ["width"] : "100%", ["height"] : "20px", ["background"] : "white", ["borderBottom"] : "2px solid black", ["cursor"] : "move" }),direction:"row",gap:"3"},
jsx(
RadixThemesBox,
{css:({ ["padding"] : "4px" })},
jsx(Box_174144715613526904058507941398936262945,{},)
,),jsx(
RadixThemesFlex,
{css:({ ["display"] : "flex", ["alignItems"] : "center", ["justifyContent"] : "center", ["flex"] : "1" })},
jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "12px", ["fontFamily"] : "'Press Start 2P', monospace", ["--default-font-family"] : "'Press Start 2P', monospace", ["color"] : "black", ["fontWeight"] : "bold" })},
"MacDraw"
,),),jsx(RadixThemesBox,{css:({ ["width"] : "20px" })},)
,),jsx(
RadixThemesBox,
{css:({ ["background"] : "white", ["padding"] : "8px", ["flex"] : "1", ["overflow"] : "auto", ["borderLeft"] : "2px solid black", ["borderRight"] : "2px solid black", ["borderBottom"] : "2px solid black" })},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["width"] : "100%", ["height"] : "100vh", ["padding"] : "4" }),direction:"column",gap:"4"},
jsx(
RadixThemesFlex,
{align:"center",className:"rx-Stack",css:({ ["width"] : "100%" }),direction:"row",gap:"3"},
jsx(
RadixThemesText,
{as:"p",size:"6",weight:"bold"},
"\ud83c\udfa8 Mac Draw"
,),jsx(RadixThemesFlex,{css:({ ["flex"] : 1, ["justifySelf"] : "stretch", ["alignSelf"] : "stretch" })},)
,jsx("div",{className:"rx-Html",dangerouslySetInnerHTML:({ ["__html"] : "\n                <button \n                    onclick=\"window.clearDrawingCanvas && window.clearDrawingCanvas()\"\n                    style=\"\n                        background: #ff4757; \n                        color: white; \n                        border: 1px solid #ff4757; \n                        border-radius: 4px; \n                        padding: 8px 16px; \n                        cursor: pointer;\n                        font-size: 14px;\n                    \"\n                    onmouseover=\"this.style.background='#ff3838'\"\n                    onmouseout=\"this.style.background='#ff4757'\"\n                >\n                    Clear\n                </button>\n                " })},)
,),jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["width"] : "100%" }),direction:"row",gap:"4"},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["width"] : "200px" }),direction:"column",gap:"4"},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"column",gap:"3"},
jsx(
RadixThemesText,
{as:"p",size:"2",weight:"bold"},
"Tools"
,),jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"row",gap:"2"},
jsx(Button_4409934446465006597177086598433217050,{},)
,jsx(Button_69703613737895074624907044888339820470,{},)
,jsx(Button_267028158748701794880603063264908585018,{},)
,jsx(Button_304276182871344592155298457011793429588,{},)
,jsx(Button_177032496769180091329769789787296088508,{},)
,jsx(Button_147559384792091665662814661388975884408,{},)
,),),jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"column",gap:"3"},
jsx(
RadixThemesText,
{as:"p",size:"2",weight:"bold"},
"Colors"
,),jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"row",gap:"1"},
jsx(Button_136898173205459723246531189379051990621,{},)
,jsx(Button_339884565044009369626444165801804472419,{},)
,jsx(Button_225421362983180022699662441784484987187,{},)
,jsx(Button_28642652200977619605574490436127779426,{},)
,jsx(Button_58961600070984775562488133810713569409,{},)
,jsx(Button_322859359242133389302035751355682211158,{},)
,jsx(Button_187071023319145816600356791799902838416,{},)
,jsx(Button_13637973564106607324454656450357763492,{},)
,),),jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"column",gap:"3"},
jsx(
RadixThemesText,
{as:"p",size:"2",weight:"bold"},
"Brush Size"
,),jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"row",gap:"2"},
jsx(Button_187806098466758131624818057004489577517,{},)
,jsx(Button_200017083046967465390026447344790879205,{},)
,jsx(Button_152030526463307261235458215390865463663,{},)
,),),),jsx(
RadixThemesBox,
{css:({ ["padding"] : "0" })},
jsx(
RadixThemesBox,
{css:({ ["padding"] : "4" })},
jsx(Div_45867332521292778874654643840192164547,{},)
,),),),),),),)
  )
}

function Box_20845049294691042169526252293017110355 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_93b4deabba26af9115e11fef106ca384 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___breakout____breakout_state.hit_brick", ({ ["row"] : ({ ["button"] : _e["button"], ["buttons"] : _e["buttons"], ["client_x"] : _e["clientX"], ["client_y"] : _e["clientY"], ["alt_key"] : _e["altKey"], ["ctrl_key"] : _e["ctrlKey"], ["meta_key"] : _e["metaKey"], ["shift_key"] : _e["shiftKey"] }), ["col"] : 6 }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesBox,{css:({ ["width"] : "32px", ["height"] : "10px", ["background"] : "green", ["border"] : "1px solid white", ["cursor"] : "pointer" }),onClick:on_click_93b4deabba26af9115e11fef106ca384},)

  )
}

function Button_91664619310617359172968069625577518725 () {
  
  const reflex___state____state__codechronos___components___breakout____breakout_state = useContext(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state)
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_63ce232b1a80890261b481e489dd2e87 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___breakout____breakout_state.update_ball", ({  }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{css:({ ["display"] : "none" }),"data-auto-move":"true","data-auto-play":(reflex___state____state__codechronos___components___breakout____breakout_state.auto_play_rx_state_ ? "true" : "false"),onClick:on_click_63ce232b1a80890261b481e489dd2e87},
""
,)
  )
}

function Box_161416118734409037069883407628595975886 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_8d23cc0139ac5591548fb9cef1d1466d = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___breakout____breakout_state.hit_brick", ({ ["row"] : ({ ["button"] : _e["button"], ["buttons"] : _e["buttons"], ["client_x"] : _e["clientX"], ["client_y"] : _e["clientY"], ["alt_key"] : _e["altKey"], ["ctrl_key"] : _e["ctrlKey"], ["meta_key"] : _e["metaKey"], ["shift_key"] : _e["shiftKey"] }), ["col"] : 7 }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesBox,{css:({ ["width"] : "32px", ["height"] : "10px", ["background"] : "green", ["border"] : "1px solid white", ["cursor"] : "pointer" }),onClick:on_click_8d23cc0139ac5591548fb9cef1d1466d},)

  )
}

function Fragment_166235628600003538161692847565536207620 () {
  
  const reflex___state____state__codechronos___components___breakout____breakout_state = useContext(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state)





  
  return (
    jsx(
Fragment,
{},
(reflex___state____state__codechronos___components___breakout____breakout_state.bricks_rx_state_.at(2).at(1) ? (jsx(
Fragment,
{},
jsx(Box_226047848234270498720853402156659073356,{},)
,)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{css:({ ["width"] : "35px", ["height"] : "10px" })},)
,))),)
  )
}

function Box_287485116332981456434708193420262811263 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_8509dd3c6d795ced285ddd28c3605d93 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___pages___maccode____mac_code_state.close_notepad", ({  }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesBox,{css:({ ["&:hover"] : ({ ["background"] : "#ff0000" }), ["width"] : "12px", ["height"] : "12px", ["borderRadius"] : "50%", ["background"] : "white", ["border"] : "1px solid #000", ["cursor"] : "pointer" }),onClick:on_click_8509dd3c6d795ced285ddd28c3605d93},)

  )
}

function Button_328858919555321605300699636894030750948 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_d3c17e155023ae3b13317c8762b3355c = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___calculator____calculator_state.input_digit", ({ ["digit"] : "5" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"gray",css:({ ["width"] : "60px", ["height"] : "60px", ["fontSize"] : "18px", ["fontFamily"] : "'Press Start 2P', monospace", ["--default-font-family"] : "'Press Start 2P', monospace" }),onClick:on_click_d3c17e155023ae3b13317c8762b3355c,variant:"solid"},
"5"
,)
  )
}

function Slider_194305994201668015122821498069422753548 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_change_198335683d4a040f42bf5eff5b8e07ee = useCallback(((_ev_0) => (addEvents([(Event("reflex___state____state.codechronos___components___vibe_prompt____vibe_prompt_state.set_creativity", ({ ["level"] : _ev_0 }), ({  })))], [_ev_0], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesSlider,{color:"blue",css:({ ["width"] : "180px" }),defaultValue:[0.7],max:1.0,min:0.1,onValueChange:on_change_198335683d4a040f42bf5eff5b8e07ee,step:0.1,width:"100%"},)

  )
}

function Dropdownmenu__item_24807577297668632938975327001831867599 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_53fd009ae86499e1e40650375381340a = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___notepad____notepad_state.save_file", ({  }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesDropdownMenu.Item,
{onClick:on_click_53fd009ae86499e1e40650375381340a},
"Save"
,)
  )
}

function Button_200952239129220142680489236568300753775 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);
  const reflex___state____state__codechronos___components___breakout____breakout_state = useContext(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state)


  const on_click_9f82e4272c8186f368fdbbd01a48b903 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___breakout____breakout_state.toggle_auto_play", ({  }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{css:({ ["background"] : "purple", ["color"] : "white" }),onClick:on_click_9f82e4272c8186f368fdbbd01a48b903,size:"2"},
(reflex___state____state__codechronos___components___breakout____breakout_state.auto_play_rx_state_ ? "\u23f8\ufe0f Pause" : "\u25b6\ufe0f Auto")
,)
  )
}

function Button_57382104853626552149995979237980014637 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_0a46be607d676e893bf3d8264c0edda4 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___block_editor____block_editor_state.add_block", ({ ["block_type"] : "for" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"purple",css:({ ["background"] : "linear-gradient(45deg, #C4B5FD, #A78BFA)", ["width"] : "120px" }),onClick:on_click_0a46be607d676e893bf3d8264c0edda4},
"For Loop"
,)
  )
}

function Text_232863582385191682495055488491616956571 () {
  
  const reflex___state____state__codechronos___components___breakout____breakout_state = useContext(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state)





  
  return (
    jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "white" }),size:"2",weight:"bold"},
("Lives: "+reflex___state____state__codechronos___components___breakout____breakout_state.lives_rx_state_)
,)
  )
}

function Fragment_48938834792703583323087291822827874643 () {
  
  const reflex___state____state__codechronos___components___breakout____breakout_state = useContext(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state)





  
  return (
    jsx(
Fragment,
{},
(reflex___state____state__codechronos___components___breakout____breakout_state.bricks_rx_state_.at(0).at(2) ? (jsx(
Fragment,
{},
jsx(Box_92164052058234701248659395207824117291,{},)
,)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{css:({ ["width"] : "35px", ["height"] : "10px" })},)
,))),)
  )
}

function Button_284729633373950453481426732557301522693 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_3186d2456526bcaf29a4ab3c2e07d0a7 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___codechronos____state.set_era", ({ ["era"] : "1984" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"gray",onClick:on_click_3186d2456526bcaf29a4ab3c2e07d0a7,variant:"ghost"},
"Mac 1984"
,)
  )
}

function Button_150347914621290424289420586770849170418 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_2c2e23d0cfed28b0aa49b27a8465d7ac = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___breakout____breakout_state.reset_game", ({  }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{css:({ ["background"] : "red", ["color"] : "white" }),onClick:on_click_2c2e23d0cfed28b0aa49b27a8465d7ac,size:"2"},
"Reset"
,)
  )
}

function Box_271144729248443462166549955814074207807 () {
  
  const reflex___state____state__codechronos___pages___maccode____mac_code_state = useContext(StateContexts.reflex___state____state__codechronos___pages___maccode____mac_code_state)





  
  return (
    jsx(
RadixThemesBox,
{css:({ ["position"] : "absolute", ["left"] : (reflex___state____state__codechronos___pages___maccode____mac_code_state.breakout_x_rx_state_+"px"), ["top"] : (reflex___state____state__codechronos___pages___maccode____mac_code_state.breakout_y_rx_state_+"px"), ["width"] : "400px", ["height"] : "450px", ["background"] : "white", ["border"] : "2px solid black", ["boxShadow"] : "4px 4px 0px rgba(0,0,0,0.5)", ["zIndex"] : "100", ["fontFamily"] : "'Press Start 2P', monospace", ["--default-font-family"] : "'Press Start 2P', monospace" })},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"column",gap:"0"},
jsx(
RadixThemesFlex,
{align:"center",className:"rx-Stack",css:({ ["width"] : "100%", ["height"] : "20px", ["background"] : "white", ["borderBottom"] : "2px solid black", ["cursor"] : "move" }),direction:"row",gap:"3"},
jsx(
RadixThemesBox,
{css:({ ["padding"] : "4px" })},
jsx(Box_233118938257345465517720633045986784182,{},)
,),jsx(
RadixThemesFlex,
{css:({ ["display"] : "flex", ["alignItems"] : "center", ["justifyContent"] : "center", ["flex"] : "1" })},
jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "12px", ["fontFamily"] : "'Press Start 2P', monospace", ["--default-font-family"] : "'Press Start 2P', monospace", ["color"] : "black", ["fontWeight"] : "bold" })},
"Breakout"
,),),jsx(RadixThemesBox,{css:({ ["width"] : "20px" })},)
,),jsx(
RadixThemesBox,
{css:({ ["background"] : "white", ["padding"] : "8px", ["flex"] : "1", ["overflow"] : "auto", ["borderLeft"] : "2px solid black", ["borderRight"] : "2px solid black", ["borderBottom"] : "2px solid black" })},
jsx(
RadixThemesFlex,
{align:"center",className:"rx-Stack",css:({ ["width"] : "100%", ["background"] : "black", ["color"] : "white", ["padding"] : "15px", ["borderRadius"] : "6px", ["maxHeight"] : "400px", ["overflow"] : "auto" }),direction:"column",gap:"3"},
jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "white", ["textAlign"] : "center" }),size:"4",weight:"bold"},
"BREAKOUT"
,),jsx(Fragment_33996330752306292114630491178845683356,{},)
,jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["width"] : "100%", ["padding"] : "0.8rem" }),direction:"row",justify:"between",gap:"3"},
jsx(Text_20212940772138548436204551964265379043,{},)
,jsx(Text_232863582385191682495055488491616956571,{},)
,jsx(Text_184031271800512482560667063629844626607,{},)
,),jsx(
RadixThemesBox,
{css:({ ["padding"] : "0.5rem" })},
jsx(
RadixThemesBox,
{css:({ ["position"] : "relative", ["width"] : "300px", ["height"] : "280px", ["background"] : "black", ["border"] : "2px solid white", ["margin"] : "0 auto" })},
jsx(
RadixThemesFlex,
{align:"center",className:"rx-Stack",direction:"column",gap:"1"},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"row",gap:"1"},
jsx(Fragment_77948588433464054912189938212274897940,{},)
,jsx(Fragment_42577652417556630896518931670475519636,{},)
,jsx(Fragment_48938834792703583323087291822827874643,{},)
,jsx(Fragment_253306338635615835704678411883117103455,{},)
,jsx(Fragment_192778145599263778868441823738978686007,{},)
,jsx(Fragment_277690871413548401504688877088895496433,{},)
,jsx(Fragment_137726666656477169414202711157332512708,{},)
,jsx(Fragment_8516734253161781439080054876448376413,{},)
,),jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"row",gap:"1"},
jsx(Fragment_282672268217843342903918133569191279563,{},)
,jsx(Fragment_27852205857776662234574648439195337576,{},)
,jsx(Fragment_175590100040126101152932648127185991941,{},)
,jsx(Fragment_218484703962293962784680057804773844321,{},)
,jsx(Fragment_112608084174350505895512391119508087369,{},)
,jsx(Fragment_152748523179056663540353986780056951898,{},)
,jsx(Fragment_228141112458958928862034454185481556319,{},)
,jsx(Fragment_203137895771630311957416667094039498967,{},)
,),jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"row",gap:"1"},
jsx(Fragment_272215153482607427745640696308614787130,{},)
,jsx(Fragment_166235628600003538161692847565536207620,{},)
,jsx(Fragment_162505939924202435219984937205089076434,{},)
,jsx(Fragment_198427796183499817000961534048272084920,{},)
,jsx(Fragment_63970630645396086346681513352013804056,{},)
,jsx(Fragment_23773970933067659241144580748431908249,{},)
,jsx(Fragment_250783482210679390544650544108332610860,{},)
,jsx(Fragment_236417408858819033898106930763653220341,{},)
,),jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"row",gap:"1"},
jsx(Fragment_67815087002477998303590497307249083175,{},)
,jsx(Fragment_9764215023285451793789204154294631619,{},)
,jsx(Fragment_46305778192283824274905980894472919992,{},)
,jsx(Fragment_62473005136825822559877832267705410692,{},)
,jsx(Fragment_276283994395687875034826926780972372314,{},)
,jsx(Fragment_37802070233232334938758968696984510704,{},)
,jsx(Fragment_289681848012773864421692141239309944715,{},)
,jsx(Fragment_113910408577836712550783423518941473547,{},)
,),jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"row",gap:"1"},
jsx(Fragment_123085366300739496052920227982946586803,{},)
,jsx(Fragment_236534205998239474377680445255123969201,{},)
,jsx(Fragment_278812249736650107731656478598282381446,{},)
,jsx(Fragment_263671431515168201232262390608600183772,{},)
,jsx(Fragment_316037397833011809783302444735290160233,{},)
,jsx(Fragment_145036749985981784651067557916830165890,{},)
,jsx(Fragment_118809876959672875134132736037987938645,{},)
,jsx(Fragment_13727863138921468053363826573058138817,{},)
,),),jsx(Box_174490190476095276549511234839832916350,{},)
,jsx(Box_330836859350024342471613422018380684832,{},)
,),),jsx(Fragment_244331760395190688046633131083593021775,{},)
,jsx(Fragment_107416381212993544032926986299069403397,{},)
,jsx(Fragment_192686669107232756522980869459414514258,{},)
,jsx(Fragment_268687576570940587049696880791060020806,{},)
,),),),)
  )
}

function Box_315922681925402381369863825438003986199 () {
  
  const reflex___state____state__codechronos___pages___home____home_state = useContext(StateContexts.reflex___state____state__codechronos___pages___home____home_state)





  
  return (
    jsx(RadixThemesBox,{css:({ ["width"] : "12px", ["height"] : "12px", ["borderRadius"] : "50%", ["background"] : ((reflex___state____state__codechronos___pages___home____home_state.boot_stage_rx_state_ >= 2) ? "#4ade80" : "#e5e7eb"), ["margin"] : "0 4px" })},)

  )
}

function Box_240547534704827253937718717201604013315 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_744dbe7bd8a48de3d9a58c939e20307b = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___breakout____breakout_state.hit_brick", ({ ["row"] : ({ ["button"] : _e["button"], ["buttons"] : _e["buttons"], ["client_x"] : _e["clientX"], ["client_y"] : _e["clientY"], ["alt_key"] : _e["altKey"], ["ctrl_key"] : _e["ctrlKey"], ["meta_key"] : _e["metaKey"], ["shift_key"] : _e["shiftKey"] }), ["col"] : 4 }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesBox,{css:({ ["width"] : "32px", ["height"] : "10px", ["background"] : "yellow", ["border"] : "1px solid white", ["cursor"] : "pointer" }),onClick:on_click_744dbe7bd8a48de3d9a58c939e20307b},)

  )
}

function Fragment_62473005136825822559877832267705410692 () {
  
  const reflex___state____state__codechronos___components___breakout____breakout_state = useContext(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state)





  
  return (
    jsx(
Fragment,
{},
(reflex___state____state__codechronos___components___breakout____breakout_state.bricks_rx_state_.at(3).at(3) ? (jsx(
Fragment,
{},
jsx(Box_162425234561815824708044268781489656343,{},)
,)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{css:({ ["width"] : "35px", ["height"] : "10px" })},)
,))),)
  )
}

function Button_111650463381333800680099922953843479278 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_fc4ad1b8464648d1565a5f75389c13b7 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___block_editor____block_editor_state.clear_canvas", ({  }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"gray",css:({ ["width"] : "120px", ["marginTop"] : "1rem" }),onClick:on_click_fc4ad1b8464648d1565a5f75389c13b7},
"Clear All"
,)
  )
}

function Box_191146898370878537226945140211145528883 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_ec4c15f99627e541a3ea58435637d66f = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___breakout____breakout_state.hit_brick", ({ ["row"] : ({ ["button"] : _e["button"], ["buttons"] : _e["buttons"], ["client_x"] : _e["clientX"], ["client_y"] : _e["clientY"], ["alt_key"] : _e["altKey"], ["ctrl_key"] : _e["ctrlKey"], ["meta_key"] : _e["metaKey"], ["shift_key"] : _e["shiftKey"] }), ["col"] : 5 }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesBox,{css:({ ["width"] : "32px", ["height"] : "10px", ["background"] : "orange", ["border"] : "1px solid white", ["cursor"] : "pointer" }),onClick:on_click_ec4c15f99627e541a3ea58435637d66f},)

  )
}

function Box_52708232070688556335441278140582202416 () {
  
  const reflex___state____state__codechronos___pages___home____home_state = useContext(StateContexts.reflex___state____state__codechronos___pages___home____home_state)





  
  return (
    jsx(RadixThemesBox,{css:({ ["width"] : "12px", ["height"] : "12px", ["borderRadius"] : "50%", ["background"] : ((reflex___state____state__codechronos___pages___home____home_state.boot_stage_rx_state_ >= 3) ? "#4ade80" : "#e5e7eb"), ["margin"] : "0 4px" })},)

  )
}

function Box_8068448579730643481747333586644373613 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_6ad6bbe1c40b639532ea58cf2e424c46 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___breakout____breakout_state.hit_brick", ({ ["row"] : ({ ["button"] : _e["button"], ["buttons"] : _e["buttons"], ["client_x"] : _e["clientX"], ["client_y"] : _e["clientY"], ["alt_key"] : _e["altKey"], ["ctrl_key"] : _e["ctrlKey"], ["meta_key"] : _e["metaKey"], ["shift_key"] : _e["shiftKey"] }), ["col"] : 0 }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesBox,{css:({ ["width"] : "32px", ["height"] : "10px", ["background"] : "blue", ["border"] : "1px solid white", ["cursor"] : "pointer" }),onClick:on_click_6ad6bbe1c40b639532ea58cf2e424c46},)

  )
}

function Button_177032496769180091329769789787296088508 () {
  
  const reflex___state____state__codechronos___components___mac_draw____mac_draw_state = useContext(StateContexts.reflex___state____state__codechronos___components___mac_draw____mac_draw_state)
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_5cfd1ae2141f70f62d1ee809a862a14b = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___mac_draw____mac_draw_state.set_tool", ({ ["tool"] : "rectangle" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{onClick:on_click_5cfd1ae2141f70f62d1ee809a862a14b,size:"2",variant:((reflex___state____state__codechronos___components___mac_draw____mac_draw_state.current_tool_rx_state_ === "rectangle") ? "soft" : "outline")},
"\u2b1b"
,)
  )
}

function Box_319226856812488640588694577633812056254 () {
  
  const reflex___state____state__codechronos___pages___maccode____mac_code_state = useContext(StateContexts.reflex___state____state__codechronos___pages___maccode____mac_code_state)





  
  return (
    jsx(
RadixThemesBox,
{css:({ ["position"] : "absolute", ["left"] : (reflex___state____state__codechronos___pages___maccode____mac_code_state.calculator_x_rx_state_+"px"), ["top"] : (reflex___state____state__codechronos___pages___maccode____mac_code_state.calculator_y_rx_state_+"px"), ["width"] : "280px", ["height"] : "320px", ["background"] : "white", ["border"] : "2px solid black", ["boxShadow"] : "4px 4px 0px rgba(0,0,0,0.5)", ["zIndex"] : "100", ["fontFamily"] : "'Press Start 2P', monospace", ["--default-font-family"] : "'Press Start 2P', monospace" })},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"column",gap:"0"},
jsx(
RadixThemesFlex,
{align:"center",className:"rx-Stack",css:({ ["width"] : "100%", ["height"] : "20px", ["background"] : "white", ["borderBottom"] : "2px solid black", ["cursor"] : "move" }),direction:"row",gap:"3"},
jsx(
RadixThemesBox,
{css:({ ["padding"] : "4px" })},
jsx(Box_101942607096122092040805000995394134766,{},)
,),jsx(
RadixThemesFlex,
{css:({ ["display"] : "flex", ["alignItems"] : "center", ["justifyContent"] : "center", ["flex"] : "1" })},
jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "12px", ["fontFamily"] : "'Press Start 2P', monospace", ["--default-font-family"] : "'Press Start 2P', monospace", ["color"] : "black", ["fontWeight"] : "bold" })},
"Calculator"
,),),jsx(RadixThemesBox,{css:({ ["width"] : "20px" })},)
,),jsx(
RadixThemesBox,
{css:({ ["background"] : "white", ["padding"] : "8px", ["flex"] : "1", ["overflow"] : "auto", ["borderLeft"] : "2px solid black", ["borderRight"] : "2px solid black", ["borderBottom"] : "2px solid black" })},
jsx(
RadixThemesFlex,
{align:"center",className:"rx-Stack",css:({ ["background"] : "var(--gray-2)", ["padding"] : "1rem", ["borderRadius"] : "8px", ["border"] : "2px solid #666" }),direction:"column",gap:"3"},
jsx(
RadixThemesBox,
{css:({ ["width"] : "100%", ["height"] : "80px", ["padding"] : "1rem", ["background"] : "black", ["color"] : "green", ["border"] : "2px inset #ccc", ["display"] : "flex", ["alignItems"] : "center", ["justifyContent"] : "flex-end" })},
jsx(Text_136697104082559828191253802781580637780,{},)
,),jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"column",gap:"2"},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"row",gap:"2"},
jsx(Button_82265441122061854264205453094918011035,{},)
,jsx(Button_237333068476222730787902042546348026471,{},)
,jsx(Button_68566950975981241014315045772062989494,{},)
,jsx(Button_188459941934885783935720267776432129326,{},)
,),jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"row",gap:"2"},
jsx(Button_284469961482846588817559723203376471363,{},)
,jsx(Button_107217309655825590004603843493939337339,{},)
,jsx(Button_5665159417027852826706284467618377190,{},)
,jsx(Button_59229357557296991053461269747165348543,{},)
,),jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"row",gap:"2"},
jsx(Button_45378555400811391669105951096463337328,{},)
,jsx(Button_328858919555321605300699636894030750948,{},)
,jsx(Button_63581866115272136292725355406440780215,{},)
,jsx(Button_92345245332958014058421525449913618262,{},)
,),jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"row",gap:"2"},
jsx(Button_48403181683860370722143243672719633209,{},)
,jsx(Button_300548138931974488521259774216755688599,{},)
,jsx(Button_288783363323070480941374419687704060907,{},)
,jsx(Button_298689411568171815659606739028014288598,{},)
,),jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"row",gap:"2"},
jsx(Button_265162515216161551365773855433709036699,{},)
,jsx(Button_122927138047196492895609613664274714542,{},)
,jsx(Button_15639044930373040832261154066130265087,{},)
,),),),),),)
  )
}

function Box_208308913324891126156716731934490466688 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_93b4deabba26af9115e11fef106ca384 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___breakout____breakout_state.hit_brick", ({ ["row"] : ({ ["button"] : _e["button"], ["buttons"] : _e["buttons"], ["client_x"] : _e["clientX"], ["client_y"] : _e["clientY"], ["alt_key"] : _e["altKey"], ["ctrl_key"] : _e["ctrlKey"], ["meta_key"] : _e["metaKey"], ["shift_key"] : _e["shiftKey"] }), ["col"] : 6 }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesBox,{css:({ ["width"] : "32px", ["height"] : "10px", ["background"] : "yellow", ["border"] : "1px solid white", ["cursor"] : "pointer" }),onClick:on_click_93b4deabba26af9115e11fef106ca384},)

  )
}

function Fragment_268687576570940587049696880791060020806 () {
  
  const reflex___state____state__codechronos___components___breakout____breakout_state = useContext(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state)





  
  return (
    jsx(
Fragment,
{},
((reflex___state____state__codechronos___components___breakout____breakout_state.bricks_left_rx_state_ === 0) ? (jsx(
Fragment,
{},
jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "green", ["textAlign"] : "center" }),size:"4",weight:"bold"},
"LEVEL COMPLETE!"
,),)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{},)
,))),)
  )
}

function Box_324640009329884850979002739358294332628 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_ec4c15f99627e541a3ea58435637d66f = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___breakout____breakout_state.hit_brick", ({ ["row"] : ({ ["button"] : _e["button"], ["buttons"] : _e["buttons"], ["client_x"] : _e["clientX"], ["client_y"] : _e["clientY"], ["alt_key"] : _e["altKey"], ["ctrl_key"] : _e["ctrlKey"], ["meta_key"] : _e["metaKey"], ["shift_key"] : _e["shiftKey"] }), ["col"] : 5 }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesBox,{css:({ ["width"] : "32px", ["height"] : "10px", ["background"] : "yellow", ["border"] : "1px solid white", ["cursor"] : "pointer" }),onClick:on_click_ec4c15f99627e541a3ea58435637d66f},)

  )
}

function Box_175695069005499027011147030272202927436 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_2e8bf688ff707f7e3a95435b7cc09a88 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___breakout____breakout_state.hit_brick", ({ ["row"] : ({ ["button"] : _e["button"], ["buttons"] : _e["buttons"], ["client_x"] : _e["clientX"], ["client_y"] : _e["clientY"], ["alt_key"] : _e["altKey"], ["ctrl_key"] : _e["ctrlKey"], ["meta_key"] : _e["metaKey"], ["shift_key"] : _e["shiftKey"] }), ["col"] : 3 }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesBox,{css:({ ["width"] : "32px", ["height"] : "10px", ["background"] : "blue", ["border"] : "1px solid white", ["cursor"] : "pointer" }),onClick:on_click_2e8bf688ff707f7e3a95435b7cc09a88},)

  )
}

function Fragment_232970708729071945568826901852565806096 () {
  
  const reflex___state____state__codechronos___pages___maccode____mac_code_state = useContext(StateContexts.reflex___state____state__codechronos___pages___maccode____mac_code_state)





  
  return (
    jsx(
Fragment,
{},
(reflex___state____state__codechronos___pages___maccode____mac_code_state.notepad_active_rx_state_ ? (jsx(
Fragment,
{},
jsx(Box_91275893106899135733273140869497372340,{},)
,)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{},)
,))),)
  )
}

function Fragment_282672268217843342903918133569191279563 () {
  
  const reflex___state____state__codechronos___components___breakout____breakout_state = useContext(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state)





  
  return (
    jsx(
Fragment,
{},
(reflex___state____state__codechronos___components___breakout____breakout_state.bricks_rx_state_.at(1).at(0) ? (jsx(
Fragment,
{},
jsx(Box_109040417978279600678841949870636468721,{},)
,)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{css:({ ["width"] : "35px", ["height"] : "10px" })},)
,))),)
  )
}

function Fragment_33996330752306292114630491178845683356 () {
  
  const reflex___state____state__codechronos___components___breakout____breakout_state = useContext(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state)





  
  return (
    jsx(
Fragment,
{},
(reflex___state____state__codechronos___components___breakout____breakout_state.auto_play_rx_state_ ? (jsx(
Fragment,
{},
jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "lime", ["textAlign"] : "center" }),size:"1"},
"\ud83d\udfe2 AUTO"
,),)) : (jsx(
Fragment,
{},
jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "red", ["textAlign"] : "center" }),size:"1"},
"\ud83d\udd34 MANUAL"
,),))),)
  )
}

function Button_219477215464531189701437850733598902531 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_db62032fb8e79be7249fa06432c73974 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___pages___blockcode____block_code_state.hide_tutorial", ({  }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"blue",onClick:on_click_db62032fb8e79be7249fa06432c73974,size:"3"},
"Let's Start Building!"
,)
  )
}

function Button_8796877325998894066038926357934260371 () {
  
  const reflex___state____state__codechronos___pages___vibecode____vibe_code_state = useContext(StateContexts.reflex___state____state__codechronos___pages___vibecode____vibe_code_state)
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_92056f0e23f80eed135ce47ffb011335 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___pages___vibecode____vibe_code_state.set_ai_mode", ({ ["mode"] : "experimental" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"pink",onClick:on_click_92056f0e23f80eed135ce47ffb011335,size:"2",variant:((reflex___state____state__codechronos___pages___vibecode____vibe_code_state.ai_mode_rx_state_ === "experimental") ? "soft" : "outline")},
"Experimental"
,)
  )
}

function Fragment_278812249736650107731656478598282381446 () {
  
  const reflex___state____state__codechronos___components___breakout____breakout_state = useContext(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state)





  
  return (
    jsx(
Fragment,
{},
(reflex___state____state__codechronos___components___breakout____breakout_state.bricks_rx_state_.at(4).at(2) ? (jsx(
Fragment,
{},
jsx(Box_141855829220076621947662382981920920086,{},)
,)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{css:({ ["width"] : "35px", ["height"] : "10px" })},)
,))),)
  )
}

function Button_4409934446465006597177086598433217050 () {
  
  const reflex___state____state__codechronos___components___mac_draw____mac_draw_state = useContext(StateContexts.reflex___state____state__codechronos___components___mac_draw____mac_draw_state)
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_6465112e989ad80a5f56cf18fd57408c = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___mac_draw____mac_draw_state.set_tool", ({ ["tool"] : "pencil" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{onClick:on_click_6465112e989ad80a5f56cf18fd57408c,size:"2",variant:((reflex___state____state__codechronos___components___mac_draw____mac_draw_state.current_tool_rx_state_ === "pencil") ? "soft" : "outline")},
"\u270f\ufe0f"
,)
  )
}

function Progress_218666762487269624005176995201155310758 () {
  
  const reflex___state____state__codechronos___pages___home____home_state = useContext(StateContexts.reflex___state____state__codechronos___pages___home____home_state)





  
  return (
    jsx(RadixThemesProgress,{color:"gray",css:({ ["width"] : "300px", ["height"] : "8px" }),value:reflex___state____state__codechronos___pages___home____home_state.progress_rx_state_},)

  )
}

function Fragment_42577652417556630896518931670475519636 () {
  
  const reflex___state____state__codechronos___components___breakout____breakout_state = useContext(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state)





  
  return (
    jsx(
Fragment,
{},
(reflex___state____state__codechronos___components___breakout____breakout_state.bricks_rx_state_.at(0).at(1) ? (jsx(
Fragment,
{},
jsx(Box_4955592766453191096590250986939942463,{},)
,)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{css:({ ["width"] : "35px", ["height"] : "10px" })},)
,))),)
  )
}

function Fragment_286256812553207017422461355883877563044 () {
  
  const reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state = useContext(StateContexts.reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state)





  
  return (
    jsx(
Fragment,
{},
(!((reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state.generated_code_rx_state_ === "")) ? (jsx(
Fragment,
{},
jsx(Prismasynclight_3786491886571996970191929168816844084,{},)
,)) : (jsx(
Fragment,
{},
jsx(
RadixThemesBox,
{css:({ ["height"] : "400px", ["background"] : "#FAFBFC", ["border"] : "2px dashed #D1D5DB", ["borderRadius"] : "6px", ["display"] : "flex", ["alignItems"] : "center", ["justifyContent"] : "center", ["width"] : "100%" })},
jsx(
RadixThemesFlex,
{align:"center",className:"rx-Stack",direction:"column",gap:"3"},
jsx(LucideFileText,{css:({ ["color"] : "#D1D5DB" }),size:48},)
,jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "#6B7280", ["textAlign"] : "center" }),size:"3"},
"Generated code will appear here"
,),jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "#9CA3AF", ["textAlign"] : "center" }),size:"2"},
"Describe your app above and click Generate Code"
,),),),))),)
  )
}

function Box_268782530969152737771182787310205663111 () {
  
  const reflex___state____state__codechronos___pages___home____home_state = useContext(StateContexts.reflex___state____state__codechronos___pages___home____home_state)





  
  return (
    jsx(RadixThemesBox,{css:({ ["width"] : "12px", ["height"] : "12px", ["borderRadius"] : "50%", ["background"] : ((reflex___state____state__codechronos___pages___home____home_state.boot_stage_rx_state_ >= 0) ? "#4ade80" : "#e5e7eb"), ["margin"] : "0 4px" })},)

  )
}

function Button_5665159417027852826706284467618377190 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_2db95855948e66db9ce655b1e42fb1af = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___calculator____calculator_state.input_digit", ({ ["digit"] : "9" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"gray",css:({ ["width"] : "60px", ["height"] : "60px", ["fontSize"] : "18px", ["fontFamily"] : "'Press Start 2P', monospace", ["--default-font-family"] : "'Press Start 2P', monospace" }),onClick:on_click_2db95855948e66db9ce655b1e42fb1af,variant:"solid"},
"9"
,)
  )
}

function Fragment_74836867271179415488921216589008355746 () {
  
  const reflex___state____state__codechronos___pages___vibecode____vibe_code_state = useContext(StateContexts.reflex___state____state__codechronos___pages___vibecode____vibe_code_state)





  
  return (
    jsx(
Fragment,
{},
(reflex___state____state__codechronos___pages___vibecode____vibe_code_state.show_welcome_rx_state_ ? (jsx(
Fragment,
{},
jsx(
RadixThemesFlex,
{css:({ ["display"] : "flex", ["alignItems"] : "center", ["justifyContent"] : "center", ["width"] : "100vw", ["height"] : "100vh", ["background"] : "linear-gradient(135deg, rgba(139, 92, 246, 0.1), rgba(236, 72, 153, 0.1))" })},
jsx(
RadixThemesBox,
{css:({ ["padding"] : "4rem", ["textAlign"] : "center" })},
jsx(
RadixThemesFlex,
{align:"center",className:"rx-Stack",css:({ ["maxWidth"] : "600px" }),direction:"column",gap:"4"},
jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "120px", ["marginBottom"] : "1rem" })},
"\ud83e\uddde"
,),jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "48px", ["fontWeight"] : "bold", ["background"] : "linear-gradient(45deg, #8b5cf6, #ec4899)", ["backgroundClip"] : "text", ["color"] : "transparent", ["textAlign"] : "center" })},
"Welcome to VibeCode 2025"
,),jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "20px", ["color"] : "#64748b", ["textAlign"] : "center", ["marginBottom"] : "2rem" })},
"The future of development is here"
,),jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["marginBottom"] : "3rem" }),direction:"column",gap:"2"},
jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "16px" })},
"\u2728 Describe what you want to build in natural language"
,),jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "16px" })},
"\ud83c\udfaf AI generates production-ready Python code"
,),jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "16px" })},
"\ud83d\ude80 Instant preview and testing"
,),jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "16px" })},
"\ud83d\udd27 Refine and iterate with conversational commands"
,),),jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"row",gap:"3"},
jsx(Button_23795505451821948337933316266105456461,{},)
,jsx(
RadixThemesButton,
{color:"purple",size:"4",variant:"outline"},
"Watch Demo"
,),),),),),)) : (jsx(
Fragment,
{},
jsx(
RadixThemesBox,
{},
jsx(
RadixThemesBox,
{css:({ ["position"] : "fixed", ["top"] : "20px", ["left"] : "50%", ["transform"] : "translateX(-50%)", ["width"] : "90%", ["maxWidth"] : "1200px", ["padding"] : "1rem", ["background"] : "rgba(139, 92, 246, 0.9)", ["backdropFilter"] : "blur(10px)", ["borderRadius"] : "50px", ["border"] : "1px solid rgba(255,255,255,0.2)", ["boxShadow"] : "0 8px 32px rgba(139, 92, 246, 0.3)", ["zIndex"] : "1000" })},
jsx(
RadixThemesFlex,
{align:"center",className:"rx-Stack",css:({ ["width"] : "100%" }),direction:"row",gap:"3"},
jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "16px", ["fontWeight"] : "bold", ["color"] : "white" })},
"\ud83e\uddde VibeCode"
,),jsx(RadixThemesFlex,{css:({ ["flex"] : 1, ["justifySelf"] : "stretch", ["alignSelf"] : "stretch" })},)
,jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"row",gap:"2"},
jsx(Button_142115491237993380672031523260113740788,{},)
,jsx(Button_27294360853427492673241470178741800221,{},)
,jsx(Button_8796877325998894066038926357934260371,{},)
,),),),jsx(
RadixThemesBox,
{css:({ ["paddingTop"] : "100px" })},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["fontFamily"] : "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif", ["--default-font-family"] : "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif", ["width"] : "100%", ["height"] : "100vh", ["background"] : "#FAFBFC" }),direction:"column",gap:"0"},
jsx(
RadixThemesBox,
{css:({ ["background"] : "white", ["borderBottom"] : "1px solid #E5E7EB", ["padding"] : "16px 24px", ["boxShadow"] : "0 1px 3px rgba(0, 0, 0, 0.05)", ["width"] : "100%" })},
jsx(
RadixThemesFlex,
{align:"center",className:"rx-Stack",css:({ ["width"] : "100%" }),direction:"row",justify:"between",gap:"3"},
jsx(
RadixThemesFlex,
{align:"baseline",className:"rx-Stack",direction:"row",gap:"0"},
jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "#1F2937" }),size:"6",weight:"bold"},
"VibeCode"
,),jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "#6B7280", ["marginLeft"] : "1" }),size:"4",weight:"medium"},
"2025"
,),),jsx(RadixThemesFlex,{css:({ ["flex"] : 1, ["justifySelf"] : "stretch", ["alignSelf"] : "stretch" })},)
,jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"row",gap:"2"},
jsx(Button_285844889097564622516074549863566197744,{},)
,jsx(
RadixThemesButton,
{css:({ ["color"] : "#6B7280", ["&:hover"] : ({ ["background"] : "#F3F4F6", ["color"] : "#1F2937" }) }),size:"2",variant:"ghost"},
jsx(LucideSettings,{size:18},)
,),),),),jsx(
RadixThemesBox,
{css:({ ["padding"] : "24px", ["width"] : "100%" })},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["width"] : "100%" }),direction:"column",gap:"6"},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["width"] : "100%", ["background"] : "white", ["border"] : "1px solid #E5E7EB", ["borderRadius"] : "8px", ["padding"] : "20px", ["boxShadow"] : "0 1px 3px rgba(0, 0, 0, 0.05)" }),direction:"column",gap:"4"},
jsx(Fragment_6084906993062426141309500910249554920,{},)
,jsx(Debounceinput_197795757070860827848016485905259741557,{},)
,jsx(
RadixThemesFlex,
{align:"center",className:"rx-Stack",css:({ ["width"] : "100%" }),direction:"row",gap:"3"},
jsx(Button_91593406049628586830859888116301393655,{},)
,jsx(RadixThemesFlex,{css:({ ["flex"] : 1, ["justifySelf"] : "stretch", ["alignSelf"] : "stretch" })},)
,jsx(
RadixThemesFlex,
{align:"center",className:"rx-Stack",direction:"column",gap:"2"},
jsx(Text_155840452032406156039090957037446418219,{},)
,jsx(Slider_194305994201668015122821498069422753548,{},)
,jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "#6B7280" }),size:"1"},
"Higher = More experimental"
,),),jsx(RadixThemesFlex,{css:({ ["flex"] : 1, ["justifySelf"] : "stretch", ["alignSelf"] : "stretch" })},)
,jsx(Button_268462628480918768805754824071657830915,{},)
,),),jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["width"] : "100%" }),direction:"row",gap:"3"},
jsx(
RadixThemesBox,
{css:({ ["width"] : "50%", ["background"] : "white", ["border"] : "1px solid #E5E7EB", ["borderRadius"] : "8px", ["boxShadow"] : "0 1px 3px rgba(0, 0, 0, 0.05)" })},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["width"] : "100%", ["padding"] : "20px" }),direction:"column",gap:"0"},
jsx(
RadixThemesFlex,
{align:"center",className:"rx-Stack",css:({ ["width"] : "100%", ["marginBottom"] : "4" }),direction:"row",justify:"between",gap:"3"},
jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "#111827" }),size:"4",weight:"bold"},
"Conversation"
,),jsx(RadixThemesFlex,{css:({ ["flex"] : 1, ["justifySelf"] : "stretch", ["alignSelf"] : "stretch" })},)
,jsx(Button_104045518669471106225182934179724255184,{},)
,),jsx(Box_117696102163172328261906668772388778942,{},)
,),),jsx(RadixThemesBox,{css:({ ["width"] : "2px", ["height"] : "500px", ["background"] : "#F3F4F6", ["margin"] : "0 16px" })},)
,jsx(
RadixThemesBox,
{css:({ ["width"] : "50%", ["background"] : "white", ["border"] : "1px solid #E5E7EB", ["borderRadius"] : "8px", ["boxShadow"] : "0 1px 3px rgba(0, 0, 0, 0.05)" })},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["width"] : "100%", ["padding"] : "20px" }),direction:"column",gap:"0"},
jsx(
RadixThemesFlex,
{align:"center",className:"rx-Stack",css:({ ["width"] : "100%", ["marginBottom"] : "4" }),direction:"row",justify:"between",gap:"3"},
jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "#111827" }),size:"4",weight:"bold"},
"Generated Code"
,),jsx(RadixThemesFlex,{css:({ ["flex"] : 1, ["justifySelf"] : "stretch", ["alignSelf"] : "stretch" })},)
,jsx(Fragment_320675576210565781951535527049824519903,{},)
,),jsx(Fragment_286256812553207017422461355883877563044,{},)
,),),),),),),),jsx(
RadixThemesBox,
{css:({ ["position"] : "fixed", ["bottom"] : "20px", ["right"] : "20px", ["padding"] : "0.5rem 1rem", ["background"] : "rgba(0,0,0,0.7)", ["borderRadius"] : "20px", ["backdropFilter"] : "blur(10px)" })},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"row",gap:"2"},
jsx(RadixThemesBox,{css:({ ["animation"] : "pulse 2s infinite", ["width"] : "8px", ["height"] : "8px", ["borderRadius"] : "50%", ["background"] : "#10b981" })},)
,jsx(Text_147055318896876021268548607481793427286,{},)
,),),),))),)
  )
}

function Dropdownmenu__item_270526366594079976267385956477900818037 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_e28d46b7c196cd394dc02daef2ee4445 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___notepad____notepad_state.change_font_size", ({ ["size"] : 14 }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesDropdownMenu.Item,
{onClick:on_click_e28d46b7c196cd394dc02daef2ee4445},
"Font Size 14"
,)
  )
}

function Fragment_253306338635615835704678411883117103455 () {
  
  const reflex___state____state__codechronos___components___breakout____breakout_state = useContext(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state)





  
  return (
    jsx(
Fragment,
{},
(reflex___state____state__codechronos___components___breakout____breakout_state.bricks_rx_state_.at(0).at(3) ? (jsx(
Fragment,
{},
jsx(Box_49321650982420396319675627088166443787,{},)
,)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{css:({ ["width"] : "35px", ["height"] : "10px" })},)
,))),)
  )
}

function Button_187071023319145816600356791799902838416 () {
  
  const reflex___state____state__codechronos___components___mac_draw____mac_draw_state = useContext(StateContexts.reflex___state____state__codechronos___components___mac_draw____mac_draw_state)
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_515f3f792ed69b92380fbc99b63529fa = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___mac_draw____mac_draw_state.set_color", ({ ["color"] : "#00FFFF" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesButton,{css:({ ["width"] : "30px", ["height"] : "30px", ["backgroundColor"] : "#00FFFF", ["border"] : ((reflex___state____state__codechronos___components___mac_draw____mac_draw_state.current_color_rx_state_ === "#00FFFF") ? "2px solid #000" : "1px solid #ccc"), ["borderRadius"] : "4px" }),onClick:on_click_515f3f792ed69b92380fbc99b63529fa},)

  )
}

function Button_62604915975806678539581407738687706784 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_4a3df8f6c53eb27e2baa4aa1649da96f = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___vibe_prompt____vibe_prompt_state.preview_app", ({  }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{css:({ ["background"] : "white", ["color"] : "#2563EB", ["border"] : "1px solid #3B82F6", ["borderRadius"] : "4px", ["&:hover"] : ({ ["background"] : "#EBF8FF", ["color"] : "#1D4ED8" }) }),onClick:on_click_4a3df8f6c53eb27e2baa4aa1649da96f,size:"1",variant:"outline"},
jsx(
RadixThemesFlex,
{align:"center",className:"rx-Stack",direction:"row",gap:"1"},
jsx(LucidePlay,{size:14},)
,jsx(
RadixThemesText,
{as:"p"},
"Preview"
,),),)
  )
}

function Button_68997723321721684634029274567694848608 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_7452e607362ff30e41e517d5a2a26b25 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___block_editor____block_editor_state.add_block", ({ ["block_type"] : "print" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"blue",css:({ ["background"] : "linear-gradient(45deg, #93C5FD, #60A5FA)", ["width"] : "120px" }),onClick:on_click_7452e607362ff30e41e517d5a2a26b25},
"Print"
,)
  )
}

function Button_237333068476222730787902042546348026471 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_743275c2e98d825bbf60f169df77f468 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___calculator____calculator_state.toggle_sign", ({  }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"gray",css:({ ["width"] : "60px", ["height"] : "60px", ["fontSize"] : "18px", ["fontFamily"] : "'Press Start 2P', monospace", ["--default-font-family"] : "'Press Start 2P', monospace" }),onClick:on_click_743275c2e98d825bbf60f169df77f468,variant:"solid"},
"\u00b1"
,)
  )
}

function Button_339884565044009369626444165801804472419 () {
  
  const reflex___state____state__codechronos___components___mac_draw____mac_draw_state = useContext(StateContexts.reflex___state____state__codechronos___components___mac_draw____mac_draw_state)
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_4866bf7bdd612ab78bd84ca6124ae1d8 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___mac_draw____mac_draw_state.set_color", ({ ["color"] : "#FF0000" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesButton,{css:({ ["width"] : "30px", ["height"] : "30px", ["backgroundColor"] : "#FF0000", ["border"] : ((reflex___state____state__codechronos___components___mac_draw____mac_draw_state.current_color_rx_state_ === "#FF0000") ? "2px solid #000" : "1px solid #ccc"), ["borderRadius"] : "4px" }),onClick:on_click_4866bf7bdd612ab78bd84ca6124ae1d8},)

  )
}

function Box_47485443008836893019508577274192202125 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_744dbe7bd8a48de3d9a58c939e20307b = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___breakout____breakout_state.hit_brick", ({ ["row"] : ({ ["button"] : _e["button"], ["buttons"] : _e["buttons"], ["client_x"] : _e["clientX"], ["client_y"] : _e["clientY"], ["alt_key"] : _e["altKey"], ["ctrl_key"] : _e["ctrlKey"], ["meta_key"] : _e["metaKey"], ["shift_key"] : _e["shiftKey"] }), ["col"] : 4 }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesBox,{css:({ ["width"] : "32px", ["height"] : "10px", ["background"] : "green", ["border"] : "1px solid white", ["cursor"] : "pointer" }),onClick:on_click_744dbe7bd8a48de3d9a58c939e20307b},)

  )
}

function Button_331992761637737300190594929023979493645 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_e08f55dab20e7f7d03250c6ce218f213 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___block_editor____block_editor_state.add_block", ({ ["block_type"] : "input" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"cyan",css:({ ["background"] : "linear-gradient(45deg, #67E8F9, #22D3EE)", ["width"] : "120px" }),onClick:on_click_e08f55dab20e7f7d03250c6ce218f213},
"Text Input"
,)
  )
}

function Button_23795505451821948337933316266105456461 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_696fdb8f6267c83191796d0895262fc4 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___pages___vibecode____vibe_code_state.dismiss_welcome", ({  }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"purple",css:({ ["background"] : "linear-gradient(45deg, #8b5cf6, #7c3aed)", ["boxShadow"] : "0 4px 15px rgba(139, 92, 246, 0.3)" }),onClick:on_click_696fdb8f6267c83191796d0895262fc4,size:"4"},
"Start Creating"
,)
  )
}

function Button_322859359242133389302035751355682211158 () {
  
  const reflex___state____state__codechronos___components___mac_draw____mac_draw_state = useContext(StateContexts.reflex___state____state__codechronos___components___mac_draw____mac_draw_state)
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_825b10fc3988e675133699cdec64da3c = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___mac_draw____mac_draw_state.set_color", ({ ["color"] : "#FF00FF" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesButton,{css:({ ["width"] : "30px", ["height"] : "30px", ["backgroundColor"] : "#FF00FF", ["border"] : ((reflex___state____state__codechronos___components___mac_draw____mac_draw_state.current_color_rx_state_ === "#FF00FF") ? "2px solid #000" : "1px solid #ccc"), ["borderRadius"] : "4px" }),onClick:on_click_825b10fc3988e675133699cdec64da3c},)

  )
}

function Fragment_113910408577836712550783423518941473547 () {
  
  const reflex___state____state__codechronos___components___breakout____breakout_state = useContext(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state)





  
  return (
    jsx(
Fragment,
{},
(reflex___state____state__codechronos___components___breakout____breakout_state.bricks_rx_state_.at(3).at(7) ? (jsx(
Fragment,
{},
jsx(Box_161416118734409037069883407628595975886,{},)
,)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{css:({ ["width"] : "35px", ["height"] : "10px" })},)
,))),)
  )
}

function Button_266243065710913104803511063422514002800 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_8d2a755fb5f634d3f6c7ea18a41994b0 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___pages___maccode____mac_code_state.open_breakout", ({  }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{css:({ ["whiteSpace"] : "pre-line", ["textAlign"] : "center", ["&:hover"] : ({ ["background"] : "rgba(0,0,0,0.1)" }), ["position"] : "absolute", ["left"] : "20px", ["top"] : "300px", ["width"] : "80px", ["height"] : "60px", ["background"] : "#e0e0e0", ["border"] : "1px solid black", ["fontSize"] : "10px", ["fontFamily"] : "'Press Start 2P', monospace", ["--default-font-family"] : "'Press Start 2P', monospace", ["color"] : "black", ["cursor"] : "pointer", ["zIndex"] : "100" }),onClick:on_click_8d2a755fb5f634d3f6c7ea18a41994b0},
"\ud83c\udfae\nBreakout"
,)
  )
}

function Button_82265441122061854264205453094918011035 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_a5d8d71d50e6bc0a248301cf82a1900e = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___calculator____calculator_state.clear", ({  }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"red",css:({ ["width"] : "60px", ["height"] : "60px", ["fontSize"] : "18px", ["fontFamily"] : "'Press Start 2P', monospace", ["--default-font-family"] : "'Press Start 2P', monospace" }),onClick:on_click_a5d8d71d50e6bc0a248301cf82a1900e,variant:"solid"},
"C"
,)
  )
}

function Fragment_9764215023285451793789204154294631619 () {
  
  const reflex___state____state__codechronos___components___breakout____breakout_state = useContext(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state)





  
  return (
    jsx(
Fragment,
{},
(reflex___state____state__codechronos___components___breakout____breakout_state.bricks_rx_state_.at(3).at(1) ? (jsx(
Fragment,
{},
jsx(Box_136815221291671172373662814130161396930,{},)
,)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{css:({ ["width"] : "35px", ["height"] : "10px" })},)
,))),)
  )
}

function Button_127728447672871185321506785230367448006 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_91e577e426b1aea140da5332222a0e6e = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___block_editor____block_editor_state.generate_code", ({  }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"blue",onClick:on_click_91e577e426b1aea140da5332222a0e6e,size:"2"},
"Generate"
,)
  )
}

function Button_233983167859275500955157979568693967623 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_3632709c1ac677924329a969e79b67db = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___pages___blockcode____block_code_state.save_project", ({  }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"green",onClick:on_click_3632709c1ac677924329a969e79b67db,variant:"outline"},
"Save"
,)
  )
}

function Button_284469961482846588817559723203376471363 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_35eae5523df0ad0c0738c15aa45d5610 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___calculator____calculator_state.input_digit", ({ ["digit"] : "7" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"gray",css:({ ["width"] : "60px", ["height"] : "60px", ["fontSize"] : "18px", ["fontFamily"] : "'Press Start 2P', monospace", ["--default-font-family"] : "'Press Start 2P', monospace" }),onClick:on_click_35eae5523df0ad0c0738c15aa45d5610,variant:"solid"},
"7"
,)
  )
}

function Box_110906838594077264925931370970077868636 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_6ad6bbe1c40b639532ea58cf2e424c46 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___breakout____breakout_state.hit_brick", ({ ["row"] : ({ ["button"] : _e["button"], ["buttons"] : _e["buttons"], ["client_x"] : _e["clientX"], ["client_y"] : _e["clientY"], ["alt_key"] : _e["altKey"], ["ctrl_key"] : _e["ctrlKey"], ["meta_key"] : _e["metaKey"], ["shift_key"] : _e["shiftKey"] }), ["col"] : 0 }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesBox,{css:({ ["width"] : "32px", ["height"] : "10px", ["background"] : "red", ["border"] : "1px solid white", ["cursor"] : "pointer" }),onClick:on_click_6ad6bbe1c40b639532ea58cf2e424c46},)

  )
}

function Box_215545926791433575875366456909749151199 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_744dbe7bd8a48de3d9a58c939e20307b = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___breakout____breakout_state.hit_brick", ({ ["row"] : ({ ["button"] : _e["button"], ["buttons"] : _e["buttons"], ["client_x"] : _e["clientX"], ["client_y"] : _e["clientY"], ["alt_key"] : _e["altKey"], ["ctrl_key"] : _e["ctrlKey"], ["meta_key"] : _e["metaKey"], ["shift_key"] : _e["shiftKey"] }), ["col"] : 4 }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesBox,{css:({ ["width"] : "32px", ["height"] : "10px", ["background"] : "red", ["border"] : "1px solid white", ["cursor"] : "pointer" }),onClick:on_click_744dbe7bd8a48de3d9a58c939e20307b},)

  )
}

function Box_117696102163172328261906668772388778942 () {
  
  const reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state = useContext(StateContexts.reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state)
  const { resolvedColorMode } = useContext(ColorModeContext)





  
  return (
    jsx(
RadixThemesBox,
{css:({ ["height"] : "400px", ["overflowY"] : "auto", ["width"] : "100%", ["padding"] : "16px", ["background"] : "#FAFBFC", ["borderRadius"] : "6px" })},
reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state.chat_history_rx_state_.map((msg_rx_state_,index_a44c7d734f1b2927)=>(jsx(
RadixThemesBox,
{css:({ ["padding"] : "12px", ["marginBottom"] : "2", ["background"] : "white", ["border"] : "1px solid #F3F4F6", ["borderRadius"] : "6px", ["borderLeft"] : ((msg_rx_state_["type"] === "user") ? "3px solid #3B82F6" : "3px solid #8B5CF6"), ["&:hover"] : ({ ["background"] : "#FAFBFC" }) }),key:index_a44c7d734f1b2927},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["width"] : "100%" }),direction:"row",gap:"3"},
jsx(
RadixThemesBox,
{css:({ ["background"] : ((msg_rx_state_["type"] === "user") ? "#EBF8FF" : "#F3E8FF"), ["borderRadius"] : "6px", ["padding"] : "6px", ["flexShrink"] : "0" })},
jsx(DynamicIcon,{css:({ ["size"] : 16, ["color"] : ((msg_rx_state_["type"] === "user") ? "#3B82F6" : "#8B5CF6") }),name:((msg_rx_state_["type"] === "user") ? "user" : "bot").replaceAll("_", "-")},)
,),jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["width"] : "100%" }),direction:"column",gap:"0"},
jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "#111827", ["lineHeight"] : "1.5" }),size:"3"},
msg_rx_state_["content"]
,),jsx(
Fragment,
{},
(isTrue((isTrue(msg_rx_state_["code"]) ? msg_rx_state_["code"] : "")) ? (jsx(
Fragment,
{},
jsx(SyntaxHighlighter,{children:(isTrue(msg_rx_state_["code"]) ? msg_rx_state_["code"] : ""),css:({ ["width"] : "100%", ["background"] : "#1F2937", ["color"] : "#F9FAFB", ["borderRadius"] : "6px", ["fontSize"] : "13px", ["marginTop"] : "2" }),language:"python",style:((resolvedColorMode === "light") ? oneLight : oneDark)},)
,)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{},)
,))),),),),))),)
  )
}

function Text_3864505017450607286061798556629199182 () {
  
  const reflex___state____state__codechronos___components___notepad____notepad_state = useContext(StateContexts.reflex___state____state__codechronos___components___notepad____notepad_state)





  
  return (
    jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "var(--gray-10)" }),size:"1"},
("Font: "+reflex___state____state__codechronos___components___notepad____notepad_state.font_size_rx_state_+"px")
,)
  )
}

function Box_141855829220076621947662382981920920086 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_ff64f56b161807cdba4276a094786f7a = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___breakout____breakout_state.hit_brick", ({ ["row"] : ({ ["button"] : _e["button"], ["buttons"] : _e["buttons"], ["client_x"] : _e["clientX"], ["client_y"] : _e["clientY"], ["alt_key"] : _e["altKey"], ["ctrl_key"] : _e["ctrlKey"], ["meta_key"] : _e["metaKey"], ["shift_key"] : _e["shiftKey"] }), ["col"] : 2 }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesBox,{css:({ ["width"] : "32px", ["height"] : "10px", ["background"] : "blue", ["border"] : "1px solid white", ["cursor"] : "pointer" }),onClick:on_click_ff64f56b161807cdba4276a094786f7a},)

  )
}

function Fragment_37802070233232334938758968696984510704 () {
  
  const reflex___state____state__codechronos___components___breakout____breakout_state = useContext(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state)





  
  return (
    jsx(
Fragment,
{},
(reflex___state____state__codechronos___components___breakout____breakout_state.bricks_rx_state_.at(3).at(5) ? (jsx(
Fragment,
{},
jsx(Box_49290262483184897083178324969267371990,{},)
,)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{css:({ ["width"] : "35px", ["height"] : "10px" })},)
,))),)
  )
}

function Button_23612681040425350852215331782780493187 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_6b8f8828f685a892b3863a4d44335170 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___block_editor____block_editor_state.add_block", ({ ["block_type"] : "constant" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"indigo",css:({ ["background"] : "linear-gradient(45deg, #C7D2FE, #A5B4FC)", ["width"] : "120px" }),onClick:on_click_6b8f8828f685a892b3863a4d44335170},
"Constant"
,)
  )
}

function Button_265991197706029796606441258349342569510 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_c522259ae1567389c7415cf35411d19e = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___breakout____breakout_state.move_paddle_right", ({  }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{css:({ ["background"] : "blue", ["color"] : "white" }),onClick:on_click_c522259ae1567389c7415cf35411d19e,size:"2"},
"Right \u25b6"
,)
  )
}

function Button_122927138047196492895609613664274714542 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_de9878a4547efa6d1403cf7b2f9c4e74 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___calculator____calculator_state.input_decimal", ({  }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"gray",css:({ ["width"] : "60px", ["height"] : "60px", ["fontSize"] : "18px", ["fontFamily"] : "'Press Start 2P', monospace", ["--default-font-family"] : "'Press Start 2P', monospace" }),onClick:on_click_de9878a4547efa6d1403cf7b2f9c4e74,variant:"solid"},
"."
,)
  )
}

function Box_23124024619510740204744245790075676054 () {
  
  const reflex___state____state__codechronos___pages___home____home_state = useContext(StateContexts.reflex___state____state__codechronos___pages___home____home_state)





  
  return (
    jsx(RadixThemesBox,{css:({ ["width"] : "12px", ["height"] : "12px", ["borderRadius"] : "50%", ["background"] : ((reflex___state____state__codechronos___pages___home____home_state.boot_stage_rx_state_ >= 1) ? "#4ade80" : "#e5e7eb"), ["margin"] : "0 4px" })},)

  )
}

function Box_288308436728202464397396076818127989140 () {
  
  
                useEffect(() => {
                    ((...args) => (addEvents([(Event("reflex___state____state.codechronos___pages___home____home_state.start_boot_sequence", ({  }), ({  })))], args, ({  }))))()
                    return () => {
                        
                    }
                }, []);
  const [addEvents, connectErrors] = useContext(EventLoopContext);





  
  return (
    jsx(
RadixThemesBox,
{},
jsx(
RadixThemesFlex,
{css:({ ["display"] : "flex", ["alignItems"] : "center", ["justifyContent"] : "center", ["width"] : "100vw", ["height"] : "100vh", ["background"] : "linear-gradient(135deg, #f3f4f6 0%, #e5e7eb 100%)" })},
jsx(
RadixThemesFlex,
{align:"center",className:"rx-Stack",direction:"column",gap:"4"},
jsx(
RadixThemesBox,
{css:({ ["fontSize"] : "120px", ["marginBottom"] : "2rem" })},
"\ud83d\udda5\ufe0f"
,),jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "48px", ["fontWeight"] : "bold", ["fontFamily"] : "'Press Start 2P', monospace", ["--default-font-family"] : "'Press Start 2P', monospace", ["color"] : "#333", ["marginBottom"] : "1rem" })},
"CodeChronOS"
,),jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "18px", ["color"] : "#666", ["marginBottom"] : "3rem" })},
"A journey through software development"
,),jsx(Progress_218666762487269624005176995201155310758,{},)
,jsx(Text_104991294914002852458661333203046641368,{},)
,jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["marginTop"] : "2rem" }),direction:"row",gap:"3"},
jsx(Box_268782530969152737771182787310205663111,{},)
,jsx(Box_23124024619510740204744245790075676054,{},)
,jsx(Box_315922681925402381369863825438003986199,{},)
,jsx(Box_52708232070688556335441278140582202416,{},)
,jsx(Box_202327090064938500444632565552729142166,{},)
,jsx(Box_328346057550143691615894015860893625774,{},)
,),),),)
  )
}

function Debounceinput_73368918924565017456120908267968280115 () {
  
  const reflex___state____state__codechronos___components___notepad____notepad_state = useContext(StateContexts.reflex___state____state__codechronos___components___notepad____notepad_state)
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_change_51853496e7aaf27ac87ae0ae515e217a = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___notepad____notepad_state.update_content", ({ ["new_content"] : _e["target"]["value"] }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(DebounceInput,{css:({ ["background"] : "white", ["border"] : "1px solid #ccc", ["padding"] : "1rem", ["width"] : "100%", ["height"] : "300px", ["fontFamily"] : "'VT323', monospace", ["--default-font-family"] : "'VT323', monospace", ["fontSize"] : (reflex___state____state__codechronos___components___notepad____notepad_state.font_size_rx_state_+"px") }),debounceTimeout:300,element:RadixThemesTextArea,onChange:on_change_51853496e7aaf27ac87ae0ae515e217a,placeholder:"Start typing...",resize:"none",value:reflex___state____state__codechronos___components___notepad____notepad_state.content_rx_state_},)

  )
}

function Button_61565878414463668330901934770804114289 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_9bf0cf4a6113199cc9bda9fe294c4224 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___vibe_prompt____vibe_prompt_state.copy_code", ({  }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{css:({ ["background"] : "white", ["color"] : "#6B7280", ["border"] : "1px solid #D1D5DB", ["borderRadius"] : "4px", ["&:hover"] : ({ ["background"] : "#F9FAFB", ["color"] : "#374151" }) }),onClick:on_click_9bf0cf4a6113199cc9bda9fe294c4224,size:"1",variant:"outline"},
jsx(
RadixThemesFlex,
{align:"center",className:"rx-Stack",direction:"row",gap:"1"},
jsx(LucideCopy,{size:14},)
,jsx(
RadixThemesText,
{as:"p"},
"Copy"
,),),)
  )
}

function Button_300548138931974488521259774216755688599 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_92c36d6d54f8e4e9c790e571db57081a = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___calculator____calculator_state.input_digit", ({ ["digit"] : "2" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"gray",css:({ ["width"] : "60px", ["height"] : "60px", ["fontSize"] : "18px", ["fontFamily"] : "'Press Start 2P', monospace", ["--default-font-family"] : "'Press Start 2P', monospace" }),onClick:on_click_92c36d6d54f8e4e9c790e571db57081a,variant:"solid"},
"2"
,)
  )
}

function Button_28642652200977619605574490436127779426 () {
  
  const reflex___state____state__codechronos___components___mac_draw____mac_draw_state = useContext(StateContexts.reflex___state____state__codechronos___components___mac_draw____mac_draw_state)
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_f930e8ad848f4f08d6c61b1d656ad5a6 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___mac_draw____mac_draw_state.set_color", ({ ["color"] : "#0000FF" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesButton,{css:({ ["width"] : "30px", ["height"] : "30px", ["backgroundColor"] : "#0000FF", ["border"] : ((reflex___state____state__codechronos___components___mac_draw____mac_draw_state.current_color_rx_state_ === "#0000FF") ? "2px solid #000" : "1px solid #ccc"), ["borderRadius"] : "4px" }),onClick:on_click_f930e8ad848f4f08d6c61b1d656ad5a6},)

  )
}

function Button_68566950975981241014315045772062989494 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_8fdb1956fb4e2d4094e23b7ce1ae96fe = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___calculator____calculator_state.calculate_percentage", ({  }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"gray",css:({ ["width"] : "60px", ["height"] : "60px", ["fontSize"] : "18px", ["fontFamily"] : "'Press Start 2P', monospace", ["--default-font-family"] : "'Press Start 2P', monospace" }),onClick:on_click_8fdb1956fb4e2d4094e23b7ce1ae96fe,variant:"solid"},
"%"
,)
  )
}

function Button_285844889097564622516074549863566197744 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_81f851e462850554e1f66d68f7bcabf4 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___vibe_prompt____vibe_prompt_state.toggle_dark_mode", ({  }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{css:({ ["color"] : "#6B7280", ["&:hover"] : ({ ["background"] : "#F3F4F6", ["color"] : "#1F2937" }) }),onClick:on_click_81f851e462850554e1f66d68f7bcabf4,size:"2",variant:"ghost"},
jsx(LucideMoon,{size:18},)
,)
  )
}

function Button_190446632744058997684187653363284335327 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_1b88abd63e3b1fc2c4ceacfa2342b5c9 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___breakout____breakout_state.start_game", ({  }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{css:({ ["background"] : "green", ["color"] : "white", ["width"] : "120px" }),onClick:on_click_1b88abd63e3b1fc2c4ceacfa2342b5c9,size:"3"},
"Start Game"
,)
  )
}

function Box_174144715613526904058507941398936262945 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_181afba2b21173f8c8a0414e45a52a72 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___pages___maccode____mac_code_state.close_macdraw", ({  }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesBox,{css:({ ["&:hover"] : ({ ["background"] : "#ff0000" }), ["width"] : "12px", ["height"] : "12px", ["borderRadius"] : "50%", ["background"] : "white", ["border"] : "1px solid #000", ["cursor"] : "pointer" }),onClick:on_click_181afba2b21173f8c8a0414e45a52a72},)

  )
}

function Button_147559384792091665662814661388975884408 () {
  
  const reflex___state____state__codechronos___components___mac_draw____mac_draw_state = useContext(StateContexts.reflex___state____state__codechronos___components___mac_draw____mac_draw_state)
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_33e5dc969f0f43de087206f7a2047520 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___mac_draw____mac_draw_state.set_tool", ({ ["tool"] : "circle" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{onClick:on_click_33e5dc969f0f43de087206f7a2047520,size:"2",variant:((reflex___state____state__codechronos___components___mac_draw____mac_draw_state.current_tool_rx_state_ === "circle") ? "soft" : "outline")},
"\u2b55"
,)
  )
}

function Button_200017083046967465390026447344790879205 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_adad125f291db3846d2b0a9684375461 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___mac_draw____mac_draw_state.set_brush_size", ({ ["size"] : 3 }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{onClick:on_click_adad125f291db3846d2b0a9684375461,size:"1"},
"M"
,)
  )
}

function Box_280018040571039413123387850221668312751 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_2e8bf688ff707f7e3a95435b7cc09a88 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___breakout____breakout_state.hit_brick", ({ ["row"] : ({ ["button"] : _e["button"], ["buttons"] : _e["buttons"], ["client_x"] : _e["clientX"], ["client_y"] : _e["clientY"], ["alt_key"] : _e["altKey"], ["ctrl_key"] : _e["ctrlKey"], ["meta_key"] : _e["metaKey"], ["shift_key"] : _e["shiftKey"] }), ["col"] : 3 }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesBox,{css:({ ["width"] : "32px", ["height"] : "10px", ["background"] : "yellow", ["border"] : "1px solid white", ["cursor"] : "pointer" }),onClick:on_click_2e8bf688ff707f7e3a95435b7cc09a88},)

  )
}

function Fragment_123085366300739496052920227982946586803 () {
  
  const reflex___state____state__codechronos___components___breakout____breakout_state = useContext(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state)





  
  return (
    jsx(
Fragment,
{},
(reflex___state____state__codechronos___components___breakout____breakout_state.bricks_rx_state_.at(4).at(0) ? (jsx(
Fragment,
{},
jsx(Box_8068448579730643481747333586644373613,{},)
,)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{css:({ ["width"] : "35px", ["height"] : "10px" })},)
,))),)
  )
}

function Button_91593406049628586830859888116301393655 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_cd29b0919dcd6844cceb63a2e48c337b = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___vibe_prompt____vibe_prompt_state.surprise_me", ({  }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{css:({ ["background"] : "white", ["color"] : "#6B7280", ["border"] : "1px solid #D1D5DB", ["borderRadius"] : "6px", ["&:hover"] : ({ ["background"] : "#F9FAFB", ["borderColor"] : "#9CA3AF", ["color"] : "#374151" }) }),onClick:on_click_cd29b0919dcd6844cceb63a2e48c337b,size:"2",variant:"outline"},
jsx(
RadixThemesFlex,
{align:"center",className:"rx-Stack",direction:"row",gap:"2"},
jsx(LucideShuffle,{size:16},)
,jsx(
RadixThemesText,
{as:"p"},
"Surprise Me"
,),),)
  )
}

function Box_137670690589222838856595203964645135146 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_ff64f56b161807cdba4276a094786f7a = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___breakout____breakout_state.hit_brick", ({ ["row"] : ({ ["button"] : _e["button"], ["buttons"] : _e["buttons"], ["client_x"] : _e["clientX"], ["client_y"] : _e["clientY"], ["alt_key"] : _e["altKey"], ["ctrl_key"] : _e["ctrlKey"], ["meta_key"] : _e["metaKey"], ["shift_key"] : _e["shiftKey"] }), ["col"] : 2 }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesBox,{css:({ ["width"] : "32px", ["height"] : "10px", ["background"] : "orange", ["border"] : "1px solid white", ["cursor"] : "pointer" }),onClick:on_click_ff64f56b161807cdba4276a094786f7a},)

  )
}

function Button_136898173205459723246531189379051990621 () {
  
  const reflex___state____state__codechronos___components___mac_draw____mac_draw_state = useContext(StateContexts.reflex___state____state__codechronos___components___mac_draw____mac_draw_state)
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_811b33fcc79af899a90aa2e31edfdc4d = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___mac_draw____mac_draw_state.set_color", ({ ["color"] : "#000000" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesButton,{css:({ ["width"] : "30px", ["height"] : "30px", ["backgroundColor"] : "#000000", ["border"] : ((reflex___state____state__codechronos___components___mac_draw____mac_draw_state.current_color_rx_state_ === "#000000") ? "2px solid #000" : "1px solid #ccc"), ["borderRadius"] : "4px" }),onClick:on_click_811b33fcc79af899a90aa2e31edfdc4d},)

  )
}

function Fragment_27852205857776662234574648439195337576 () {
  
  const reflex___state____state__codechronos___components___breakout____breakout_state = useContext(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state)





  
  return (
    jsx(
Fragment,
{},
(reflex___state____state__codechronos___components___breakout____breakout_state.bricks_rx_state_.at(1).at(1) ? (jsx(
Fragment,
{},
jsx(Box_90858621408870902226353740592384100114,{},)
,)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{css:({ ["width"] : "35px", ["height"] : "10px" })},)
,))),)
  )
}

function Fragment_152748523179056663540353986780056951898 () {
  
  const reflex___state____state__codechronos___components___breakout____breakout_state = useContext(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state)





  
  return (
    jsx(
Fragment,
{},
(reflex___state____state__codechronos___components___breakout____breakout_state.bricks_rx_state_.at(1).at(5) ? (jsx(
Fragment,
{},
jsx(Box_191146898370878537226945140211145528883,{},)
,)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{css:({ ["width"] : "35px", ["height"] : "10px" })},)
,))),)
  )
}

function Button_152030526463307261235458215390865463663 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_d84a4bba52689e863e79df462c87452c = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___mac_draw____mac_draw_state.set_brush_size", ({ ["size"] : 5 }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{onClick:on_click_d84a4bba52689e863e79df462c87452c,size:"1"},
"L"
,)
  )
}

function Fragment_289681848012773864421692141239309944715 () {
  
  const reflex___state____state__codechronos___components___breakout____breakout_state = useContext(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state)





  
  return (
    jsx(
Fragment,
{},
(reflex___state____state__codechronos___components___breakout____breakout_state.bricks_rx_state_.at(3).at(6) ? (jsx(
Fragment,
{},
jsx(Box_20845049294691042169526252293017110355,{},)
,)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{css:({ ["width"] : "35px", ["height"] : "10px" })},)
,))),)
  )
}

function Button_69703613737895074624907044888339820470 () {
  
  const reflex___state____state__codechronos___components___mac_draw____mac_draw_state = useContext(StateContexts.reflex___state____state__codechronos___components___mac_draw____mac_draw_state)
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_e89631e0678d42792bbdc8b9511df700 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___mac_draw____mac_draw_state.set_tool", ({ ["tool"] : "brush" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{onClick:on_click_e89631e0678d42792bbdc8b9511df700,size:"2",variant:((reflex___state____state__codechronos___components___mac_draw____mac_draw_state.current_tool_rx_state_ === "brush") ? "soft" : "outline")},
"\ud83d\udd8c\ufe0f"
,)
  )
}

function Debounceinput_197795757070860827848016485905259741557 () {
  
  const reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state = useContext(StateContexts.reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state)
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_change_6788f1fcf3aa5b5ff0ff0c75b1b43149 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___vibe_prompt____vibe_prompt_state.update_prompt", ({ ["new_prompt"] : _e["target"]["value"] }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(DebounceInput,{css:({ ["width"] : "100%", ["height"] : "120px", ["fontSize"] : "16px", ["background"] : "white", ["border"] : "1px solid #D1D5DB", ["borderRadius"] : "6px", ["padding"] : "16px", ["color"] : "#111827", ["&:focus"] : ({ ["borderColor"] : "#3B82F6", ["boxShadow"] : "0 0 0 3px rgba(59, 130, 246, 0.1)", ["outline"] : "none" }), ["&:placeholder"] : ({ ["color"] : "#9CA3AF" }) }),debounceTimeout:300,element:RadixThemesTextArea,onChange:on_change_6788f1fcf3aa5b5ff0ff0c75b1b43149,placeholder:"Describe the app you want to create...\n\nExamples:\n\u2022 Create a calculator with history\n\u2022 Build a todo list with categories\n\u2022 Make a weather dashboard",resize:"none",value:reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state.prompt_rx_state_},)

  )
}

function Box_328346057550143691615894015860893625774 () {
  
  const reflex___state____state__codechronos___pages___home____home_state = useContext(StateContexts.reflex___state____state__codechronos___pages___home____home_state)





  
  return (
    jsx(RadixThemesBox,{css:({ ["width"] : "12px", ["height"] : "12px", ["borderRadius"] : "50%", ["background"] : ((reflex___state____state__codechronos___pages___home____home_state.boot_stage_rx_state_ >= 5) ? "#4ade80" : "#e5e7eb"), ["margin"] : "0 4px" })},)

  )
}

function Box_307928869062780029287249668425278101389 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_ff64f56b161807cdba4276a094786f7a = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___breakout____breakout_state.hit_brick", ({ ["row"] : ({ ["button"] : _e["button"], ["buttons"] : _e["buttons"], ["client_x"] : _e["clientX"], ["client_y"] : _e["clientY"], ["alt_key"] : _e["altKey"], ["ctrl_key"] : _e["ctrlKey"], ["meta_key"] : _e["metaKey"], ["shift_key"] : _e["shiftKey"] }), ["col"] : 2 }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesBox,{css:({ ["width"] : "32px", ["height"] : "10px", ["background"] : "yellow", ["border"] : "1px solid white", ["cursor"] : "pointer" }),onClick:on_click_ff64f56b161807cdba4276a094786f7a},)

  )
}

function Fragment_162505939924202435219984937205089076434 () {
  
  const reflex___state____state__codechronos___components___breakout____breakout_state = useContext(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state)





  
  return (
    jsx(
Fragment,
{},
(reflex___state____state__codechronos___components___breakout____breakout_state.bricks_rx_state_.at(2).at(2) ? (jsx(
Fragment,
{},
jsx(Box_307928869062780029287249668425278101389,{},)
,)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{css:({ ["width"] : "35px", ["height"] : "10px" })},)
,))),)
  )
}

function Box_49290262483184897083178324969267371990 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_ec4c15f99627e541a3ea58435637d66f = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___breakout____breakout_state.hit_brick", ({ ["row"] : ({ ["button"] : _e["button"], ["buttons"] : _e["buttons"], ["client_x"] : _e["clientX"], ["client_y"] : _e["clientY"], ["alt_key"] : _e["altKey"], ["ctrl_key"] : _e["ctrlKey"], ["meta_key"] : _e["metaKey"], ["shift_key"] : _e["shiftKey"] }), ["col"] : 5 }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesBox,{css:({ ["width"] : "32px", ["height"] : "10px", ["background"] : "green", ["border"] : "1px solid white", ["cursor"] : "pointer" }),onClick:on_click_ec4c15f99627e541a3ea58435637d66f},)

  )
}

function Button_225421362983180022699662441784484987187 () {
  
  const reflex___state____state__codechronos___components___mac_draw____mac_draw_state = useContext(StateContexts.reflex___state____state__codechronos___components___mac_draw____mac_draw_state)
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_858ad80ce11be1dd17988af2dcbee612 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___mac_draw____mac_draw_state.set_color", ({ ["color"] : "#00FF00" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesButton,{css:({ ["width"] : "30px", ["height"] : "30px", ["backgroundColor"] : "#00FF00", ["border"] : ((reflex___state____state__codechronos___components___mac_draw____mac_draw_state.current_color_rx_state_ === "#00FF00") ? "2px solid #000" : "1px solid #ccc"), ["borderRadius"] : "4px" }),onClick:on_click_858ad80ce11be1dd17988af2dcbee612},)

  )
}

function Fragment_277690871413548401504688877088895496433 () {
  
  const reflex___state____state__codechronos___components___breakout____breakout_state = useContext(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state)





  
  return (
    jsx(
Fragment,
{},
(reflex___state____state__codechronos___components___breakout____breakout_state.bricks_rx_state_.at(0).at(5) ? (jsx(
Fragment,
{},
jsx(Box_130076187179758590558520224876932466837,{},)
,)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{css:({ ["width"] : "35px", ["height"] : "10px" })},)
,))),)
  )
}

function Button_187806098466758131624818057004489577517 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_89eeaedd94555045b7a3ce07c41822d4 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___mac_draw____mac_draw_state.set_brush_size", ({ ["size"] : 1 }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{onClick:on_click_89eeaedd94555045b7a3ce07c41822d4,size:"1"},
"S"
,)
  )
}

function Box_91275893106899135733273140869497372340 () {
  
  const reflex___state____state__codechronos___pages___maccode____mac_code_state = useContext(StateContexts.reflex___state____state__codechronos___pages___maccode____mac_code_state)





  
  return (
    jsx(
RadixThemesBox,
{css:({ ["position"] : "absolute", ["left"] : (reflex___state____state__codechronos___pages___maccode____mac_code_state.notepad_x_rx_state_+"px"), ["top"] : (reflex___state____state__codechronos___pages___maccode____mac_code_state.notepad_y_rx_state_+"px"), ["width"] : "450px", ["height"] : "350px", ["background"] : "white", ["border"] : "2px solid black", ["boxShadow"] : "4px 4px 0px rgba(0,0,0,0.5)", ["zIndex"] : "100", ["fontFamily"] : "'Press Start 2P', monospace", ["--default-font-family"] : "'Press Start 2P', monospace" })},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"column",gap:"0"},
jsx(
RadixThemesFlex,
{align:"center",className:"rx-Stack",css:({ ["width"] : "100%", ["height"] : "20px", ["background"] : "white", ["borderBottom"] : "2px solid black", ["cursor"] : "move" }),direction:"row",gap:"3"},
jsx(
RadixThemesBox,
{css:({ ["padding"] : "4px" })},
jsx(Box_287485116332981456434708193420262811263,{},)
,),jsx(
RadixThemesFlex,
{css:({ ["display"] : "flex", ["alignItems"] : "center", ["justifyContent"] : "center", ["flex"] : "1" })},
jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "12px", ["fontFamily"] : "'Press Start 2P', monospace", ["--default-font-family"] : "'Press Start 2P', monospace", ["color"] : "black", ["fontWeight"] : "bold" })},
"Notepad"
,),),jsx(RadixThemesBox,{css:({ ["width"] : "20px" })},)
,),jsx(
RadixThemesBox,
{css:({ ["background"] : "white", ["padding"] : "8px", ["flex"] : "1", ["overflow"] : "auto", ["borderLeft"] : "2px solid black", ["borderRight"] : "2px solid black", ["borderBottom"] : "2px solid black" })},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["width"] : "100%", ["height"] : "100%", ["background"] : "white" }),direction:"column",gap:"0"},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["width"] : "100%", ["padding"] : "0.5rem", ["background"] : "var(--gray-2)", ["borderBottom"] : "1px solid var(--gray-6)" }),direction:"row",gap:"2"},
jsx(
RadixThemesDropdownMenu.Root,
{},
jsx(
RadixThemesDropdownMenu.Trigger,
{},
jsx(
RadixThemesButton,
{size:"2",variant:"ghost"},
"File"
,),),jsx(
RadixThemesDropdownMenu.Content,
{},
jsx(Dropdownmenu__item_65423782002938546488162407450771898675,{},)
,jsx(Dropdownmenu__item_24807577297668632938975327001831867599,{},)
,jsx(RadixThemesDropdownMenu.Separator,{},)
,jsx(
RadixThemesDropdownMenu.Item,
{},
"Exit"
,),),),jsx(
RadixThemesDropdownMenu.Root,
{},
jsx(
RadixThemesDropdownMenu.Trigger,
{},
jsx(
RadixThemesButton,
{size:"2",variant:"ghost"},
"Format"
,),),jsx(
RadixThemesDropdownMenu.Content,
{},
jsx(Dropdownmenu__item_177971289096077839513785154832145555698,{},)
,jsx(Dropdownmenu__item_234667224340087336626630737971996976654,{},)
,jsx(Dropdownmenu__item_270526366594079976267385956477900818037,{},)
,jsx(Dropdownmenu__item_139411670398525463260507540843493349681,{},)
,),),),jsx(Debounceinput_73368918924565017456120908267968280115,{},)
,jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["width"] : "100%", ["padding"] : "0.5rem", ["background"] : "var(--gray-2)", ["borderTop"] : "1px solid var(--gray-6)" }),direction:"row",gap:"3"},
jsx(Text_237996932381961904682111419143537709251,{},)
,jsx(RadixThemesFlex,{css:({ ["flex"] : 1, ["justifySelf"] : "stretch", ["alignSelf"] : "stretch" })},)
,jsx(Text_3864505017450607286061798556629199182,{},)
,),),),),)
  )
}

function Box_136815221291671172373662814130161396930 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_dd19a969b5fbcd48eecfe77c8512fbec = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___breakout____breakout_state.hit_brick", ({ ["row"] : ({ ["button"] : _e["button"], ["buttons"] : _e["buttons"], ["client_x"] : _e["clientX"], ["client_y"] : _e["clientY"], ["alt_key"] : _e["altKey"], ["ctrl_key"] : _e["ctrlKey"], ["meta_key"] : _e["metaKey"], ["shift_key"] : _e["shiftKey"] }), ["col"] : 1 }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesBox,{css:({ ["width"] : "32px", ["height"] : "10px", ["background"] : "green", ["border"] : "1px solid white", ["cursor"] : "pointer" }),onClick:on_click_dd19a969b5fbcd48eecfe77c8512fbec},)

  )
}

function Button_104045518669471106225182934179724255184 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_3be3bc71dd7976792b2b599b6582d1cb = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___vibe_prompt____vibe_prompt_state.clear_chat", ({  }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{css:({ ["color"] : "#6B7280", ["&:hover"] : ({ ["background"] : "#F3F4F6", ["color"] : "#374151" }) }),onClick:on_click_3be3bc71dd7976792b2b599b6582d1cb,size:"1",variant:"ghost"},
jsx(
RadixThemesFlex,
{align:"center",className:"rx-Stack",direction:"row",gap:"1"},
jsx(LucideTrash2,{size:14},)
,jsx(
RadixThemesText,
{as:"p"},
"Clear"
,),),)
  )
}

function Box_102514847484999002769593180011921286723 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_744dbe7bd8a48de3d9a58c939e20307b = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___breakout____breakout_state.hit_brick", ({ ["row"] : ({ ["button"] : _e["button"], ["buttons"] : _e["buttons"], ["client_x"] : _e["clientX"], ["client_y"] : _e["clientY"], ["alt_key"] : _e["altKey"], ["ctrl_key"] : _e["ctrlKey"], ["meta_key"] : _e["metaKey"], ["shift_key"] : _e["shiftKey"] }), ["col"] : 4 }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesBox,{css:({ ["width"] : "32px", ["height"] : "10px", ["background"] : "orange", ["border"] : "1px solid white", ["cursor"] : "pointer" }),onClick:on_click_744dbe7bd8a48de3d9a58c939e20307b},)

  )
}

function Box_200183154894695559090547063742144703666 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_8d23cc0139ac5591548fb9cef1d1466d = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___breakout____breakout_state.hit_brick", ({ ["row"] : ({ ["button"] : _e["button"], ["buttons"] : _e["buttons"], ["client_x"] : _e["clientX"], ["client_y"] : _e["clientY"], ["alt_key"] : _e["altKey"], ["ctrl_key"] : _e["ctrlKey"], ["meta_key"] : _e["metaKey"], ["shift_key"] : _e["shiftKey"] }), ["col"] : 7 }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesBox,{css:({ ["width"] : "32px", ["height"] : "10px", ["background"] : "yellow", ["border"] : "1px solid white", ["cursor"] : "pointer" }),onClick:on_click_8d23cc0139ac5591548fb9cef1d1466d},)

  )
}

function Button_288293195485420009220000238763182503867 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_7737e319194535eed7dead3e2d6e0ddd = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___pages___maccode____mac_code_state.open_macdraw", ({  }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{css:({ ["whiteSpace"] : "pre-line", ["textAlign"] : "center", ["&:hover"] : ({ ["background"] : "rgba(0,0,0,0.1)" }), ["position"] : "absolute", ["left"] : "20px", ["top"] : "220px", ["width"] : "80px", ["height"] : "60px", ["background"] : "#e0e0e0", ["border"] : "1px solid black", ["fontSize"] : "10px", ["fontFamily"] : "'Press Start 2P', monospace", ["--default-font-family"] : "'Press Start 2P', monospace", ["color"] : "black", ["cursor"] : "pointer", ["zIndex"] : "100" }),onClick:on_click_7737e319194535eed7dead3e2d6e0ddd},
"\ud83c\udfa8\nMacDraw"
,)
  )
}

function Button_41393336654860386463322009453935947789 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_fd9a0fd4e22268e06d9a8e62a0a699dc = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___codechronos____state.set_era", ({ ["era"] : "2015" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"blue",onClick:on_click_fd9a0fd4e22268e06d9a8e62a0a699dc,variant:"ghost"},
"Block 2015"
,)
  )
}

function Fragment_112608084174350505895512391119508087369 () {
  
  const reflex___state____state__codechronos___components___breakout____breakout_state = useContext(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state)





  
  return (
    jsx(
Fragment,
{},
(reflex___state____state__codechronos___components___breakout____breakout_state.bricks_rx_state_.at(1).at(4) ? (jsx(
Fragment,
{},
jsx(Box_102514847484999002769593180011921286723,{},)
,)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{css:({ ["width"] : "35px", ["height"] : "10px" })},)
,))),)
  )
}

function Fragment_63970630645396086346681513352013804056 () {
  
  const reflex___state____state__codechronos___components___breakout____breakout_state = useContext(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state)





  
  return (
    jsx(
Fragment,
{},
(reflex___state____state__codechronos___components___breakout____breakout_state.bricks_rx_state_.at(2).at(4) ? (jsx(
Fragment,
{},
jsx(Box_240547534704827253937718717201604013315,{},)
,)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{css:({ ["width"] : "35px", ["height"] : "10px" })},)
,))),)
  )
}

function Fragment_235850454122705276607237826755668050656 () {
  
  const reflex___state____state__codechronos___pages___maccode____mac_code_state = useContext(StateContexts.reflex___state____state__codechronos___pages___maccode____mac_code_state)





  
  return (
    jsx(
Fragment,
{},
(reflex___state____state__codechronos___pages___maccode____mac_code_state.breakout_active_rx_state_ ? (jsx(
Fragment,
{},
jsx(Box_271144729248443462166549955814074207807,{},)
,)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{},)
,))),)
  )
}

function Fragment_8516734253161781439080054876448376413 () {
  
  const reflex___state____state__codechronos___components___breakout____breakout_state = useContext(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state)





  
  return (
    jsx(
Fragment,
{},
(reflex___state____state__codechronos___components___breakout____breakout_state.bricks_rx_state_.at(0).at(7) ? (jsx(
Fragment,
{},
jsx(Box_126081557249898688703572572109252319005,{},)
,)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{css:({ ["width"] : "35px", ["height"] : "10px" })},)
,))),)
  )
}

function Fragment_263671431515168201232262390608600183772 () {
  
  const reflex___state____state__codechronos___components___breakout____breakout_state = useContext(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state)





  
  return (
    jsx(
Fragment,
{},
(reflex___state____state__codechronos___components___breakout____breakout_state.bricks_rx_state_.at(4).at(3) ? (jsx(
Fragment,
{},
jsx(Box_175695069005499027011147030272202927436,{},)
,)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{css:({ ["width"] : "35px", ["height"] : "10px" })},)
,))),)
  )
}

function Box_90858621408870902226353740592384100114 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_dd19a969b5fbcd48eecfe77c8512fbec = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___breakout____breakout_state.hit_brick", ({ ["row"] : ({ ["button"] : _e["button"], ["buttons"] : _e["buttons"], ["client_x"] : _e["clientX"], ["client_y"] : _e["clientY"], ["alt_key"] : _e["altKey"], ["ctrl_key"] : _e["ctrlKey"], ["meta_key"] : _e["metaKey"], ["shift_key"] : _e["shiftKey"] }), ["col"] : 1 }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesBox,{css:({ ["width"] : "32px", ["height"] : "10px", ["background"] : "orange", ["border"] : "1px solid white", ["cursor"] : "pointer" }),onClick:on_click_dd19a969b5fbcd48eecfe77c8512fbec},)

  )
}

function Button_98629922982460100273507996140430467626 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_e6a30038c77b5fe9b9783b642ebedfd1 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___pages___blockcode____block_code_state.new_project", ({  }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"blue",onClick:on_click_e6a30038c77b5fe9b9783b642ebedfd1,variant:"outline"},
"New"
,)
  )
}

function Fragment_287178239339254547887718008991437968167 () {
  
  const reflex___state____state__codechronos___codechronos____state = useContext(StateContexts.reflex___state____state__codechronos___codechronos____state)





  
  return (
    jsx(
Fragment,
{},
((reflex___state____state__codechronos___codechronos____state.current_era_rx_state_ === "1984") ? (jsx(
Fragment,
{},
jsx(
RadixThemesBox,
{css:({ ["imageRendering"] : "pixelated", ["cursor"] : "crosshair", ["userSelect"] : "none", ["width"] : "100vw", ["height"] : "100vh", ["background"] : "white", ["fontFamily"] : "'Press Start 2P', monospace", ["--default-font-family"] : "'Press Start 2P', monospace" })},
jsx(
RadixThemesFlex,
{align:"center",className:"rx-Stack",css:({ ["width"] : "100%", ["padding"] : "4px 8px", ["background"] : "white", ["borderBottom"] : "2px solid black" }),direction:"row",gap:"3"},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"row",gap:"2"},
jsx(
RadixThemesBox,
{css:({ ["background"] : "black", ["color"] : "white", ["padding"] : "2px 6px", ["cursor"] : "pointer" })},
jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "14px" })},
"\ud83c\udf4e"
,),),jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "12px", ["fontFamily"] : "'Press Start 2P', monospace", ["--default-font-family"] : "'Press Start 2P', monospace", ["cursor"] : "pointer", ["padding"] : "2px 8px" })},
"File"
,),jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "12px", ["fontFamily"] : "'Press Start 2P', monospace", ["--default-font-family"] : "'Press Start 2P', monospace", ["cursor"] : "pointer", ["padding"] : "2px 8px" })},
"Edit"
,),jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "12px", ["fontFamily"] : "'Press Start 2P', monospace", ["--default-font-family"] : "'Press Start 2P', monospace", ["cursor"] : "pointer", ["padding"] : "2px 8px" })},
"View"
,),jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "12px", ["fontFamily"] : "'Press Start 2P', monospace", ["--default-font-family"] : "'Press Start 2P', monospace", ["cursor"] : "pointer", ["padding"] : "2px 8px" })},
"Tools"
,),),jsx(RadixThemesFlex,{css:({ ["flex"] : 1, ["justifySelf"] : "stretch", ["alignSelf"] : "stretch" })},)
,jsx(Text_17318465457492298815093796480195511501,{},)
,),jsx(
RadixThemesBox,
{css:({ ["position"] : "relative", ["width"] : "100%", ["height"] : "calc(100vh - 30px)", ["background"] : "white", ["overflow"] : "hidden" })},
jsx(Button_118634592107776375793086319586934954331,{},)
,jsx(Button_140678343358233532601229815492277362548,{},)
,jsx(Button_288293195485420009220000238763182503867,{},)
,jsx(Button_266243065710913104803511063422514002800,{},)
,jsx(
RadixThemesBox,
{css:({ ["position"] : "relative", ["width"] : "100%", ["height"] : "100%", ["zIndex"] : "50" })},
jsx(Fragment_216893019725020024042768772891642711704,{},)
,jsx(Fragment_232970708729071945568826901852565806096,{},)
,jsx(Fragment_129202257301049972434274211196267332845,{},)
,jsx(Fragment_235850454122705276607237826755668050656,{},)
,),),),)) : (jsx(Fragment_252761261593685100367128669135228531778,{},)
)),)
  )
}

function Box_126081557249898688703572572109252319005 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_8d23cc0139ac5591548fb9cef1d1466d = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___breakout____breakout_state.hit_brick", ({ ["row"] : ({ ["button"] : _e["button"], ["buttons"] : _e["buttons"], ["client_x"] : _e["clientX"], ["client_y"] : _e["clientY"], ["alt_key"] : _e["altKey"], ["ctrl_key"] : _e["ctrlKey"], ["meta_key"] : _e["metaKey"], ["shift_key"] : _e["shiftKey"] }), ["col"] : 7 }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesBox,{css:({ ["width"] : "32px", ["height"] : "10px", ["background"] : "red", ["border"] : "1px solid white", ["cursor"] : "pointer" }),onClick:on_click_8d23cc0139ac5591548fb9cef1d1466d},)

  )
}

function Box_174490190476095276549511234839832916350 () {
  
  const reflex___state____state__codechronos___components___breakout____breakout_state = useContext(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state)





  
  return (
    jsx(
RadixThemesBox,
{css:({ ["position"] : "absolute", ["left"] : (reflex___state____state__codechronos___components___breakout____breakout_state.scaled_ball_x_rx_state_+"px"), ["top"] : (reflex___state____state__codechronos___components___breakout____breakout_state.scaled_ball_y_rx_state_+"px"), ["color"] : "white", ["fontSize"] : "16px", ["zIndex"] : "10" })},
"\u25cf"
,)
  )
}

function Text_184031271800512482560667063629844626607 () {
  
  const reflex___state____state__codechronos___components___breakout____breakout_state = useContext(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state)





  
  return (
    jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "white" }),size:"2",weight:"bold"},
("Bricks: "+reflex___state____state__codechronos___components___breakout____breakout_state.bricks_left_rx_state_)
,)
  )
}

function Button_63581866115272136292725355406440780215 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_1b6cd9696be2dfa28f91366549a0f0d7 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___calculator____calculator_state.input_digit", ({ ["digit"] : "6" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"gray",css:({ ["width"] : "60px", ["height"] : "60px", ["fontSize"] : "18px", ["fontFamily"] : "'Press Start 2P', monospace", ["--default-font-family"] : "'Press Start 2P', monospace" }),onClick:on_click_1b6cd9696be2dfa28f91366549a0f0d7,variant:"solid"},
"6"
,)
  )
}

function Text_237996932381961904682111419143537709251 () {
  
  const reflex___state____state__codechronos___components___notepad____notepad_state = useContext(StateContexts.reflex___state____state__codechronos___components___notepad____notepad_state)





  
  return (
    jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "var(--gray-10)" }),size:"1"},
(reflex___state____state__codechronos___components___notepad____notepad_state.filename_rx_state_+(reflex___state____state__codechronos___components___notepad____notepad_state.is_modified_rx_state_ ? "*" : ""))
,)
  )
}

function Button_321769091228358055937094733606874742740 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_63ce232b1a80890261b481e489dd2e87 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___breakout____breakout_state.update_ball", ({  }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{css:({ ["background"] : "cyan", ["color"] : "black" }),onClick:on_click_63ce232b1a80890261b481e489dd2e87,size:"2"},
"Move Ball"
,)
  )
}

function Button_48403181683860370722143243672719633209 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_6040c33012118d1c5f62ebdb17a4ac0d = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___calculator____calculator_state.input_digit", ({ ["digit"] : "1" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"gray",css:({ ["width"] : "60px", ["height"] : "60px", ["fontSize"] : "18px", ["fontFamily"] : "'Press Start 2P', monospace", ["--default-font-family"] : "'Press Start 2P', monospace" }),onClick:on_click_6040c33012118d1c5f62ebdb17a4ac0d,variant:"solid"},
"1"
,)
  )
}

function Fragment_121498107908862259993586421223809370072 () {
  
  const reflex___state____state__codechronos___codechronos____state = useContext(StateContexts.reflex___state____state__codechronos___codechronos____state)





  
  return (
    jsx(
Fragment,
{},
(reflex___state____state__codechronos___codechronos____state.boot_complete_rx_state_ ? (jsx(
Fragment,
{},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"column",gap:"0"},
jsx(
RadixThemesFlex,
{align:"center",className:"rx-Stack",css:({ ["width"] : "100%", ["padding"] : "1rem", ["background"] : "rgba(0,0,0,0.8)", ["backdropFilter"] : "blur(10px)" }),direction:"row",justify:"between",gap:"3"},
jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "1.5rem", ["fontWeight"] : "bold", ["color"] : "white" })},
"CodeChronOS"
,),jsx(RadixThemesFlex,{css:({ ["flex"] : 1, ["justifySelf"] : "stretch", ["alignSelf"] : "stretch" })},)
,jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"row",gap:"2"},
jsx(Button_284729633373950453481426732557301522693,{},)
,jsx(Button_41393336654860386463322009453935947789,{},)
,jsx(Button_286709652083013392547229448243489173845,{},)
,),),jsx(Fragment_287178239339254547887718008991437968167,{},)
,),)) : (jsx(Fragment_258652760091787945836251939543807118080,{},)
)),)
  )
}

function Fragment_236417408858819033898106930763653220341 () {
  
  const reflex___state____state__codechronos___components___breakout____breakout_state = useContext(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state)





  
  return (
    jsx(
Fragment,
{},
(reflex___state____state__codechronos___components___breakout____breakout_state.bricks_rx_state_.at(2).at(7) ? (jsx(
Fragment,
{},
jsx(Box_200183154894695559090547063742144703666,{},)
,)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{css:({ ["width"] : "35px", ["height"] : "10px" })},)
,))),)
  )
}

function Prismasynclight_135743271562277648814139370464492673590 () {
  
  const { resolvedColorMode } = useContext(ColorModeContext)
  const reflex___state____state__codechronos___components___block_editor____block_editor_state = useContext(StateContexts.reflex___state____state__codechronos___components___block_editor____block_editor_state)





  
  return (
    jsx(SyntaxHighlighter,{children:(!((reflex___state____state__codechronos___components___block_editor____block_editor_state.generated_code_rx_state_ === "")) ? reflex___state____state__codechronos___components___block_editor____block_editor_state.generated_code_rx_state_ : "# Click 'Generate' to see Python code"),css:({ ["width"] : "100%", ["minHeight"] : "200px" }),language:"python",style:((resolvedColorMode === "light") ? oneLight : oneDark)},)

  )
}

function Button_107217309655825590004603843493939337339 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_636a9ec5e648f8e1d9a5ec458fb9d0f9 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___calculator____calculator_state.input_digit", ({ ["digit"] : "8" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"gray",css:({ ["width"] : "60px", ["height"] : "60px", ["fontSize"] : "18px", ["fontFamily"] : "'Press Start 2P', monospace", ["--default-font-family"] : "'Press Start 2P', monospace" }),onClick:on_click_636a9ec5e648f8e1d9a5ec458fb9d0f9,variant:"solid"},
"8"
,)
  )
}

function Fragment_129202257301049972434274211196267332845 () {
  
  const reflex___state____state__codechronos___pages___maccode____mac_code_state = useContext(StateContexts.reflex___state____state__codechronos___pages___maccode____mac_code_state)





  
  return (
    jsx(
Fragment,
{},
(reflex___state____state__codechronos___pages___maccode____mac_code_state.draw_active_rx_state_ ? (jsx(
Fragment,
{},
jsx(Box_249060059608287955488031555719857623513,{},)
,)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{},)
,))),)
  )
}

function Text_136697104082559828191253802781580637780 () {
  
  const reflex___state____state__codechronos___components___calculator____calculator_state = useContext(StateContexts.reflex___state____state__codechronos___components___calculator____calculator_state)





  
  return (
    jsx(
RadixThemesText,
{as:"p",css:({ ["textAlign"] : "right", ["fontFamily"] : "'VT323', monospace", ["--default-font-family"] : "'VT323', monospace" }),size:"6",weight:"bold"},
reflex___state____state__codechronos___components___calculator____calculator_state.display_rx_state_
,)
  )
}

function Button_58961600070984775562488133810713569409 () {
  
  const reflex___state____state__codechronos___components___mac_draw____mac_draw_state = useContext(StateContexts.reflex___state____state__codechronos___components___mac_draw____mac_draw_state)
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_c4a212deebc58f225cf1bc7e7384b1f2 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___mac_draw____mac_draw_state.set_color", ({ ["color"] : "#FFFF00" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesButton,{css:({ ["width"] : "30px", ["height"] : "30px", ["backgroundColor"] : "#FFFF00", ["border"] : ((reflex___state____state__codechronos___components___mac_draw____mac_draw_state.current_color_rx_state_ === "#FFFF00") ? "2px solid #000" : "1px solid #ccc"), ["borderRadius"] : "4px" }),onClick:on_click_c4a212deebc58f225cf1bc7e7384b1f2},)

  )
}

function Fragment_198427796183499817000961534048272084920 () {
  
  const reflex___state____state__codechronos___components___breakout____breakout_state = useContext(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state)





  
  return (
    jsx(
Fragment,
{},
(reflex___state____state__codechronos___components___breakout____breakout_state.bricks_rx_state_.at(2).at(3) ? (jsx(
Fragment,
{},
jsx(Box_280018040571039413123387850221668312751,{},)
,)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{css:({ ["width"] : "35px", ["height"] : "10px" })},)
,))),)
  )
}

function Box_130076187179758590558520224876932466837 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_ec4c15f99627e541a3ea58435637d66f = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___breakout____breakout_state.hit_brick", ({ ["row"] : ({ ["button"] : _e["button"], ["buttons"] : _e["buttons"], ["client_x"] : _e["clientX"], ["client_y"] : _e["clientY"], ["alt_key"] : _e["altKey"], ["ctrl_key"] : _e["ctrlKey"], ["meta_key"] : _e["metaKey"], ["shift_key"] : _e["shiftKey"] }), ["col"] : 5 }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesBox,{css:({ ["width"] : "32px", ["height"] : "10px", ["background"] : "red", ["border"] : "1px solid white", ["cursor"] : "pointer" }),onClick:on_click_ec4c15f99627e541a3ea58435637d66f},)

  )
}

function Fragment_250783482210679390544650544108332610860 () {
  
  const reflex___state____state__codechronos___components___breakout____breakout_state = useContext(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state)





  
  return (
    jsx(
Fragment,
{},
(reflex___state____state__codechronos___components___breakout____breakout_state.bricks_rx_state_.at(2).at(6) ? (jsx(
Fragment,
{},
jsx(Box_208308913324891126156716731934490466688,{},)
,)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{css:({ ["width"] : "35px", ["height"] : "10px" })},)
,))),)
  )
}

function Button_162659129934545480643767067313288100843 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_160f4ab9b94c203dd04e150887c2d3fb = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___block_editor____block_editor_state.add_block", ({ ["block_type"] : "function" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"red",css:({ ["background"] : "linear-gradient(45deg, #FCA5A5, #F87171)", ["width"] : "120px" }),onClick:on_click_160f4ab9b94c203dd04e150887c2d3fb},
"Function"
,)
  )
}

function Dropdownmenu__item_139411670398525463260507540843493349681 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_7706add8c33710c28ae8ddf155a1df38 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___notepad____notepad_state.change_font_size", ({ ["size"] : 16 }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesDropdownMenu.Item,
{onClick:on_click_7706add8c33710c28ae8ddf155a1df38},
"Font Size 16"
,)
  )
}

function Box_153186666532713597889689732847495049536 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_8d23cc0139ac5591548fb9cef1d1466d = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___breakout____breakout_state.hit_brick", ({ ["row"] : ({ ["button"] : _e["button"], ["buttons"] : _e["buttons"], ["client_x"] : _e["clientX"], ["client_y"] : _e["clientY"], ["alt_key"] : _e["altKey"], ["ctrl_key"] : _e["ctrlKey"], ["meta_key"] : _e["metaKey"], ["shift_key"] : _e["shiftKey"] }), ["col"] : 7 }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesBox,{css:({ ["width"] : "32px", ["height"] : "10px", ["background"] : "orange", ["border"] : "1px solid white", ["cursor"] : "pointer" }),onClick:on_click_8d23cc0139ac5591548fb9cef1d1466d},)

  )
}

function Button_188459941934885783935720267776432129326 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_31b6030b445bf491521c96b8cb7917d6 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___calculator____calculator_state.perform_operation", ({ ["next_operation"] : "\u00f7" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"orange",css:({ ["width"] : "60px", ["height"] : "60px", ["fontSize"] : "18px", ["fontFamily"] : "'Press Start 2P', monospace", ["--default-font-family"] : "'Press Start 2P', monospace" }),onClick:on_click_31b6030b445bf491521c96b8cb7917d6,variant:"solid"},
"\u00f7"
,)
  )
}

function Button_304276182871344592155298457011793429588 () {
  
  const reflex___state____state__codechronos___components___mac_draw____mac_draw_state = useContext(StateContexts.reflex___state____state__codechronos___components___mac_draw____mac_draw_state)
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_9d49b3c695aef23876d845577536effd = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___mac_draw____mac_draw_state.set_tool", ({ ["tool"] : "line" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{onClick:on_click_9d49b3c695aef23876d845577536effd,size:"2",variant:((reflex___state____state__codechronos___components___mac_draw____mac_draw_state.current_tool_rx_state_ === "line") ? "soft" : "outline")},
"\ud83d\udccf"
,)
  )
}

function Div_45867332521292778874654643840192164547 () {
  
  const reflex___state____state__codechronos___components___mac_draw____mac_draw_state = useContext(StateContexts.reflex___state____state__codechronos___components___mac_draw____mac_draw_state)





  
  return (
    jsx("div",{className:"rx-Html",dangerouslySetInnerHTML:({ ["__html"] : ("\n                <canvas id=\"drawingCanvas\" width=\"600\" height=\"400\" \n                        style=\"border: 2px solid #000; background: white; cursor: crosshair; display: block;\"\n                        data-tool=\""+reflex___state____state__codechronos___components___mac_draw____mac_draw_state.current_tool_rx_state_+"\" \n                        data-color=\""+reflex___state____state__codechronos___components___mac_draw____mac_draw_state.current_color_rx_state_+"\" \n                        data-size=\""+reflex___state____state__codechronos___components___mac_draw____mac_draw_state.brush_size_rx_state_+"\">\n                </canvas>\n                <script>\n                (function() {\n                    const canvas = document.getElementById(\"drawingCanvas\");\n                    if (!canvas) return;\n                    const ctx = canvas.getContext(\"2d\");\n                    let drawing = false;\n                    \n                    function updateToolState() {\n                        return {\n                            tool: canvas.dataset.tool || \"pencil\",\n                            color: canvas.dataset.color || \"#000000\",\n                            size: parseInt(canvas.dataset.size) || 2\n                        };\n                    }\n                    \n                    canvas.onmousedown = (e) => {\n                        drawing = true;\n                        const { tool, color, size } = updateToolState();\n                        ctx.beginPath();\n                        ctx.moveTo(e.offsetX, e.offsetY);\n                        ctx.strokeStyle = color;\n                        ctx.lineWidth = size;\n                        ctx.lineCap = \"round\";\n                    };\n                    \n                    canvas.onmousemove = (e) => {\n                        if (!drawing) return;\n                        const { tool, color, size } = updateToolState();\n                        ctx.lineTo(e.offsetX, e.offsetY);\n                        ctx.strokeStyle = color;\n                        ctx.lineWidth = size;\n                        ctx.stroke();\n                    };\n                    \n                    canvas.onmouseup = () => drawing = false;\n                    canvas.onmouseleave = () => drawing = false;\n                    \n                    // Clear canvas function\n                    window.clearDrawingCanvas = function() {\n                        ctx.clearRect(0, 0, canvas.width, canvas.height);\n                    };\n                })();\n                </script>\n            ") })},)

  )
}

function Box_250473458978652614230870930250126683750 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_ec4c15f99627e541a3ea58435637d66f = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___breakout____breakout_state.hit_brick", ({ ["row"] : ({ ["button"] : _e["button"], ["buttons"] : _e["buttons"], ["client_x"] : _e["clientX"], ["client_y"] : _e["clientY"], ["alt_key"] : _e["altKey"], ["ctrl_key"] : _e["ctrlKey"], ["meta_key"] : _e["metaKey"], ["shift_key"] : _e["shiftKey"] }), ["col"] : 5 }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesBox,{css:({ ["width"] : "32px", ["height"] : "10px", ["background"] : "blue", ["border"] : "1px solid white", ["cursor"] : "pointer" }),onClick:on_click_ec4c15f99627e541a3ea58435637d66f},)

  )
}

function Box_166178522484563743585171266421621039082 () {
  
  const reflex___state____state__codechronos___components___block_editor____block_editor_state = useContext(StateContexts.reflex___state____state__codechronos___components___block_editor____block_editor_state)





  
  return (
    jsx(
RadixThemesBox,
{css:({ ["minHeight"] : "300px", ["width"] : "100%", ["background"] : "var(--gray-2)", ["border"] : "2px dashed #ccc", ["borderRadius"] : "8px", ["padding"] : "1rem" })},
reflex___state____state__codechronos___components___block_editor____block_editor_state.canvas_blocks_rx_state_.map((block_rx_state_,index_78d93433b6606722)=>(jsx(
RadixThemesBox,
{css:({ ["&:hover"] : ({ ["transform"] : "translateY(-1px)", ["boxShadow"] : "0 3px 6px rgba(0,0,0,0.25)" }), ["padding"] : "0.8em 1.2em", ["margin"] : "0.5rem", ["background"] : ((block_rx_state_["type"] === "constant") ? "#C7D2FE" : ((block_rx_state_["type"] === "print") ? "#93C5FD" : ((block_rx_state_["type"] === "variable") ? "#86EFAC" : ((block_rx_state_["type"] === "if") ? "#FCD34D" : ((block_rx_state_["type"] === "for") ? "#C4B5FD" : ((block_rx_state_["type"] === "function") ? "#FCA5A5" : ((block_rx_state_["type"] === "button") ? "#5EEAD4" : ((block_rx_state_["type"] === "input") ? "#67E8F9" : "#F9A8D4")))))))), ["borderRadius"] : "6px", ["cursor"] : "pointer", ["width"] : "fit-content", ["minWidth"] : "150px", ["maxWidth"] : "200px", ["textAlign"] : "center", ["boxShadow"] : "0 2px 4px rgba(0,0,0,0.15)" }),key:index_78d93433b6606722},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"column",gap:"2"},
jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "white" }),size:"2",weight:"bold"},
block_rx_state_["type"].toUpperCase()
,),jsx(
Fragment,
{},
((block_rx_state_["type"] === "constant") ? (jsx(
Fragment,
{},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"column",gap:"1"},
jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "white" }),size:"1"},
("name: "+block_rx_state_["parameters"]["name"])
,),jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "white" }),size:"1"},
("value: "+block_rx_state_["parameters"]["value"])
,),),)) : (jsx(
Fragment,
{},
((block_rx_state_["type"] === "print") ? (jsx(
Fragment,
{},
jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "white" }),size:"1"},
("text: "+block_rx_state_["parameters"]["text"])
,),)) : (jsx(
Fragment,
{},
((block_rx_state_["type"] === "variable") ? (jsx(
Fragment,
{},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"column",gap:"1"},
jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "white" }),size:"1"},
("name: "+block_rx_state_["parameters"]["name"])
,),jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "white" }),size:"1"},
("value: "+block_rx_state_["parameters"]["value"])
,),),)) : (jsx(
Fragment,
{},
((block_rx_state_["type"] === "if") ? (jsx(
Fragment,
{},
jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "white" }),size:"1"},
("condition: "+block_rx_state_["parameters"]["condition"])
,),)) : (jsx(
Fragment,
{},
((block_rx_state_["type"] === "for") ? (jsx(
Fragment,
{},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"column",gap:"1"},
jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "white" }),size:"1"},
("variable: "+block_rx_state_["parameters"]["variable"])
,),jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "white" }),size:"1"},
("start: "+block_rx_state_["parameters"]["start"])
,),jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "white" }),size:"1"},
("end: "+block_rx_state_["parameters"]["end"])
,),),)) : (jsx(
Fragment,
{},
((block_rx_state_["type"] === "function") ? (jsx(
Fragment,
{},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"column",gap:"1"},
jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "white" }),size:"1"},
("name: "+block_rx_state_["parameters"]["name"])
,),jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "white" }),size:"1"},
("params: "+block_rx_state_["parameters"]["params"])
,),),)) : (jsx(
Fragment,
{},
((block_rx_state_["type"] === "button") ? (jsx(
Fragment,
{},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"column",gap:"1"},
jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "white" }),size:"1"},
("text: "+block_rx_state_["parameters"]["text"])
,),jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "white" }),size:"1"},
("action: "+block_rx_state_["parameters"]["action"])
,),),)) : (jsx(
Fragment,
{},
((block_rx_state_["type"] === "input") ? (jsx(
Fragment,
{},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"column",gap:"1"},
jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "white" }),size:"1"},
("label: "+block_rx_state_["parameters"]["label"])
,),jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "white" }),size:"1"},
("variable: "+block_rx_state_["parameters"]["variable"])
,),),)) : (jsx(
Fragment,
{},
((block_rx_state_["type"] === "slider") ? (jsx(
Fragment,
{},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"column",gap:"1"},
jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "white" }),size:"1"},
("min: "+block_rx_state_["parameters"]["min"])
,),jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "white" }),size:"1"},
("max: "+block_rx_state_["parameters"]["max"])
,),jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "white" }),size:"1"},
("variable: "+block_rx_state_["parameters"]["variable"])
,),),)) : (jsx(
Fragment,
{},
jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "white" }),size:"1"},
"No parameters"
,),))),))),))),))),))),))),))),))),))),),),))),)
  )
}

function Button_290228358543734617405933977780323460514 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_d40b2f32921a48f6c9b57598f375787a = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___breakout____breakout_state.move_paddle_left", ({  }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{css:({ ["background"] : "blue", ["color"] : "white" }),onClick:on_click_d40b2f32921a48f6c9b57598f375787a,size:"2"},
"\u25c0 Left"
,)
  )
}

export default function Component() {
    




  return (
    jsx(
Fragment,
{},
jsx(
RadixThemesBox,
{css:({ ["width"] : "100vw", ["height"] : "100vh" })},
jsx(Fragment_121498107908862259993586421223809370072,{},)
,),jsx(
"title",
{},
"Codechronos | Index"
,),jsx("meta",{content:"favicon.ico",property:"og:image"},)
,)
  )
}
