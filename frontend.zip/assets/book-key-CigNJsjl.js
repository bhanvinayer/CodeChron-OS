import{ao as o}from"./createLucideIcon-B8e-Mjz2.js";import"./chunk-EF7DTUVF-DLseTd5d.js";import"./grid-YQL9s_RY.js";import"./index-DFKkHzjq.js";/**
 * @license lucide-react v0.536.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const e=[["path",{d:"m19 3 1 1",key:"ze14oc"}],["path",{d:"m20 2-4.5 4.5",key:"1sppr8"}],["path",{d:"M20 7.898V21a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20",key:"1xzogz"}],["path",{d:"M4 19.5v-15A2.5 2.5 0 0 1 6.5 2h7.844",key:"vtdg6h"}],["circle",{cx:"14",cy:"8",r:"2",key:"u49eql"}]],r=o("book-key",e);export{e as __iconNode,r as default};
