import{ao as t}from"./createLucideIcon-B8e-Mjz2.js";import"./chunk-EF7DTUVF-DLseTd5d.js";import"./grid-YQL9s_RY.js";import"./index-DFKkHzjq.js";/**
 * @license lucide-react v0.536.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const i=[["rect",{width:"6",height:"14",x:"4",y:"5",rx:"2",key:"1wwnby"}],["rect",{width:"6",height:"10",x:"14",y:"7",rx:"2",key:"1fe6j6"}],["path",{d:"M4 2v20",key:"gtpd5x"}],["path",{d:"M14 2v20",key:"tg6bpw"}]],d=t("align-horizontal-distribute-start",i);export{i as __iconNode,d as default};
