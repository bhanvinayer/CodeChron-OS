

import { Fragment, useCallback, useContext, useEffect } from "react"
import { Box as RadixThemesBox, Button as RadixThemesButton, Flex as RadixThemesFlex, Slider as RadixThemesSlider, Text as RadixThemesText, TextArea as RadixThemesTextArea } from "@radix-ui/themes"
import { ColorModeContext, EventLoopContext, StateContexts } from "$/utils/context"
import { Event, isTrue } from "$/utils/state"
import { CircleHelp as LucideCircleHelp, Copy as LucideCopy, Download as LucideDownload, FileText as LucideFileText, Moon as LucideMoon, Play as LucidePlay, Settings as LucideSettings, Shuffle as LucideShuffle, Sparkles as LucideSparkles, Trash2 as LucideTrash2 } from "lucide-react"
import { DynamicIcon } from "lucide-react/dynamic.mjs"
import DebounceInput from "react-debounce-input"
import { PrismAsyncLight as SyntaxHighlighter } from "react-syntax-highlighter"
import oneLight from "react-syntax-highlighter/dist/esm/styles/prism/one-light"
import oneDark from "react-syntax-highlighter/dist/esm/styles/prism/one-dark"
import { jsx } from "@emotion/react"



function Button_8796877325998894066038926357934260371 () {
  
  const reflex___state____state__codechronos___pages___vibecode____vibe_code_state = useContext(StateContexts.reflex___state____state__codechronos___pages___vibecode____vibe_code_state)
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_92056f0e23f80eed135ce47ffb011335 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___pages___vibecode____vibe_code_state.set_ai_mode", ({ ["mode"] : "experimental" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"pink",onClick:on_click_92056f0e23f80eed135ce47ffb011335,size:"2",variant:((reflex___state____state__codechronos___pages___vibecode____vibe_code_state.ai_mode_rx_state_ === "experimental") ? "soft" : "outline")},
"Experimental"
,)
  )
}

function Fragment_320675576210565781951535527049824519903 () {
  
  const reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state = useContext(StateContexts.reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state)





  
  return (
    jsx(
Fragment,
{},
(!((reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state.generated_code_rx_state_ === "")) ? (jsx(
Fragment,
{},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"row",gap:"2"},
jsx(Button_61565878414463668330901934770804114289,{},)
,jsx(Button_169960526187752535866448905230877626476,{},)
,jsx(Button_62604915975806678539581407738687706784,{},)
,),)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{},)
,))),)
  )
}

function Button_91593406049628586830859888116301393655 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_cd29b0919dcd6844cceb63a2e48c337b = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___vibe_prompt____vibe_prompt_state.surprise_me", ({  }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{css:({ ["background"] : "white", ["color"] : "#6B7280", ["border"] : "1px solid #D1D5DB", ["borderRadius"] : "6px", ["&:hover"] : ({ ["background"] : "#F9FAFB", ["borderColor"] : "#9CA3AF", ["color"] : "#374151" }) }),onClick:on_click_cd29b0919dcd6844cceb63a2e48c337b,size:"2",variant:"outline"},
jsx(
RadixThemesFlex,
{align:"center",className:"rx-Stack",direction:"row",gap:"2"},
jsx(LucideShuffle,{size:16},)
,jsx(
RadixThemesText,
{as:"p"},
"Surprise Me"
,),),)
  )
}

function Debounceinput_197795757070860827848016485905259741557 () {
  
  const reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state = useContext(StateContexts.reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state)
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_change_6788f1fcf3aa5b5ff0ff0c75b1b43149 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___vibe_prompt____vibe_prompt_state.update_prompt", ({ ["new_prompt"] : _e["target"]["value"] }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(DebounceInput,{css:({ ["width"] : "100%", ["height"] : "120px", ["fontSize"] : "16px", ["background"] : "white", ["border"] : "1px solid #D1D5DB", ["borderRadius"] : "6px", ["padding"] : "16px", ["color"] : "#111827", ["&:focus"] : ({ ["borderColor"] : "#3B82F6", ["boxShadow"] : "0 0 0 3px rgba(59, 130, 246, 0.1)", ["outline"] : "none" }), ["&:placeholder"] : ({ ["color"] : "#9CA3AF" }) }),debounceTimeout:300,element:RadixThemesTextArea,onChange:on_change_6788f1fcf3aa5b5ff0ff0c75b1b43149,placeholder:"Describe the app you want to create...\n\nExamples:\n\u2022 Create a calculator with history\n\u2022 Build a todo list with categories\n\u2022 Make a weather dashboard",resize:"none",value:reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state.prompt_rx_state_},)

  )
}

function Button_142115491237993380672031523260113740788 () {
  
  const reflex___state____state__codechronos___pages___vibecode____vibe_code_state = useContext(StateContexts.reflex___state____state__codechronos___pages___vibecode____vibe_code_state)
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_d25867d3191e2369c6f68c1bf6536d1a = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___pages___vibecode____vibe_code_state.set_ai_mode", ({ ["mode"] : "creative" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"purple",onClick:on_click_d25867d3191e2369c6f68c1bf6536d1a,size:"2",variant:((reflex___state____state__codechronos___pages___vibecode____vibe_code_state.ai_mode_rx_state_ === "creative") ? "soft" : "outline")},
"Creative"
,)
  )
}

function Text_155305555398420155212847909347135635247 () {
  
  const reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state = useContext(StateContexts.reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state)





  
  return (
    jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "#DC2626" }),size:"3",weight:"medium"},
reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state.error_message_rx_state_
,)
  )
}

function Slider_194305994201668015122821498069422753548 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_change_198335683d4a040f42bf5eff5b8e07ee = useCallback(((_ev_0) => (addEvents([(Event("reflex___state____state.codechronos___components___vibe_prompt____vibe_prompt_state.set_creativity", ({ ["level"] : _ev_0 }), ({  })))], [_ev_0], ({  })))), [addEvents, Event])



  
  return (
    jsx(RadixThemesSlider,{color:"blue",css:({ ["width"] : "180px" }),defaultValue:[0.7],max:1.0,min:0.1,onValueChange:on_change_198335683d4a040f42bf5eff5b8e07ee,step:0.1,width:"100%"},)

  )
}

function Fragment_286256812553207017422461355883877563044 () {
  
  const reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state = useContext(StateContexts.reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state)





  
  return (
    jsx(
Fragment,
{},
(!((reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state.generated_code_rx_state_ === "")) ? (jsx(
Fragment,
{},
jsx(Prismasynclight_3786491886571996970191929168816844084,{},)
,)) : (jsx(
Fragment,
{},
jsx(
RadixThemesBox,
{css:({ ["height"] : "400px", ["background"] : "#FAFBFC", ["border"] : "2px dashed #D1D5DB", ["borderRadius"] : "6px", ["display"] : "flex", ["alignItems"] : "center", ["justifyContent"] : "center", ["width"] : "100%" })},
jsx(
RadixThemesFlex,
{align:"center",className:"rx-Stack",direction:"column",gap:"3"},
jsx(LucideFileText,{css:({ ["color"] : "#D1D5DB" }),size:48},)
,jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "#6B7280", ["textAlign"] : "center" }),size:"3"},
"Generated code will appear here"
,),jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "#9CA3AF", ["textAlign"] : "center" }),size:"2"},
"Describe your app above and click Generate Code"
,),),),))),)
  )
}

function Button_169960526187752535866448905230877626476 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_7fe0673e78038b95a07d96d32202e663 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___vibe_prompt____vibe_prompt_state.save_app", ({  }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{css:({ ["background"] : "white", ["color"] : "#059669", ["border"] : "1px solid #10B981", ["borderRadius"] : "4px", ["&:hover"] : ({ ["background"] : "#ECFDF5", ["color"] : "#047857" }) }),onClick:on_click_7fe0673e78038b95a07d96d32202e663,size:"1",variant:"outline"},
jsx(
RadixThemesFlex,
{align:"center",className:"rx-Stack",direction:"row",gap:"1"},
jsx(LucideDownload,{size:14},)
,jsx(
RadixThemesText,
{as:"p"},
"Save"
,),),)
  )
}

function Box_117696102163172328261906668772388778942 () {
  
  const reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state = useContext(StateContexts.reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state)
  const { resolvedColorMode } = useContext(ColorModeContext)





  
  return (
    jsx(
RadixThemesBox,
{css:({ ["height"] : "400px", ["overflowY"] : "auto", ["width"] : "100%", ["padding"] : "16px", ["background"] : "#FAFBFC", ["borderRadius"] : "6px" })},
reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state.chat_history_rx_state_.map((msg_rx_state_,index_a44c7d734f1b2927)=>(jsx(
RadixThemesBox,
{css:({ ["padding"] : "12px", ["marginBottom"] : "2", ["background"] : "white", ["border"] : "1px solid #F3F4F6", ["borderRadius"] : "6px", ["borderLeft"] : ((msg_rx_state_["type"] === "user") ? "3px solid #3B82F6" : "3px solid #8B5CF6"), ["&:hover"] : ({ ["background"] : "#FAFBFC" }) }),key:index_a44c7d734f1b2927},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["width"] : "100%" }),direction:"row",gap:"3"},
jsx(
RadixThemesBox,
{css:({ ["background"] : ((msg_rx_state_["type"] === "user") ? "#EBF8FF" : "#F3E8FF"), ["borderRadius"] : "6px", ["padding"] : "6px", ["flexShrink"] : "0" })},
jsx(DynamicIcon,{css:({ ["size"] : 16, ["color"] : ((msg_rx_state_["type"] === "user") ? "#3B82F6" : "#8B5CF6") }),name:((msg_rx_state_["type"] === "user") ? "user" : "bot").replaceAll("_", "-")},)
,),jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["width"] : "100%" }),direction:"column",gap:"0"},
jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "#111827", ["lineHeight"] : "1.5" }),size:"3"},
msg_rx_state_["content"]
,),jsx(
Fragment,
{},
(isTrue((isTrue(msg_rx_state_["code"]) ? msg_rx_state_["code"] : "")) ? (jsx(
Fragment,
{},
jsx(SyntaxHighlighter,{children:(isTrue(msg_rx_state_["code"]) ? msg_rx_state_["code"] : ""),css:({ ["width"] : "100%", ["background"] : "#1F2937", ["color"] : "#F9FAFB", ["borderRadius"] : "6px", ["fontSize"] : "13px", ["marginTop"] : "2" }),language:"python",style:((resolvedColorMode === "light") ? oneLight : oneDark)},)
,)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{},)
,))),),),),))),)
  )
}

function Button_27294360853427492673241470178741800221 () {
  
  const reflex___state____state__codechronos___pages___vibecode____vibe_code_state = useContext(StateContexts.reflex___state____state__codechronos___pages___vibecode____vibe_code_state)
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_9f6150a87d57a6f7432636cdd73e8e01 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___pages___vibecode____vibe_code_state.set_ai_mode", ({ ["mode"] : "precise" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"blue",onClick:on_click_9f6150a87d57a6f7432636cdd73e8e01,size:"2",variant:((reflex___state____state__codechronos___pages___vibecode____vibe_code_state.ai_mode_rx_state_ === "precise") ? "soft" : "outline")},
"Precise"
,)
  )
}

function Text_147055318896876021268548607481793427286 () {
  
  const reflex___state____state__codechronos___pages___vibecode____vibe_code_state = useContext(StateContexts.reflex___state____state__codechronos___pages___vibecode____vibe_code_state)





  
  return (
    jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "12px", ["color"] : "white" })},
("AI Mode: "+reflex___state____state__codechronos___pages___vibecode____vibe_code_state.ai_mode_rx_state_.split(' ').map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()).join(' '))
,)
  )
}

function Prismasynclight_3786491886571996970191929168816844084 () {
  
  const { resolvedColorMode } = useContext(ColorModeContext)
  const reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state = useContext(StateContexts.reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state)





  
  return (
    jsx(SyntaxHighlighter,{children:reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state.generated_code_rx_state_,css:({ ["width"] : "100%", ["height"] : "400px", ["background"] : "#1F2937", ["color"] : "#F9FAFB", ["borderRadius"] : "6px", ["fontSize"] : "13px", ["overflowY"] : "auto", ["padding"] : "16px" }),language:"python",style:((resolvedColorMode === "light") ? oneLight : oneDark)},)

  )
}

function Text_155840452032406156039090957037446418219 () {
  
  const reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state = useContext(StateContexts.reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state)





  
  return (
    jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "#374151" }),size:"2",weight:"medium"},
("Creativity Level: "+(reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state.creativity_level_rx_state_.toLocaleString('en-US', ((decimals) => ({minimumFractionDigits: decimals, maximumFractionDigits: decimals}))(1)).replaceAll(',', "")))
,)
  )
}

function Button_104045518669471106225182934179724255184 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_3be3bc71dd7976792b2b599b6582d1cb = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___vibe_prompt____vibe_prompt_state.clear_chat", ({  }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{css:({ ["color"] : "#6B7280", ["&:hover"] : ({ ["background"] : "#F3F4F6", ["color"] : "#374151" }) }),onClick:on_click_3be3bc71dd7976792b2b599b6582d1cb,size:"1",variant:"ghost"},
jsx(
RadixThemesFlex,
{align:"center",className:"rx-Stack",direction:"row",gap:"1"},
jsx(LucideTrash2,{size:14},)
,jsx(
RadixThemesText,
{as:"p"},
"Clear"
,),),)
  )
}

function Fragment_74836867271179415488921216589008355746 () {
  
  const reflex___state____state__codechronos___pages___vibecode____vibe_code_state = useContext(StateContexts.reflex___state____state__codechronos___pages___vibecode____vibe_code_state)





  
  return (
    jsx(
Fragment,
{},
(reflex___state____state__codechronos___pages___vibecode____vibe_code_state.show_welcome_rx_state_ ? (jsx(
Fragment,
{},
jsx(
RadixThemesFlex,
{css:({ ["display"] : "flex", ["alignItems"] : "center", ["justifyContent"] : "center", ["width"] : "100vw", ["height"] : "100vh", ["background"] : "linear-gradient(135deg, rgba(139, 92, 246, 0.1), rgba(236, 72, 153, 0.1))" })},
jsx(
RadixThemesBox,
{css:({ ["padding"] : "4rem", ["textAlign"] : "center" })},
jsx(
RadixThemesFlex,
{align:"center",className:"rx-Stack",css:({ ["maxWidth"] : "600px" }),direction:"column",gap:"4"},
jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "120px", ["marginBottom"] : "1rem" })},
"\ud83e\uddde"
,),jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "48px", ["fontWeight"] : "bold", ["background"] : "linear-gradient(45deg, #8b5cf6, #ec4899)", ["backgroundClip"] : "text", ["color"] : "transparent", ["textAlign"] : "center" })},
"Welcome to VibeCode 2025"
,),jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "20px", ["color"] : "#64748b", ["textAlign"] : "center", ["marginBottom"] : "2rem" })},
"The future of development is here"
,),jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["marginBottom"] : "3rem" }),direction:"column",gap:"2"},
jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "16px" })},
"\u2728 Describe what you want to build in natural language"
,),jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "16px" })},
"\ud83c\udfaf AI generates production-ready Python code"
,),jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "16px" })},
"\ud83d\ude80 Instant preview and testing"
,),jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "16px" })},
"\ud83d\udd27 Refine and iterate with conversational commands"
,),),jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"row",gap:"3"},
jsx(Button_23795505451821948337933316266105456461,{},)
,jsx(
RadixThemesButton,
{color:"purple",size:"4",variant:"outline"},
"Watch Demo"
,),),),),),)) : (jsx(
Fragment,
{},
jsx(
RadixThemesBox,
{},
jsx(
RadixThemesBox,
{css:({ ["position"] : "fixed", ["top"] : "20px", ["left"] : "50%", ["transform"] : "translateX(-50%)", ["width"] : "90%", ["maxWidth"] : "1200px", ["padding"] : "1rem", ["background"] : "rgba(139, 92, 246, 0.9)", ["backdropFilter"] : "blur(10px)", ["borderRadius"] : "50px", ["border"] : "1px solid rgba(255,255,255,0.2)", ["boxShadow"] : "0 8px 32px rgba(139, 92, 246, 0.3)", ["zIndex"] : "1000" })},
jsx(
RadixThemesFlex,
{align:"center",className:"rx-Stack",css:({ ["width"] : "100%" }),direction:"row",gap:"3"},
jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "16px", ["fontWeight"] : "bold", ["color"] : "white" })},
"\ud83e\uddde VibeCode"
,),jsx(RadixThemesFlex,{css:({ ["flex"] : 1, ["justifySelf"] : "stretch", ["alignSelf"] : "stretch" })},)
,jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"row",gap:"2"},
jsx(Button_142115491237993380672031523260113740788,{},)
,jsx(Button_27294360853427492673241470178741800221,{},)
,jsx(Button_8796877325998894066038926357934260371,{},)
,),),),jsx(
RadixThemesBox,
{css:({ ["paddingTop"] : "100px" })},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["fontFamily"] : "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif", ["--default-font-family"] : "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif", ["width"] : "100%", ["height"] : "100vh", ["background"] : "#FAFBFC" }),direction:"column",gap:"0"},
jsx(
RadixThemesBox,
{css:({ ["background"] : "white", ["borderBottom"] : "1px solid #E5E7EB", ["padding"] : "16px 24px", ["boxShadow"] : "0 1px 3px rgba(0, 0, 0, 0.05)", ["width"] : "100%" })},
jsx(
RadixThemesFlex,
{align:"center",className:"rx-Stack",css:({ ["width"] : "100%" }),direction:"row",justify:"between",gap:"3"},
jsx(
RadixThemesFlex,
{align:"baseline",className:"rx-Stack",direction:"row",gap:"0"},
jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "#1F2937" }),size:"6",weight:"bold"},
"VibeCode"
,),jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "#6B7280", ["marginLeft"] : "1" }),size:"4",weight:"medium"},
"2025"
,),),jsx(RadixThemesFlex,{css:({ ["flex"] : 1, ["justifySelf"] : "stretch", ["alignSelf"] : "stretch" })},)
,jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"row",gap:"2"},
jsx(Button_285844889097564622516074549863566197744,{},)
,jsx(
RadixThemesButton,
{css:({ ["color"] : "#6B7280", ["&:hover"] : ({ ["background"] : "#F3F4F6", ["color"] : "#1F2937" }) }),size:"2",variant:"ghost"},
jsx(LucideSettings,{size:18},)
,),),),),jsx(
RadixThemesBox,
{css:({ ["padding"] : "24px", ["width"] : "100%" })},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["width"] : "100%" }),direction:"column",gap:"6"},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["width"] : "100%", ["background"] : "white", ["border"] : "1px solid #E5E7EB", ["borderRadius"] : "8px", ["padding"] : "20px", ["boxShadow"] : "0 1px 3px rgba(0, 0, 0, 0.05)" }),direction:"column",gap:"4"},
jsx(Fragment_6084906993062426141309500910249554920,{},)
,jsx(Debounceinput_197795757070860827848016485905259741557,{},)
,jsx(
RadixThemesFlex,
{align:"center",className:"rx-Stack",css:({ ["width"] : "100%" }),direction:"row",gap:"3"},
jsx(Button_91593406049628586830859888116301393655,{},)
,jsx(RadixThemesFlex,{css:({ ["flex"] : 1, ["justifySelf"] : "stretch", ["alignSelf"] : "stretch" })},)
,jsx(
RadixThemesFlex,
{align:"center",className:"rx-Stack",direction:"column",gap:"2"},
jsx(Text_155840452032406156039090957037446418219,{},)
,jsx(Slider_194305994201668015122821498069422753548,{},)
,jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "#6B7280" }),size:"1"},
"Higher = More experimental"
,),),jsx(RadixThemesFlex,{css:({ ["flex"] : 1, ["justifySelf"] : "stretch", ["alignSelf"] : "stretch" })},)
,jsx(Button_268462628480918768805754824071657830915,{},)
,),),jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["width"] : "100%" }),direction:"row",gap:"3"},
jsx(
RadixThemesBox,
{css:({ ["width"] : "50%", ["background"] : "white", ["border"] : "1px solid #E5E7EB", ["borderRadius"] : "8px", ["boxShadow"] : "0 1px 3px rgba(0, 0, 0, 0.05)" })},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["width"] : "100%", ["padding"] : "20px" }),direction:"column",gap:"0"},
jsx(
RadixThemesFlex,
{align:"center",className:"rx-Stack",css:({ ["width"] : "100%", ["marginBottom"] : "4" }),direction:"row",justify:"between",gap:"3"},
jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "#111827" }),size:"4",weight:"bold"},
"Conversation"
,),jsx(RadixThemesFlex,{css:({ ["flex"] : 1, ["justifySelf"] : "stretch", ["alignSelf"] : "stretch" })},)
,jsx(Button_104045518669471106225182934179724255184,{},)
,),jsx(Box_117696102163172328261906668772388778942,{},)
,),),jsx(RadixThemesBox,{css:({ ["width"] : "2px", ["height"] : "500px", ["background"] : "#F3F4F6", ["margin"] : "0 16px" })},)
,jsx(
RadixThemesBox,
{css:({ ["width"] : "50%", ["background"] : "white", ["border"] : "1px solid #E5E7EB", ["borderRadius"] : "8px", ["boxShadow"] : "0 1px 3px rgba(0, 0, 0, 0.05)" })},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["width"] : "100%", ["padding"] : "20px" }),direction:"column",gap:"0"},
jsx(
RadixThemesFlex,
{align:"center",className:"rx-Stack",css:({ ["width"] : "100%", ["marginBottom"] : "4" }),direction:"row",justify:"between",gap:"3"},
jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "#111827" }),size:"4",weight:"bold"},
"Generated Code"
,),jsx(RadixThemesFlex,{css:({ ["flex"] : 1, ["justifySelf"] : "stretch", ["alignSelf"] : "stretch" })},)
,jsx(Fragment_320675576210565781951535527049824519903,{},)
,),jsx(Fragment_286256812553207017422461355883877563044,{},)
,),),),),),),),jsx(
RadixThemesBox,
{css:({ ["position"] : "fixed", ["bottom"] : "20px", ["right"] : "20px", ["padding"] : "0.5rem 1rem", ["background"] : "rgba(0,0,0,0.7)", ["borderRadius"] : "20px", ["backdropFilter"] : "blur(10px)" })},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"row",gap:"2"},
jsx(RadixThemesBox,{css:({ ["animation"] : "pulse 2s infinite", ["width"] : "8px", ["height"] : "8px", ["borderRadius"] : "50%", ["background"] : "#10b981" })},)
,jsx(Text_147055318896876021268548607481793427286,{},)
,),),),))),)
  )
}

function Button_62604915975806678539581407738687706784 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_4a3df8f6c53eb27e2baa4aa1649da96f = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___vibe_prompt____vibe_prompt_state.preview_app", ({  }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{css:({ ["background"] : "white", ["color"] : "#2563EB", ["border"] : "1px solid #3B82F6", ["borderRadius"] : "4px", ["&:hover"] : ({ ["background"] : "#EBF8FF", ["color"] : "#1D4ED8" }) }),onClick:on_click_4a3df8f6c53eb27e2baa4aa1649da96f,size:"1",variant:"outline"},
jsx(
RadixThemesFlex,
{align:"center",className:"rx-Stack",direction:"row",gap:"1"},
jsx(LucidePlay,{size:14},)
,jsx(
RadixThemesText,
{as:"p"},
"Preview"
,),),)
  )
}

function Button_61565878414463668330901934770804114289 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_9bf0cf4a6113199cc9bda9fe294c4224 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___vibe_prompt____vibe_prompt_state.copy_code", ({  }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{css:({ ["background"] : "white", ["color"] : "#6B7280", ["border"] : "1px solid #D1D5DB", ["borderRadius"] : "4px", ["&:hover"] : ({ ["background"] : "#F9FAFB", ["color"] : "#374151" }) }),onClick:on_click_9bf0cf4a6113199cc9bda9fe294c4224,size:"1",variant:"outline"},
jsx(
RadixThemesFlex,
{align:"center",className:"rx-Stack",direction:"row",gap:"1"},
jsx(LucideCopy,{size:14},)
,jsx(
RadixThemesText,
{as:"p"},
"Copy"
,),),)
  )
}

function Fragment_6084906993062426141309500910249554920 () {
  
  const reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state = useContext(StateContexts.reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state)





  
  return (
    jsx(
Fragment,
{},
(!((reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state.error_message_rx_state_ === "")) ? (jsx(
Fragment,
{},
jsx(
RadixThemesBox,
{css:({ ["background"] : "#FEF2F2", ["border"] : "1px solid #FCA5A5", ["borderRadius"] : "6px", ["padding"] : "12px 16px", ["width"] : "100%" })},
jsx(
RadixThemesFlex,
{align:"center",className:"rx-Stack",direction:"row",gap:"2"},
jsx(LucideCircleHelp,{css:({ ["color"] : "#DC2626" }),size:16},)
,jsx(Text_155305555398420155212847909347135635247,{},)
,),),)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{},)
,))),)
  )
}

function Button_268462628480918768805754824071657830915 () {
  
  const reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state = useContext(StateContexts.reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state)
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_b4da950997a8c93e4a2677b1356c677d = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___vibe_prompt____vibe_prompt_state.generate_code", ({  }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{css:({ ["background"] : "#3B82F6", ["color"] : "white", ["border"] : "none", ["borderRadius"] : "6px", ["boxShadow"] : "0 1px 3px rgba(0, 0, 0, 0.1)", ["&:hover"] : ({ ["background"] : "#2563EB", ["transform"] : "translateY(-1px)", ["boxShadow"] : "0 4px 6px rgba(0, 0, 0, 0.1)" }) }),loading:reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state.is_generating_rx_state_,onClick:on_click_b4da950997a8c93e4a2677b1356c677d,size:"3"},
jsx(
RadixThemesFlex,
{align:"center",className:"rx-Stack",direction:"row",gap:"2"},
jsx(LucideSparkles,{size:16},)
,jsx(
RadixThemesText,
{as:"p"},
"Generate Code"
,),),)
  )
}

function Button_285844889097564622516074549863566197744 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_81f851e462850554e1f66d68f7bcabf4 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___vibe_prompt____vibe_prompt_state.toggle_dark_mode", ({  }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{css:({ ["color"] : "#6B7280", ["&:hover"] : ({ ["background"] : "#F3F4F6", ["color"] : "#1F2937" }) }),onClick:on_click_81f851e462850554e1f66d68f7bcabf4,size:"2",variant:"ghost"},
jsx(LucideMoon,{size:18},)
,)
  )
}

function Button_23795505451821948337933316266105456461 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_696fdb8f6267c83191796d0895262fc4 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___pages___vibecode____vibe_code_state.dismiss_welcome", ({  }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"purple",css:({ ["background"] : "linear-gradient(45deg, #8b5cf6, #7c3aed)", ["boxShadow"] : "0 4px 15px rgba(139, 92, 246, 0.3)" }),onClick:on_click_696fdb8f6267c83191796d0895262fc4,size:"4"},
"Start Creating"
,)
  )
}

export default function Component() {
    




  return (
    jsx(
Fragment,
{},
jsx(
RadixThemesBox,
{css:({ ["width"] : "100vw", ["height"] : "100vh", ["background"] : "linear-gradient(135deg, #0f0f23 0%, #1a1a2e 50%, #16213e 100%)", ["color"] : "white", ["overflowX"] : "hidden" })},
jsx("div",{className:"rx-Html",dangerouslySetInnerHTML:({ ["__html"] : "\n            <style>\n                @keyframes float {\n                    0%, 100% { transform: translateY(0px) rotate(0deg); }\n                    33% { transform: translateY(-20px) rotate(5deg); }\n                    66% { transform: translateY(10px) rotate(-3deg); }\n                }\n                @keyframes pulse {\n                    0%, 100% { opacity: 1; }\n                    50% { opacity: 0.5; }\n                }\n            </style>\n            " })},)
,jsx(
RadixThemesBox,
{css:({ ["position"] : "fixed", ["top"] : "0", ["left"] : "0", ["width"] : "100%", ["height"] : "100%", ["pointerEvents"] : "none", ["zIndex"] : "-1" })},
jsx(RadixThemesBox,{css:({ ["animation"] : "float 6s ease-in-out infinite", ["width"] : "300px", ["height"] : "300px", ["borderRadius"] : "50%", ["background"] : "radial-gradient(circle, rgba(139, 92, 246, 0.3), transparent)", ["position"] : "absolute", ["top"] : "-150px", ["right"] : "-150px" })},)
,jsx(RadixThemesBox,{css:({ ["animation"] : "float 8s ease-in-out infinite reverse", ["width"] : "200px", ["height"] : "200px", ["borderRadius"] : "50%", ["background"] : "radial-gradient(circle, rgba(236, 72, 153, 0.2), transparent)", ["position"] : "absolute", ["bottom"] : "-100px", ["left"] : "-100px" })},)
,),jsx(Fragment_74836867271179415488921216589008355746,{},)
,),jsx(
"title",
{},
"Codechronos | Vibecode"
,),jsx("meta",{content:"favicon.ico",property:"og:image"},)
,)
  )
}
