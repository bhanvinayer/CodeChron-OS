

import { Fragment, useCallback, useContext, useEffect } from "react"
import { Box as RadixThemesBox, Button as RadixThemesButton, Flex as RadixThemesFlex, Text as RadixThemesText } from "@radix-ui/themes"
import { ColorModeContext, EventLoopContext, StateContexts } from "$/utils/context"
import { Event, isTrue } from "$/utils/state"
import { PrismAsyncLight as SyntaxHighlighter } from "react-syntax-highlighter"
import oneLight from "react-syntax-highlighter/dist/esm/styles/prism/one-light"
import oneDark from "react-syntax-highlighter/dist/esm/styles/prism/one-dark"
import { jsx } from "@emotion/react"



function Button_10963579034772078003108102700277173357 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_4ff3475c34f6e3600c8a2e5bf69fcf6b = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___block_editor____block_editor_state.add_block", ({ ["block_type"] : "slider" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"pink",css:({ ["background"] : "linear-gradient(45deg, #F9A8D4, #EC4899)", ["width"] : "120px" }),onClick:on_click_4ff3475c34f6e3600c8a2e5bf69fcf6b},
"Slider"
,)
  )
}

function Button_98629922982460100273507996140430467626 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_e6a30038c77b5fe9b9783b642ebedfd1 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___pages___blockcode____block_code_state.new_project", ({  }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"blue",onClick:on_click_e6a30038c77b5fe9b9783b642ebedfd1,variant:"outline"},
"New"
,)
  )
}

function Button_219477215464531189701437850733598902531 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_db62032fb8e79be7249fa06432c73974 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___pages___blockcode____block_code_state.hide_tutorial", ({  }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"blue",onClick:on_click_db62032fb8e79be7249fa06432c73974,size:"3"},
"Let's Start Building!"
,)
  )
}

function Button_127728447672871185321506785230367448006 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_91e577e426b1aea140da5332222a0e6e = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___block_editor____block_editor_state.generate_code", ({  }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"blue",onClick:on_click_91e577e426b1aea140da5332222a0e6e,size:"2"},
"Generate"
,)
  )
}

function Button_233983167859275500955157979568693967623 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_3632709c1ac677924329a969e79b67db = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___pages___blockcode____block_code_state.save_project", ({  }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"green",onClick:on_click_3632709c1ac677924329a969e79b67db,variant:"outline"},
"Save"
,)
  )
}

function Text_336104500564292434712161161494157494909 () {
  
  const reflex___state____state__codechronos___pages___blockcode____block_code_state = useContext(StateContexts.reflex___state____state__codechronos___pages___blockcode____block_code_state)





  
  return (
    jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "18px", ["fontWeight"] : "bold" })},
reflex___state____state__codechronos___pages___blockcode____block_code_state.current_project_rx_state_
,)
  )
}

function Prismasynclight_135743271562277648814139370464492673590 () {
  
  const { resolvedColorMode } = useContext(ColorModeContext)
  const reflex___state____state__codechronos___components___block_editor____block_editor_state = useContext(StateContexts.reflex___state____state__codechronos___components___block_editor____block_editor_state)





  
  return (
    jsx(SyntaxHighlighter,{children:(!((reflex___state____state__codechronos___components___block_editor____block_editor_state.generated_code_rx_state_ === "")) ? reflex___state____state__codechronos___components___block_editor____block_editor_state.generated_code_rx_state_ : "# Click 'Generate' to see Python code"),css:({ ["width"] : "100%", ["minHeight"] : "200px" }),language:"python",style:((resolvedColorMode === "light") ? oneLight : oneDark)},)

  )
}

function Button_194567053326286791963899705503038379468 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_d5fcbf28aed642c39d245ae222d68eda = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___block_editor____block_editor_state.add_block", ({ ["block_type"] : "variable" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"green",css:({ ["background"] : "linear-gradient(45deg, #86EFAC, #4ADE80)", ["width"] : "120px" }),onClick:on_click_d5fcbf28aed642c39d245ae222d68eda},
"Variable"
,)
  )
}

function Button_24491614469354119162511037219534901725 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_1e65417a673fd7adabae9044b92ea776 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___block_editor____block_editor_state.add_block", ({ ["block_type"] : "button" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"teal",css:({ ["background"] : "linear-gradient(45deg, #5EEAD4, #2DD4BF)", ["width"] : "120px" }),onClick:on_click_1e65417a673fd7adabae9044b92ea776},
"Button"
,)
  )
}

function Button_57382104853626552149995979237980014637 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_0a46be607d676e893bf3d8264c0edda4 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___block_editor____block_editor_state.add_block", ({ ["block_type"] : "for" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"purple",css:({ ["background"] : "linear-gradient(45deg, #C4B5FD, #A78BFA)", ["width"] : "120px" }),onClick:on_click_0a46be607d676e893bf3d8264c0edda4},
"For Loop"
,)
  )
}

function Button_23612681040425350852215331782780493187 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_6b8f8828f685a892b3863a4d44335170 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___block_editor____block_editor_state.add_block", ({ ["block_type"] : "constant" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"indigo",css:({ ["background"] : "linear-gradient(45deg, #C7D2FE, #A5B4FC)", ["width"] : "120px" }),onClick:on_click_6b8f8828f685a892b3863a4d44335170},
"Constant"
,)
  )
}

function Button_162659129934545480643767067313288100843 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_160f4ab9b94c203dd04e150887c2d3fb = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___block_editor____block_editor_state.add_block", ({ ["block_type"] : "function" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"red",css:({ ["background"] : "linear-gradient(45deg, #FCA5A5, #F87171)", ["width"] : "120px" }),onClick:on_click_160f4ab9b94c203dd04e150887c2d3fb},
"Function"
,)
  )
}

function Fragment_287278809950046042776360904378504354677 () {
  
  const reflex___state____state__codechronos___pages___blockcode____block_code_state = useContext(StateContexts.reflex___state____state__codechronos___pages___blockcode____block_code_state)





  
  return (
    jsx(
Fragment,
{},
(reflex___state____state__codechronos___pages___blockcode____block_code_state.show_tutorial_rx_state_ ? (jsx(
Fragment,
{},
jsx(
RadixThemesBox,
{css:({ ["position"] : "fixed", ["top"] : "0", ["left"] : "0", ["width"] : "100vw", ["height"] : "100vh", ["background"] : "rgba(0,0,0,0.5)", ["zIndex"] : "9999" })},
jsx(
RadixThemesFlex,
{css:({ ["display"] : "flex", ["alignItems"] : "center", ["justifyContent"] : "center" })},
jsx(
RadixThemesBox,
{css:({ ["padding"] : "3rem", ["background"] : "white", ["borderRadius"] : "16px", ["border"] : "2px solid #e5e7eb", ["maxWidth"] : "500px", ["boxShadow"] : "0 20px 50px rgba(0,0,0,0.1)" })},
jsx(
RadixThemesFlex,
{align:"center",className:"rx-Stack",direction:"column",gap:"4"},
jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "28px", ["fontWeight"] : "bold", ["color"] : "#2563eb" })},
"Welcome to BlockCode!"
,),jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "16px", ["color"] : "#6b7280", ["textAlign"] : "center" })},
"Drag blocks from the palette to create your app visually"
,),jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"column",gap:"1"},
jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "14px" })},
"\ud83d\udccb Logic blocks: Control your app's behavior"
,),jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "14px" })},
"\ud83c\udfa8 UI blocks: Add buttons, inputs, and visual elements"
,),jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "14px" })},
"\ud83d\udd27 Connect blocks to build complex functionality"
,),jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "14px" })},
"\u26a1 Generate Python code instantly"
,),),jsx(Button_219477215464531189701437850733598902531,{},)
,),),),),)) : (jsx(
Fragment,
{},
jsx(RadixThemesBox,{},)
,))),)
  )
}

function Flex_296659786278355488451140423243399174933 () {
  
  const reflex___state____state__codechronos___pages___blockcode____block_code_state = useContext(StateContexts.reflex___state____state__codechronos___pages___blockcode____block_code_state)





  
  return (
    jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["width"] : "100%" }),direction:"column",gap:"1"},
reflex___state____state__codechronos___pages___blockcode____block_code_state.saved_projects_rx_state_.map((project_rx_state_,index_542d4cf9cff027c4)=>(jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["&:hover"] : ({ ["background"] : "#f3f4f6" }), ["width"] : "100%", ["padding"] : "0.5rem", ["borderRadius"] : "6px" }),direction:"row",key:index_542d4cf9cff027c4,gap:"3"},
jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "16px" })},
"\ud83d\udcc1"
,),jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "14px" })},
project_rx_state_
,),jsx(RadixThemesFlex,{css:({ ["flex"] : 1, ["justifySelf"] : "stretch", ["alignSelf"] : "stretch" })},)
,jsx(
RadixThemesButton,
{size:"1",variant:"ghost"},
"Load"
,),))),)
  )
}

function Button_68997723321721684634029274567694848608 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_7452e607362ff30e41e517d5a2a26b25 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___block_editor____block_editor_state.add_block", ({ ["block_type"] : "print" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"blue",css:({ ["background"] : "linear-gradient(45deg, #93C5FD, #60A5FA)", ["width"] : "120px" }),onClick:on_click_7452e607362ff30e41e517d5a2a26b25},
"Print"
,)
  )
}

function Button_111650463381333800680099922953843479278 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_fc4ad1b8464648d1565a5f75389c13b7 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___block_editor____block_editor_state.clear_canvas", ({  }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"gray",css:({ ["width"] : "120px", ["marginTop"] : "1rem" }),onClick:on_click_fc4ad1b8464648d1565a5f75389c13b7},
"Clear All"
,)
  )
}

function Button_331992761637737300190594929023979493645 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_e08f55dab20e7f7d03250c6ce218f213 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___block_editor____block_editor_state.add_block", ({ ["block_type"] : "input" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"cyan",css:({ ["background"] : "linear-gradient(45deg, #67E8F9, #22D3EE)", ["width"] : "120px" }),onClick:on_click_e08f55dab20e7f7d03250c6ce218f213},
"Text Input"
,)
  )
}

function Box_166178522484563743585171266421621039082 () {
  
  const reflex___state____state__codechronos___components___block_editor____block_editor_state = useContext(StateContexts.reflex___state____state__codechronos___components___block_editor____block_editor_state)





  
  return (
    jsx(
RadixThemesBox,
{css:({ ["minHeight"] : "300px", ["width"] : "100%", ["background"] : "var(--gray-2)", ["border"] : "2px dashed #ccc", ["borderRadius"] : "8px", ["padding"] : "1rem" })},
reflex___state____state__codechronos___components___block_editor____block_editor_state.canvas_blocks_rx_state_.map((block_rx_state_,index_78d93433b6606722)=>(jsx(
RadixThemesBox,
{css:({ ["&:hover"] : ({ ["transform"] : "translateY(-1px)", ["boxShadow"] : "0 3px 6px rgba(0,0,0,0.25)" }), ["padding"] : "0.8em 1.2em", ["margin"] : "0.5rem", ["background"] : ((block_rx_state_["type"] === "constant") ? "#C7D2FE" : ((block_rx_state_["type"] === "print") ? "#93C5FD" : ((block_rx_state_["type"] === "variable") ? "#86EFAC" : ((block_rx_state_["type"] === "if") ? "#FCD34D" : ((block_rx_state_["type"] === "for") ? "#C4B5FD" : ((block_rx_state_["type"] === "function") ? "#FCA5A5" : ((block_rx_state_["type"] === "button") ? "#5EEAD4" : ((block_rx_state_["type"] === "input") ? "#67E8F9" : "#F9A8D4")))))))), ["borderRadius"] : "6px", ["cursor"] : "pointer", ["width"] : "fit-content", ["minWidth"] : "150px", ["maxWidth"] : "200px", ["textAlign"] : "center", ["boxShadow"] : "0 2px 4px rgba(0,0,0,0.15)" }),key:index_78d93433b6606722},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"column",gap:"2"},
jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "white" }),size:"2",weight:"bold"},
block_rx_state_["type"].toUpperCase()
,),jsx(
Fragment,
{},
((block_rx_state_["type"] === "constant") ? (jsx(
Fragment,
{},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"column",gap:"1"},
jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "white" }),size:"1"},
("name: "+block_rx_state_["parameters"]["name"])
,),jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "white" }),size:"1"},
("value: "+block_rx_state_["parameters"]["value"])
,),),)) : (jsx(
Fragment,
{},
((block_rx_state_["type"] === "print") ? (jsx(
Fragment,
{},
jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "white" }),size:"1"},
("text: "+block_rx_state_["parameters"]["text"])
,),)) : (jsx(
Fragment,
{},
((block_rx_state_["type"] === "variable") ? (jsx(
Fragment,
{},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"column",gap:"1"},
jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "white" }),size:"1"},
("name: "+block_rx_state_["parameters"]["name"])
,),jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "white" }),size:"1"},
("value: "+block_rx_state_["parameters"]["value"])
,),),)) : (jsx(
Fragment,
{},
((block_rx_state_["type"] === "if") ? (jsx(
Fragment,
{},
jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "white" }),size:"1"},
("condition: "+block_rx_state_["parameters"]["condition"])
,),)) : (jsx(
Fragment,
{},
((block_rx_state_["type"] === "for") ? (jsx(
Fragment,
{},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"column",gap:"1"},
jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "white" }),size:"1"},
("variable: "+block_rx_state_["parameters"]["variable"])
,),jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "white" }),size:"1"},
("start: "+block_rx_state_["parameters"]["start"])
,),jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "white" }),size:"1"},
("end: "+block_rx_state_["parameters"]["end"])
,),),)) : (jsx(
Fragment,
{},
((block_rx_state_["type"] === "function") ? (jsx(
Fragment,
{},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"column",gap:"1"},
jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "white" }),size:"1"},
("name: "+block_rx_state_["parameters"]["name"])
,),jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "white" }),size:"1"},
("params: "+block_rx_state_["parameters"]["params"])
,),),)) : (jsx(
Fragment,
{},
((block_rx_state_["type"] === "button") ? (jsx(
Fragment,
{},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"column",gap:"1"},
jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "white" }),size:"1"},
("text: "+block_rx_state_["parameters"]["text"])
,),jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "white" }),size:"1"},
("action: "+block_rx_state_["parameters"]["action"])
,),),)) : (jsx(
Fragment,
{},
((block_rx_state_["type"] === "input") ? (jsx(
Fragment,
{},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"column",gap:"1"},
jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "white" }),size:"1"},
("label: "+block_rx_state_["parameters"]["label"])
,),jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "white" }),size:"1"},
("variable: "+block_rx_state_["parameters"]["variable"])
,),),)) : (jsx(
Fragment,
{},
((block_rx_state_["type"] === "slider") ? (jsx(
Fragment,
{},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"column",gap:"1"},
jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "white" }),size:"1"},
("min: "+block_rx_state_["parameters"]["min"])
,),jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "white" }),size:"1"},
("max: "+block_rx_state_["parameters"]["max"])
,),jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "white" }),size:"1"},
("variable: "+block_rx_state_["parameters"]["variable"])
,),),)) : (jsx(
Fragment,
{},
jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "white" }),size:"1"},
"No parameters"
,),))),))),))),))),))),))),))),))),))),),),))),)
  )
}

function Button_43642195342283648934813609275825279546 () {
  
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_adc5bd54e24101b958af5c571d0c2cd4 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___components___block_editor____block_editor_state.add_block", ({ ["block_type"] : "if" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"orange",css:({ ["background"] : "linear-gradient(45deg, #FCD34D, #F59E0B)", ["width"] : "120px" }),onClick:on_click_adc5bd54e24101b958af5c571d0c2cd4},
"If Statement"
,)
  )
}

export default function Component() {
    




  return (
    jsx(
Fragment,
{},
jsx(
RadixThemesBox,
{css:({ ["width"] : "100vw", ["height"] : "100vh", ["background"] : "#ffffff", ["fontFamily"] : "system-ui, -apple-system, sans-serif", ["--default-font-family"] : "system-ui, -apple-system, sans-serif" })},
jsx(Fragment_287278809950046042776360904378504354677,{},)
,jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"column",gap:"0"},
jsx(
RadixThemesFlex,
{align:"center",className:"rx-Stack",css:({ ["width"] : "100%", ["padding"] : "1rem 2rem", ["background"] : "white", ["borderBottom"] : "2px solid #e5e7eb" }),direction:"row",gap:"3"},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"row",gap:"2"},
jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "24px" })},
"\ud83e\uddf1"
,),jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "24px", ["fontWeight"] : "bold", ["color"] : "#2563eb" })},
"BlockCode 2015"
,),),jsx(RadixThemesFlex,{css:({ ["flex"] : 1, ["justifySelf"] : "stretch", ["alignSelf"] : "stretch" })},)
,jsx(Text_336104500564292434712161161494157494909,{},)
,jsx(RadixThemesFlex,{css:({ ["flex"] : 1, ["justifySelf"] : "stretch", ["alignSelf"] : "stretch" })},)
,jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"row",gap:"2"},
jsx(Button_98629922982460100273507996140430467626,{},)
,jsx(Button_233983167859275500955157979568693967623,{},)
,jsx(
RadixThemesButton,
{color:"purple",variant:"outline"},
"Share"
,),),),jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["width"] : "100%", ["height"] : "calc(100vh - 80px)" }),direction:"row",gap:"0"},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["width"] : "250px", ["height"] : "100%", ["padding"] : "2rem", ["background"] : "#f9fafb", ["borderRight"] : "2px solid #e5e7eb" }),direction:"column",gap:"3"},
jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "16px", ["fontWeight"] : "bold", ["color"] : "#374151" })},
"Saved Projects"
,),jsx(Flex_296659786278355488451140423243399174933,{},)
,jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "16px", ["fontWeight"] : "bold", ["color"] : "#374151", ["marginTop"] : "2rem" })},
"Quick Tips"
,),jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"column",gap:"1"},
jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "12px", ["color"] : "#6b7280" })},
"\ud83d\udca1 Drag blocks to the canvas"
,),jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "12px", ["color"] : "#6b7280" })},
"\ud83d\udd17 Snap blocks together"
,),jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "12px", ["color"] : "#6b7280" })},
"\u2699\ufe0f Click blocks to edit properties"
,),jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "12px", ["color"] : "#6b7280" })},
"\ud83d\ude80 Hit Generate to see Python code"
,),),),jsx(
RadixThemesBox,
{css:({ ["width"] : "100%", ["height"] : "100%", ["padding"] : "2rem", ["background"] : "linear-gradient(135deg, #dbeafe 0%, #ede9fe 100%)" })},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["width"] : "100%", ["height"] : "100%" }),direction:"row",gap:"4"},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["padding"] : "1rem", ["background"] : "var(--gray-1)", ["borderRadius"] : "8px" }),direction:"column",gap:"2"},
jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "blue" }),size:"3",weight:"bold"},
"Logic Blocks"
,),jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"column",gap:"2"},
jsx(Button_23612681040425350852215331782780493187,{},)
,jsx(Button_68997723321721684634029274567694848608,{},)
,jsx(Button_194567053326286791963899705503038379468,{},)
,jsx(Button_43642195342283648934813609275825279546,{},)
,jsx(Button_57382104853626552149995979237980014637,{},)
,jsx(Button_162659129934545480643767067313288100843,{},)
,),jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "teal", ["marginTop"] : "1rem" }),size:"3",weight:"bold"},
"UI Blocks"
,),jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"column",gap:"2"},
jsx(Button_24491614469354119162511037219534901725,{},)
,jsx(Button_331992761637737300190594929023979493645,{},)
,jsx(Button_10963579034772078003108102700277173357,{},)
,),jsx(Button_111650463381333800680099922953843479278,{},)
,),jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["width"] : "100%" }),direction:"column",gap:"4"},
jsx(
RadixThemesBox,
{css:({ ["width"] : "100%" })},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"column",gap:"2"},
jsx(
RadixThemesText,
{as:"p",size:"4",weight:"bold"},
"Block Canvas"
,),jsx(Box_166178522484563743585171266421621039082,{},)
,),),jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["width"] : "100%" }),direction:"column",gap:"2"},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["width"] : "100%" }),direction:"row",justify:"between",gap:"3"},
jsx(
RadixThemesText,
{as:"p",size:"4",weight:"bold"},
"Generated Code"
,),jsx(Button_127728447672871185321506785230367448006,{},)
,),jsx(Prismasynclight_135743271562277648814139370464492673590,{},)
,),),),),),),),jsx(
"title",
{},
"Codechronos | Blockcode"
,),jsx("meta",{content:"favicon.ico",property:"og:image"},)
,)
  )
}
