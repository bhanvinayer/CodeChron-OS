import{ao as t}from"./createLucideIcon-B8e-Mjz2.js";import"./chunk-EF7DTUVF-DLseTd5d.js";import"./grid-YQL9s_RY.js";import"./index-DFKkHzjq.js";/**
 * @license lucide-react v0.536.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const o=[["rect",{width:"6",height:"16",x:"4",y:"2",rx:"2",key:"z5wdxg"}],["rect",{width:"6",height:"9",x:"14",y:"9",rx:"2",key:"um7a8w"}],["path",{d:"M22 22H2",key:"19qnx5"}]],a=t("align-end-horizontal",o);export{o as __iconNode,a as default};
