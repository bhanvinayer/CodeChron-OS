

import { Fragment, useCallback, useContext, useEffect } from "react"
import { Badge as RadixThemesBadge, Box as RadixThemesBox, Button as RadixThemesButton, Flex as RadixThemesFlex, Grid as RadixThemesGrid, Text as RadixThemesText } from "@radix-ui/themes"
import { ColorModeContext, EventLoopContext, StateContexts } from "$/utils/context"
import { Event, isTrue } from "$/utils/state"
import { PrismAsyncLight as SyntaxHighlighter } from "react-syntax-highlighter"
import oneLight from "react-syntax-highlighter/dist/esm/styles/prism/one-light"
import oneDark from "react-syntax-highlighter/dist/esm/styles/prism/one-dark"
import { jsx } from "@emotion/react"



function Badge_64850405393027634878232118631668143541 () {
  
  const reflex___state____state__codechronos___pages___mutation_log____mutation_log_state = useContext(StateContexts.reflex___state____state__codechronos___pages___mutation_log____mutation_log_state)





  
  return (
    jsx(
RadixThemesBadge,
{},
(isTrue(reflex___state____state__codechronos___pages___mutation_log____mutation_log_state.selected_mutation_rx_state_["era"]) ? reflex___state____state__codechronos___pages___mutation_log____mutation_log_state.selected_mutation_rx_state_["era"] : "")
,)
  )
}

function Text_204061181094170522034824275738100521372 () {
  
  const reflex___state____state__codechronos___pages___mutation_log____mutation_log_state = useContext(StateContexts.reflex___state____state__codechronos___pages___mutation_log____mutation_log_state)





  
  return (
    jsx(
RadixThemesText,
{as:"p"},
(isTrue(reflex___state____state__codechronos___pages___mutation_log____mutation_log_state.selected_mutation_rx_state_["changes"]) ? reflex___state____state__codechronos___pages___mutation_log____mutation_log_state.selected_mutation_rx_state_["changes"] : "")
,)
  )
}

function Button_237060840900705721183161676407105698478 () {
  
  const reflex___state____state__codechronos___pages___mutation_log____mutation_log_state = useContext(StateContexts.reflex___state____state__codechronos___pages___mutation_log____mutation_log_state)
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_bfb1e8bf43a1e0d670669e87d842fe81 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___pages___mutation_log____mutation_log_state.set_filter", ({ ["filter_type"] : "ai" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"purple",onClick:on_click_bfb1e8bf43a1e0d670669e87d842fe81,size:"2",variant:((reflex___state____state__codechronos___pages___mutation_log____mutation_log_state.filter_type_rx_state_ === "ai") ? "soft" : "outline")},
"AI"
,)
  )
}

function Button_155898868518712025749937116074261386962 () {
  
  const reflex___state____state__codechronos___pages___mutation_log____mutation_log_state = useContext(StateContexts.reflex___state____state__codechronos___pages___mutation_log____mutation_log_state)
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_cbf5fe5424916edb11ba0dd42c86b7c0 = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___pages___mutation_log____mutation_log_state.set_filter", ({ ["filter_type"] : "all" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{onClick:on_click_cbf5fe5424916edb11ba0dd42c86b7c0,size:"2",variant:((reflex___state____state__codechronos___pages___mutation_log____mutation_log_state.filter_type_rx_state_ === "all") ? "soft" : "outline")},
"All"
,)
  )
}

function Button_14191677064651564170888225119257461605 () {
  
  const reflex___state____state__codechronos___pages___mutation_log____mutation_log_state = useContext(StateContexts.reflex___state____state__codechronos___pages___mutation_log____mutation_log_state)
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_c0b9ac08df1cc84ed939768b9b8cf13c = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___pages___mutation_log____mutation_log_state.set_filter", ({ ["filter_type"] : "code" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"blue",onClick:on_click_c0b9ac08df1cc84ed939768b9b8cf13c,size:"2",variant:((reflex___state____state__codechronos___pages___mutation_log____mutation_log_state.filter_type_rx_state_ === "code") ? "soft" : "outline")},
"Code"
,)
  )
}

function Badge_96296694088842681397525897762256632573 () {
  
  const reflex___state____state__codechronos___pages___mutation_log____mutation_log_state = useContext(StateContexts.reflex___state____state__codechronos___pages___mutation_log____mutation_log_state)





  
  return (
    jsx(
RadixThemesBadge,
{},
(isTrue(reflex___state____state__codechronos___pages___mutation_log____mutation_log_state.selected_mutation_rx_state_["type"]) ? reflex___state____state__codechronos___pages___mutation_log____mutation_log_state.selected_mutation_rx_state_["type"] : "")
,)
  )
}

function Button_86250989819958233190918694416898963748 () {
  
  const reflex___state____state__codechronos___pages___mutation_log____mutation_log_state = useContext(StateContexts.reflex___state____state__codechronos___pages___mutation_log____mutation_log_state)
  const [addEvents, connectErrors] = useContext(EventLoopContext);


  const on_click_24261d5e6400071f72ccc89541eb35af = useCallback(((_e) => (addEvents([(Event("reflex___state____state.codechronos___pages___mutation_log____mutation_log_state.set_filter", ({ ["filter_type"] : "ui" }), ({  })))], [_e], ({  })))), [addEvents, Event])



  
  return (
    jsx(
RadixThemesButton,
{color:"green",onClick:on_click_24261d5e6400071f72ccc89541eb35af,size:"2",variant:((reflex___state____state__codechronos___pages___mutation_log____mutation_log_state.filter_type_rx_state_ === "ui") ? "soft" : "outline")},
"UI"
,)
  )
}

function Text_59360502119498355784681033771022243919 () {
  
  const reflex___state____state__codechronos___pages___mutation_log____mutation_log_state = useContext(StateContexts.reflex___state____state__codechronos___pages___mutation_log____mutation_log_state)





  
  return (
    jsx(
RadixThemesText,
{as:"p"},
(isTrue(reflex___state____state__codechronos___pages___mutation_log____mutation_log_state.selected_mutation_rx_state_["description"]) ? reflex___state____state__codechronos___pages___mutation_log____mutation_log_state.selected_mutation_rx_state_["description"] : "")
,)
  )
}

function Text_5618526565406935472665579208771150432 () {
  
  const reflex___state____state__codechronos___pages___mutation_log____mutation_log_state = useContext(StateContexts.reflex___state____state__codechronos___pages___mutation_log____mutation_log_state)





  
  return (
    jsx(
RadixThemesText,
{as:"p"},
(isTrue(reflex___state____state__codechronos___pages___mutation_log____mutation_log_state.selected_mutation_rx_state_["id"]) ? reflex___state____state__codechronos___pages___mutation_log____mutation_log_state.selected_mutation_rx_state_["id"] : "")
,)
  )
}

function Fragment_335019416985178973061204242629909126111 () {
  
  const reflex___state____state__codechronos___pages___mutation_log____mutation_log_state = useContext(StateContexts.reflex___state____state__codechronos___pages___mutation_log____mutation_log_state)





  
  return (
    jsx(
Fragment,
{},
(isTrue(reflex___state____state__codechronos___pages___mutation_log____mutation_log_state.selected_mutation_rx_state_) ? (jsx(
Fragment,
{},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["width"] : "100%" }),direction:"column",gap:"2"},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["width"] : "100%" }),direction:"row",gap:"3"},
jsx(
RadixThemesText,
{as:"p",css:({ ["fontWeight"] : "bold" })},
"ID:"
,),jsx(Text_5618526565406935472665579208771150432,{},)
,),jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["width"] : "100%" }),direction:"row",gap:"3"},
jsx(
RadixThemesText,
{as:"p",css:({ ["fontWeight"] : "bold" })},
"Type:"
,),jsx(Badge_96296694088842681397525897762256632573,{},)
,),jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["width"] : "100%" }),direction:"row",gap:"3"},
jsx(
RadixThemesText,
{as:"p",css:({ ["fontWeight"] : "bold" })},
"Description:"
,),jsx(Text_59360502119498355784681033771022243919,{},)
,),jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["width"] : "100%" }),direction:"row",gap:"3"},
jsx(
RadixThemesText,
{as:"p",css:({ ["fontWeight"] : "bold" })},
"Author:"
,),jsx(Text_251162995831631061070912909400736042324,{},)
,),jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["width"] : "100%" }),direction:"row",gap:"3"},
jsx(
RadixThemesText,
{as:"p",css:({ ["fontWeight"] : "bold" })},
"Changes:"
,),jsx(Text_204061181094170522034824275738100521372,{},)
,),jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["width"] : "100%" }),direction:"row",gap:"3"},
jsx(
RadixThemesText,
{as:"p",css:({ ["fontWeight"] : "bold" })},
"Era:"
,),jsx(Badge_64850405393027634878232118631668143541,{},)
,),jsx(Prismasynclight_248786333722726736456774775400487370352,{},)
,),)) : (jsx(
Fragment,
{},
jsx(
RadixThemesText,
{as:"p",css:({ ["color"] : "gray", ["textAlign"] : "center" })},
"Select a mutation to view details"
,),))),)
  )
}

function Text_251162995831631061070912909400736042324 () {
  
  const reflex___state____state__codechronos___pages___mutation_log____mutation_log_state = useContext(StateContexts.reflex___state____state__codechronos___pages___mutation_log____mutation_log_state)





  
  return (
    jsx(
RadixThemesText,
{as:"p"},
(isTrue(reflex___state____state__codechronos___pages___mutation_log____mutation_log_state.selected_mutation_rx_state_["author"]) ? reflex___state____state__codechronos___pages___mutation_log____mutation_log_state.selected_mutation_rx_state_["author"] : "")
,)
  )
}

function Box_24395468214585221276249589175092075172 () {
  
  const reflex___state____state__codechronos___pages___mutation_log____mutation_log_state = useContext(StateContexts.reflex___state____state__codechronos___pages___mutation_log____mutation_log_state)
  const [addEvents, connectErrors] = useContext(EventLoopContext);





  
  return (
    jsx(
RadixThemesBox,
{css:({ ["maxHeight"] : "500px", ["overflowY"] : "auto", ["width"] : "100%" })},
reflex___state____state__codechronos___pages___mutation_log____mutation_log_state.mutations_rx_state_.map((mutation_rx_state_,index_82bb6ae7038c7cfe)=>(jsx(
RadixThemesBox,
{css:({ ["&:hover"] : ({ ["background"] : "#f9fafb" }), ["padding"] : "1rem", ["border"] : "1px solid #e5e7eb", ["borderRadius"] : "8px", ["marginBottom"] : "0.5rem", ["cursor"] : "pointer" }),key:index_82bb6ae7038c7cfe},
jsx(
RadixThemesFlex,
{align:"center",className:"rx-Stack",css:({ ["width"] : "100%" }),direction:"row",gap:"3"},
jsx(
RadixThemesBox,
{css:({ ["width"] : "40px", ["display"] : "flex", ["alignItems"] : "center", ["justifyContent"] : "center" })},
jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "20px" })},
((mutation_rx_state_["type"] === "code") ? "\ud83d\udd27" : ((mutation_rx_state_["type"] === "ui") ? "\ud83c\udfa8" : "\ud83e\udd16"))
,),),jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["width"] : "100%" }),direction:"column",gap:"1"},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["width"] : "100%" }),direction:"row",gap:"3"},
jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "16px", ["fontWeight"] : "bold" })},
mutation_rx_state_["description"]
,),jsx(RadixThemesFlex,{css:({ ["flex"] : 1, ["justifySelf"] : "stretch", ["alignSelf"] : "stretch" })},)
,jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "12px", ["color"] : "gray" })},
mutation_rx_state_["changes"]
,),),jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"row",gap:"2"},
jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "12px", ["color"] : "gray" })},
("by "+mutation_rx_state_["author"])
,),jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "12px", ["color"] : "gray" })},
"\u2022"
,),jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "12px", ["color"] : "gray" })},
mutation_rx_state_["timestamp"].split("T").at(1).split("").slice(undefined, 5).join("")
,),jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "12px", ["color"] : "gray" })},
"\u2022"
,),jsx(
RadixThemesBadge,
{color:(mutation_rx_state_["era"].includes("vibe") ? "purple" : (mutation_rx_state_["era"].includes("block") ? "blue" : "gray"))},
mutation_rx_state_["era"]
,),),),jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"row",gap:"2"},
jsx(
RadixThemesButton,
{onClick:((_e) => (addEvents([(Event("reflex___state____state.codechronos___pages___mutation_log____mutation_log_state.select_mutation", ({ ["mutation"] : mutation_rx_state_ }), ({  })))], [_e], ({  })))),size:"1",variant:"outline"},
"View"
,),jsx(
RadixThemesButton,
{color:"red",onClick:((_e) => (addEvents([(Event("reflex___state____state.codechronos___pages___mutation_log____mutation_log_state.rollback_to_mutation", ({ ["mutation_id"] : mutation_rx_state_["id"] }), ({  })))], [_e], ({  })))),size:"1",variant:"outline"},
"Rollback"
,),),),))),)
  )
}

function Prismasynclight_248786333722726736456774775400487370352 () {
  
  const { resolvedColorMode } = useContext(ColorModeContext)





  
  return (
    jsx(SyntaxHighlighter,{children:"// Code diff would appear here\n+ function addNumbers(a, b) {\n+   return a + b;\n+ }",css:({ ["width"] : "100%" }),language:"javascript",style:((resolvedColorMode === "light") ? oneLight : oneDark)},)

  )
}

function Box_185373605331908030023490140022529721444 () {
  
  
                useEffect(() => {
                    ((...args) => (addEvents([(Event("reflex___state____state.codechronos___pages___mutation_log____mutation_log_state.load_mutations", ({  }), ({  })))], args, ({  }))))()
                    return () => {
                        
                    }
                }, []);
  const [addEvents, connectErrors] = useContext(EventLoopContext);





  
  return (
    jsx(
RadixThemesBox,
{css:({ ["width"] : "100vw", ["minHeight"] : "100vh", ["background"] : "#f9fafb" })},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["padding"] : "2rem", ["maxWidth"] : "1200px", ["margin"] : "0 auto" }),direction:"column",gap:"3"},
jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "32px", ["fontWeight"] : "bold", ["textAlign"] : "center", ["marginBottom"] : "2rem" })},
"Mutation Log"
,),jsx(
RadixThemesGrid,
{columns:"2",css:({ ["width"] : "100%" }),gap:"4"},
jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["width"] : "100%" }),direction:"column",gap:"3"},
jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "20px", ["fontWeight"] : "bold" })},
"Recent Changes"
,),jsx(
RadixThemesFlex,
{align:"center",className:"rx-Stack",direction:"row",gap:"3"},
jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "14px", ["color"] : "gray" })},
"Filter by:"
,),jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",direction:"row",gap:"2"},
jsx(Button_155898868518712025749937116074261386962,{},)
,jsx(Button_14191677064651564170888225119257461605,{},)
,jsx(Button_86250989819958233190918694416898963748,{},)
,jsx(Button_237060840900705721183161676407105698478,{},)
,),),jsx(Box_24395468214585221276249589175092075172,{},)
,),jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["width"] : "100%" }),direction:"column",gap:"3"},
jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "20px", ["fontWeight"] : "bold" })},
"Mutation Details"
,),jsx(Fragment_335019416985178973061204242629909126111,{},)
,),jsx(
RadixThemesFlex,
{align:"start",className:"rx-Stack",css:({ ["width"] : "100%" }),direction:"column",gap:"3"},
jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "20px", ["fontWeight"] : "bold" })},
"Statistics"
,),jsx(
RadixThemesGrid,
{columns:"2",gap:"2"},
jsx(
RadixThemesBox,
{css:({ ["textAlign"] : "center", ["padding"] : "1rem", ["border"] : "1px solid #e5e7eb", ["borderRadius"] : "8px" })},
jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "24px", ["fontWeight"] : "bold", ["color"] : "blue" })},
"12"
,),jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "12px", ["color"] : "gray" })},
"Total Changes"
,),),jsx(
RadixThemesBox,
{css:({ ["textAlign"] : "center", ["padding"] : "1rem", ["border"] : "1px solid #e5e7eb", ["borderRadius"] : "8px" })},
jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "24px", ["fontWeight"] : "bold", ["color"] : "green" })},
"3"
,),jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "12px", ["color"] : "gray" })},
"Code Changes"
,),),jsx(
RadixThemesBox,
{css:({ ["textAlign"] : "center", ["padding"] : "1rem", ["border"] : "1px solid #e5e7eb", ["borderRadius"] : "8px" })},
jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "24px", ["fontWeight"] : "bold", ["color"] : "purple" })},
"5"
,),jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "12px", ["color"] : "gray" })},
"AI Generated"
,),),jsx(
RadixThemesBox,
{css:({ ["textAlign"] : "center", ["padding"] : "1rem", ["border"] : "1px solid #e5e7eb", ["borderRadius"] : "8px" })},
jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "24px", ["fontWeight"] : "bold", ["color"] : "orange" })},
"4"
,),jsx(
RadixThemesText,
{as:"p",css:({ ["fontSize"] : "12px", ["color"] : "gray" })},
"UI Changes"
,),),),),),),)
  )
}

export default function Component() {
    




  return (
    jsx(
Fragment,
{},
jsx(Box_185373605331908030023490140022529721444,{},)
,jsx(
"title",
{},
"Codechronos | Logs"
,),jsx("meta",{content:"favicon.ico",property:"og:image"},)
,)
  )
}
