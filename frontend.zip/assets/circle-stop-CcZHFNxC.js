import{ao as o}from"./createLucideIcon-B8e-Mjz2.js";import"./chunk-EF7DTUVF-DLseTd5d.js";import"./grid-YQL9s_RY.js";import"./index-DFKkHzjq.js";/**
 * @license lucide-react v0.536.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const c=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["rect",{x:"9",y:"9",width:"6",height:"6",rx:"1",key:"1ssd4o"}]],p=o("circle-stop",c);export{c as __iconNode,p as default};
