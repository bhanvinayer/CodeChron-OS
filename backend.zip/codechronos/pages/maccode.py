"""
MacCode Page - 1984 Macintosh development environment
"""

import reflex as rx
from typing import List, Dict, Any
from ..components.base_window import base_window, WindowState
from ..components.calculator import calculator_component
from ..components.notepad import notepad_component
from ..components.mac_draw import mac_draw
from ..components.breakout import breakout_component
from ..components.interface_builder import interface_builder

class MacCodeState(rx.State):
    # Menu dropdown state
    open_menu: str = ""

    def open_menu_dropdown(self, menu: str):
        self.open_menu = menu

    def close_menu_dropdown(self):
        self.open_menu = ""
    """State for Mac 1984 interface"""
    current_time: str = "12:00 PM"
    
    # Window states with positions
    calculator_active: bool = False
    calculator_x: int = 150
    calculator_y: int = 80
    
    notepad_active: bool = False
    notepad_x: int = 200
    notepad_y: int = 120
    
    draw_active: bool = False
    draw_x: int = 250
    draw_y: int = 160
    
    breakout_active: bool = False
    breakout_x: int = 300
    breakout_y: int = 200
    
    interface_builder_active: bool = False
    interface_builder_x: int = 200
    interface_builder_y: int = 60
    
    # Desktop state
    selected_icon: str = ""
    
    def open_calculator(self):
        """Open Calculator"""
        print("Opening calculator")  # Debug print
        self.calculator_active = True
        self.selected_icon = "calculator"
    
    def open_notepad(self):
        """Open Notepad"""
        print("Opening notepad")  # Debug print
        self.notepad_active = True
        self.selected_icon = "notepad"
    
    def open_macdraw(self):
        """Open MacDraw"""
        print("Opening macdraw")  # Debug print
        self.draw_active = True
        self.selected_icon = "macdraw"
    
    def open_breakout(self):
        """Open Breakout"""
        print("Opening breakout")  # Debug print
        self.breakout_active = True
        self.selected_icon = "breakout"
    
    def open_interface_builder(self):
        """Open Interface Builder"""
        print("Opening Interface Builder")  # Debug print
        self.interface_builder_active = True
        self.selected_icon = "interface_builder"
    
    def close_calculator(self):
        """Close Calculator"""
        self.calculator_active = False
    
    def close_notepad(self):
        """Close Notepad"""
        self.notepad_active = False
    
    def close_macdraw(self):
        """Close MacDraw"""
        self.draw_active = False
    
    def close_breakout(self):
        """Close Breakout"""
        self.breakout_active = False
    
    def close_interface_builder(self):
        """Close Interface Builder"""
        self.interface_builder_active = False
    
    def clear_selection(self):
        """Clear icon selection"""
        self.selected_icon = ""

def mac_window_title_bar(title: str, on_close) -> rx.Component:
    """Create an authentic Mac-style title bar"""
    return rx.hstack(
        # Left side - close button
        rx.box(
            rx.box(
                width="12px",
                height="12px",
                border_radius="50%",
                bg="white",
                border="1px solid #000",
                cursor="pointer",
                on_click=on_close,
                style={
                    "&:hover": {
                        "background": "#ff0000"
                    }
                }
            ),
            padding="4px"
        ),
        
        # Center - title
        rx.center(
            rx.text(
                title,
                font_size="12px",
                font_family="'Press Start 2P', monospace",
                color="black",
                font_weight="bold"
            ),
            flex="1"
        ),
        
        # Right side - spacer for symmetry
        rx.box(width="20px"),
        
        width="100%",
        height="20px",
        bg="white",
        border_bottom="2px solid black",
        align="center",
        cursor="move"
    )

def mac_window(
    title: str,
    children: rx.Component,
    x: int,
    y: int,
    width: str = "300px",
    height: str = "250px",
    on_close=None
) -> rx.Component:
    """Create an authentic Mac-style window"""
    return rx.box(
        rx.vstack(
            mac_window_title_bar(title, on_close),
            rx.box(
                children,
                bg="white",
                padding="8px",
                flex="1",
                overflow="auto",
                border_left="2px solid black",
                border_right="2px solid black",
                border_bottom="2px solid black"
            ),
            spacing="0"
        ),
        position="absolute",
        left=f"{x}px",
        top=f"{y}px",
        width=width,
        height=height,
        bg="white",
        border="2px solid black",
        box_shadow="4px 4px 0px rgba(0,0,0,0.5)",
        z_index="100",
        font_family="'Press Start 2P', monospace"
    )

def mac_menu_bar() -> rx.Component:
    """Classic Mac menu bar"""
    def dropdown(menu, options):
        return rx.cond(
            MacCodeState.open_menu == menu,
            rx.box(
                # Overlay to capture outside clicks
                rx.box(
                    on_click=MacCodeState.close_menu_dropdown,
                    position="fixed",
                    top="0",
                    left="0",
                    width="100vw",
                    height="100vh",
                    z_index="9998",
                    bg="rgba(0,0,0,0)",
                ),
                rx.box(
                    rx.vstack(
                        *[rx.text(opt, font_size="12px", padding="6px 18px", color="#222", bg="#f4f4f4", cursor="pointer", _hover={"bg": "#e0e0e0"}) for opt in options],
                        spacing="0",
                        align="start"
                    ),
                    position="absolute",
                    top="28px",
                    left="0" if menu == "File" else ("60px" if menu == "Edit" else ("120px" if menu == "View" else "180px")),
                    min_width="100px",
                    border="1.5px solid #222",
                    border_radius="6px",
                    box_shadow="0 2px 12px rgba(0,0,0,0.08)",
                    z_index="9999",
                    bg="#f4f4f4"
                )
            ),
            rx.box()
        )

    return rx.box(
        rx.hstack(
            rx.box(
                rx.image(
                    src="/images/apple.png",
                    width="16px",
                    height="16px",
                    alt="Apple"
                ),
                
                color="white",
                padding="2px 6px",
                cursor="pointer"
            ),
            rx.box(
                rx.text("File", font_size="12px", font_family="'Press Start 2P', monospace", cursor="pointer", padding="2px 8px", color="#222", font_weight="bold",
                        on_click=lambda: MacCodeState.open_menu_dropdown("File")),
                position="relative"
            ),
            rx.box(
                rx.text("Edit", font_size="12px", font_family="'Press Start 2P', monospace", cursor="pointer", padding="2px 8px", color="#222", font_weight="bold", 
                        on_click=lambda: MacCodeState.open_menu_dropdown("Edit")),
                position="relative"
            ),
            rx.box(
                rx.text("View", font_size="12px", font_family="'Press Start 2P', monospace", cursor="pointer", padding="2px 8px", color="#222", font_weight="bold", 
                        on_click=lambda: MacCodeState.open_menu_dropdown("View")),
                position="relative"
            ),
            rx.box(
                rx.text("Tools", font_size="12px", font_family="'Press Start 2P', monospace", cursor="pointer", padding="2px 8px", color="#222", font_weight="bold", 
                        on_click=lambda: MacCodeState.open_menu_dropdown("Tools")),
                position="relative"
            ),
            spacing="2",
            position="relative"
        ),
        dropdown("File", ["New", "Open", "Save", "Close"]),
        dropdown("Edit", ["Undo", "Redo", "Cut", "Copy", "Paste"]),
        dropdown("View", ["Zoom In", "Zoom Out", "Actual Size"]),
        dropdown("Tools", ["Settings", "Customize Toolbar"]),
        rx.spacer(),
        # Time display
        rx.text(
            MacCodeState.current_time,
            font_size="12px",
            font_family="'Press Start 2P', monospace"
        ),
        width="100%",
        padding="4px 8px",
        bg="white",
        border_bottom="2px solid black",
        align="center",
        # Remove on_click here, overlay now handles closing
        style={"user-select": "none"}
    )
    # (removed duplicate block)

def application_windows() -> rx.Component:
    """Render all open application windows"""
    return rx.box(
        # Calculator window
        rx.cond(
            MacCodeState.calculator_active,
            mac_window(
                "Calculator",
                calculator_component(),
                MacCodeState.calculator_x,
                MacCodeState.calculator_y,
                width="400px",
                height="620px",
                on_close=MacCodeState.close_calculator
            ),
            rx.box()
        ),
        
        # Notepad window
        rx.cond(
            MacCodeState.notepad_active,
            mac_window(
                "Notepad",
                rx.box(
                    notepad_component(),
                    width="500px",
                    height="320px",
                    min_height="320px",
                    bg="white",
                    color="#111",
                    font_size="15px",
                    font_family="'Press Start 2P', monospace",
                    style={"overflow": "auto"}
                ),
                MacCodeState.notepad_x,
                MacCodeState.notepad_y,
                width="520px",
                height="350px",
                on_close=MacCodeState.close_notepad
            ),
            rx.box()
        ),
        
        # Interface Builder window (now called MacCode)
        rx.cond(
            MacCodeState.interface_builder_active,
            mac_window(
                "MacCode",
                interface_builder(),
                MacCodeState.interface_builder_x,
                MacCodeState.interface_builder_y,
                width="900px",
                height="900px",
                on_close=MacCodeState.close_interface_builder
            ),
            rx.box()
        ),

        # MacDraw window
        rx.cond(
            MacCodeState.draw_active,
            mac_window(
                "MacDraw",
                mac_draw(),
                MacCodeState.draw_x,
                MacCodeState.draw_y,
                width="830px",
                height="500px",
                on_close=MacCodeState.close_macdraw
            ),
            rx.box()
        ),
        rx.cond(
            MacCodeState.breakout_active,
            mac_window(
                "Breakout",
                breakout_component(),
                MacCodeState.breakout_x,
                MacCodeState.breakout_y,
                width="430px",
                height="450px",
                on_close=MacCodeState.close_breakout
            ),
            rx.box()
        ),
        
        # Interface Builder window
        rx.cond(
            MacCodeState.interface_builder_active,
            mac_window(
                "Interface Builder",
                interface_builder(),
                MacCodeState.interface_builder_x,
                MacCodeState.interface_builder_y,
                width="900px",
                height="900px",
                on_close=MacCodeState.close_interface_builder
            ),
            rx.box()
        ),
        
        position="relative",
        width="100%",
        height="100%",
        z_index="50"
    )

def mac_desktop() -> rx.Component:
    """Mac desktop with icons and windows"""
    return rx.box(
        # Desktop icons as simple buttons (like the working test button)
        # Calculator icon
        rx.button(
            rx.vstack(
                rx.image(
                    src="/images/calculator_icon.png",
                    width="40px",
                    height="40px",
                    alt="Calculator"
                ),
                rx.text(
                    "Calculator",
                    font_size="12px",
                    font_family="'Press Start 2P', monospace",
                    color="black",
                    text_align="center"
                ),
                spacing="2",
                align="center"
            ),
            on_click=MacCodeState.open_calculator,
            position="absolute",
            left="20px",
            top="60px",
            width="100px",
            height="80px",
            bg="#e0e0e0",
            border="1px solid black",
            cursor="pointer",
            z_index="100",
            style={
                "&:hover": {"background": "rgba(0,0,0,0.1)"}
            }
        ),
        
        # Notepad icon
        rx.button(
            rx.vstack(
                rx.image(
                    src="/images/notepad_icon.png",
                    width="40px",
                    height="40px",
                    alt="Notepad"
                ),
                rx.text(
                    "Notepad",
                    font_size="12px",
                    font_family="'Press Start 2P', monospace",
                    color="black",
                    text_align="center"
                ),
                spacing="2",
                align="center"
            ),
            on_click=MacCodeState.open_notepad,
            position="absolute",
            left="20px",
            top="160px",
            width="100px",
            height="80px",
            bg="#e0e0e0",
            border="1px solid black",
            cursor="pointer",
            z_index="100",
            style={
                "&:hover": {"background": "rgba(0,0,0,0.1)"}
            }
        ),
        
        # MacCode (Interface Builder) icon
        rx.button(
            rx.vstack(
                rx.image(
                    src="/images/maccode_icon.png",
                    width="40px",
                    height="40px",
                    alt="MacCode"
                ),
                rx.text(
                    "MacCode",
                    font_size="12px",
                    font_family="'Press Start 2P', monospace",
                    color="black",
                    text_align="center"
                ),
                spacing="2",
                align="center"
            ),
            on_click=MacCodeState.open_interface_builder,
            position="absolute",
            left="20px",
            top="260px",
            width="100px",
            height="80px",
            bg="#e0e0e0",
            border="1px solid black",
            cursor="pointer",
            z_index="100",
            style={
                "&:hover": {"background": "rgba(0,0,0,0.1)"}
            }
        ),

        # MacDraw icon
        rx.button(
            rx.vstack(
                rx.image(
                    src="/images/macdraw_icon.png",
                    width="40px",
                    height="40px",
                    alt="MacDraw"
                ),
                rx.text(
                    "MacDraw",
                    font_size="12px",
                    font_family="'Press Start 2P', monospace",
                    color="black",
                    text_align="center"
                ),
                spacing="2",
                align="center"
            ),
            on_click=MacCodeState.open_macdraw,
            position="absolute",
            left="20px",
            top="460px",
            width="100px",
            height="80px",
            bg="#e0e0e0",
            border="1px solid black",
            cursor="pointer",
            z_index="100",
            style={
                "&:hover": {"background": "rgba(0,0,0,0.1)"}
            }
        ),
        rx.button(
            rx.vstack(
                rx.image(
                    src="/images/breakout_icon.png",
                    width="40px",
                    height="40px",
                    alt="Breakout"
                ),
                rx.text(
                    "Breakout",
                    font_size="12px",
                    font_family="'Press Start 2P', monospace",
                    color="black",
                    text_align="center"
                ),
                spacing="2",
                align="center"
            ),
            on_click=MacCodeState.open_breakout,
            position="absolute",
            left="20px",
            top="360px",
            width="100px",
            height="80px",
            bg="#e0e0e0",
            border="1px solid black",
            cursor="pointer",
            z_index="100",
            style={
                "&:hover": {"background": "rgba(0,0,0,0.1)"}
            }
        ),
        

        
        # Application windows
        application_windows(),
        
        position="relative",
        width="100%",
        height="calc(100vh - 30px)",
        bg="white",  # White background for better visibility
        overflow="hidden"
    )

def maccode_page() -> rx.Component:
    """Complete Mac 1984 interface - like the demo site"""
    return rx.box(
        mac_menu_bar(),
        mac_desktop(),
        width="100vw",
        height="100vh",
        bg="white",  # White background
        font_family="'Press Start 2P', monospace",
        style={
            "image_rendering": "pixelated",
            "cursor": "crosshair",
            "user_select": "none"
        }
    )