# CodeChronOS main module
from .codechronos import app

__all__ = ["app"]
