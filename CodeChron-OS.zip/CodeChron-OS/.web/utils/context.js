import { createContext, useContext, useMemo, useReducer, useState, createElement, useEffect } from "react"
import { applyDelta, Event, hydrateClientStorage, useEventLoop, refs } from "$/utils/state"
import { jsx } from "@emotion/react";

export const initialState = {"reflex___state____state": {"is_hydrated_rx_state_": false, "router_rx_state_": {"session": {"client_token": "", "client_ip": "", "session_id": ""}, "headers": {"host": "", "origin": "", "upgrade": "", "connection": "", "cookie": "", "pragma": "", "cache_control": "", "user_agent": "", "sec_websocket_version": "", "sec_websocket_key": "", "sec_websocket_extensions": "", "accept_encoding": "", "accept_language": "", "raw_headers": {}}, "page": {"host": "", "path": "", "raw_path": "", "full_path": "", "full_raw_path": "", "params": {}}, "url": "", "route_id": ""}}, "reflex___state____state.codechronos___codechronos____state": {"audio_enabled_rx_state_": true, "boot_complete_rx_state_": false, "current_era_rx_state_": "1984", "theme_mode_rx_state_": "mac1984"}, "reflex___state____state.codechronos___components___base_window____window_state": {"breakout_active_rx_state_": false, "calculator_active_rx_state_": false, "draw_active_rx_state_": false, "notepad_active_rx_state_": false, "windows_rx_state_": {}}, "reflex___state____state.codechronos___components___block_editor____block_editor_state": {"blocks_rx_state_": [], "canvas_blocks_rx_state_": [], "edit_parameter_rx_state_": "", "edit_value_rx_state_": "", "editing_block_id_rx_state_": -1, "generated_code_rx_state_": "", "selected_block_type_rx_state_": "print"}, "reflex___state____state.codechronos___components___breakout____breakout_state": {"auto_play_rx_state_": false, "ball_dx_rx_state_": 3, "ball_dy_rx_state_": -3, "ball_x_rx_state_": 150, "ball_y_rx_state_": 200, "bricks_rx_state_": [[true, true, true, true, true, true, true, true], [true, true, true, true, true, true, true, true], [true, true, true, true, true, true, true, true], [true, true, true, true, true, true, true, true], [true, true, true, true, true, true, true, true]], "bricks_left_rx_state_": 40, "game_over_rx_state_": false, "game_started_rx_state_": false, "lives_rx_state_": 3, "paddle_width_rx_state_": 80, "paddle_x_rx_state_": 110, "scaled_ball_x_rx_state_": 135, "scaled_ball_y_rx_state_": 160, "scaled_paddle_width_rx_state_": 72, "scaled_paddle_x_rx_state_": 99, "score_rx_state_": 0}, "reflex___state____state.codechronos___components___calculator____calculator_state": {"display_rx_state_": "0", "operation_rx_state_": "", "previous_value_rx_state_": 0, "waiting_for_operand_rx_state_": false}, "reflex___state____state.codechronos___components___mac_draw____mac_draw_state": {"brush_size_rx_state_": 2, "canvas_data_rx_state_": "", "current_color_rx_state_": "#000000", "current_path_rx_state_": [], "current_tool_rx_state_": "pencil", "drawing_paths_rx_state_": [], "is_drawing_rx_state_": false}, "reflex___state____state.codechronos___components___notepad____notepad_state": {"content_rx_state_": "Welcome to MacPad!\n\nType your text here...", "filename_rx_state_": "Untitled", "font_size_rx_state_": 12, "is_modified_rx_state_": false}, "reflex___state____state.codechronos___components___vibe_prompt____vibe_prompt_state": {"chat_history_rx_state_": [], "creativity_level_rx_state_": 0.7, "dark_mode_rx_state_": false, "error_message_rx_state_": "", "generated_code_rx_state_": "", "is_generating_rx_state_": false, "openai_api_key_rx_state_": "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", "prompt_rx_state_": ""}, "reflex___state____state.codechronos___pages___blockcode____block_code_state": {"current_project_rx_state_": "My Awesome App", "saved_projects_rx_state_": ["Calculator", "Todo List", "Drawing App"], "show_tutorial_rx_state_": true}, "reflex___state____state.codechronos___pages___home____home_state": {"boot_complete_rx_state_": false, "boot_stage_rx_state_": 0, "boot_text_rx_state_": "CodeChronOS Loading...", "progress_rx_state_": 0, "show_logo_rx_state_": false}, "reflex___state____state.codechronos___pages___maccode____mac_code_state": {"breakout_active_rx_state_": false, "breakout_x_rx_state_": 300, "breakout_y_rx_state_": 200, "calculator_active_rx_state_": false, "calculator_x_rx_state_": 150, "calculator_y_rx_state_": 80, "current_time_rx_state_": "12:00 PM", "draw_active_rx_state_": false, "draw_x_rx_state_": 250, "draw_y_rx_state_": 160, "notepad_active_rx_state_": false, "notepad_x_rx_state_": 200, "notepad_y_rx_state_": 120, "selected_icon_rx_state_": ""}, "reflex___state____state.codechronos___pages___mutation_log____mutation_log_state": {"filter_type_rx_state_": "all", "mutations_rx_state_": [], "selected_mutation_rx_state_": {}}, "reflex___state____state.codechronos___pages___vibecode____vibe_code_state": {"ai_mode_rx_state_": "creative", "session_apps_rx_state_": [], "show_welcome_rx_state_": true}, "reflex___state____state.reflex___state____frontend_event_exception_state": {}, "reflex___state____state.reflex___state____on_load_internal_state": {}, "reflex___state____state.reflex___state____update_vars_internal_state": {}}

export const defaultColorMode = "light"
export const ColorModeContext = createContext(null);
export const UploadFilesContext = createContext(null);
export const DispatchContext = createContext(null);
export const StateContexts = {
  reflex___state____state: createContext(null),
  reflex___state____state__codechronos___codechronos____state: createContext(null),
  reflex___state____state__codechronos___components___base_window____window_state: createContext(null),
  reflex___state____state__codechronos___components___block_editor____block_editor_state: createContext(null),
  reflex___state____state__codechronos___components___breakout____breakout_state: createContext(null),
  reflex___state____state__codechronos___components___calculator____calculator_state: createContext(null),
  reflex___state____state__codechronos___components___mac_draw____mac_draw_state: createContext(null),
  reflex___state____state__codechronos___components___notepad____notepad_state: createContext(null),
  reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state: createContext(null),
  reflex___state____state__codechronos___pages___blockcode____block_code_state: createContext(null),
  reflex___state____state__codechronos___pages___home____home_state: createContext(null),
  reflex___state____state__codechronos___pages___maccode____mac_code_state: createContext(null),
  reflex___state____state__codechronos___pages___mutation_log____mutation_log_state: createContext(null),
  reflex___state____state__codechronos___pages___vibecode____vibe_code_state: createContext(null),
  reflex___state____state__reflex___state____frontend_event_exception_state: createContext(null),
  reflex___state____state__reflex___state____on_load_internal_state: createContext(null),
  reflex___state____state__reflex___state____update_vars_internal_state: createContext(null),
}
export const EventLoopContext = createContext(null);
export const clientStorage = {"cookies": {}, "local_storage": {}, "session_storage": {}}

export const state_name = "reflex___state____state"

export const exception_state_name = "reflex___state____state.reflex___state____frontend_event_exception_state"

// These events are triggered on initial load and each page navigation.
export const onLoadInternalEvent = () => {
    const internal_events = [];

    // Get tracked cookie and local storage vars to send to the backend.
    const client_storage_vars = hydrateClientStorage(clientStorage);
    // But only send the vars if any are actually set in the browser.
    if (client_storage_vars && Object.keys(client_storage_vars).length !== 0) {
        internal_events.push(
            Event(
                'reflex___state____state.reflex___state____update_vars_internal_state.update_vars_internal',
                {vars: client_storage_vars},
            ),
        );
    }

    // `on_load_internal` triggers the correct on_load event(s) for the current page.
    // If the page does not define any on_load event, this will just set `is_hydrated = true`.
    internal_events.push(Event('reflex___state____state.reflex___state____on_load_internal_state.on_load_internal'));

    return internal_events;
}

// The following events are sent when the websocket connects or reconnects.
export const initialEvents = () => [
    Event('reflex___state____state.hydrate'),
    ...onLoadInternalEvent()
]

export const isDevMode = true

export function UploadFilesProvider({ children }) {
  const [filesById, setFilesById] = useState({})
  refs["__clear_selected_files"] = (id) => setFilesById(filesById => {
    const newFilesById = {...filesById}
    delete newFilesById[id]
    return newFilesById
  })
  return createElement(
    UploadFilesContext.Provider,
    { value: [filesById, setFilesById] },
    children
  );
}

export function ClientSide(component) {
  return ({ children, ...props }) => {
    const [Component, setComponent] = useState(null);
    useEffect(() => {
      setComponent(component);
    }, []);
    return Component ? jsx(Component, props, children) : null;
  };
}

export function EventLoopProvider({ children }) {
  const dispatch = useContext(DispatchContext)
  const [addEvents, connectErrors] = useEventLoop(
    dispatch,
    initialEvents,
    clientStorage,
  )
  return createElement(
    EventLoopContext.Provider,
    { value: [addEvents, connectErrors] },
    children
  );
}

export function StateProvider({ children }) {
  const [reflex___state____state, dispatch_reflex___state____state] = useReducer(applyDelta, initialState["reflex___state____state"])
  const [reflex___state____state__codechronos___codechronos____state, dispatch_reflex___state____state__codechronos___codechronos____state] = useReducer(applyDelta, initialState["reflex___state____state.codechronos___codechronos____state"])
  const [reflex___state____state__codechronos___components___base_window____window_state, dispatch_reflex___state____state__codechronos___components___base_window____window_state] = useReducer(applyDelta, initialState["reflex___state____state.codechronos___components___base_window____window_state"])
  const [reflex___state____state__codechronos___components___block_editor____block_editor_state, dispatch_reflex___state____state__codechronos___components___block_editor____block_editor_state] = useReducer(applyDelta, initialState["reflex___state____state.codechronos___components___block_editor____block_editor_state"])
  const [reflex___state____state__codechronos___components___breakout____breakout_state, dispatch_reflex___state____state__codechronos___components___breakout____breakout_state] = useReducer(applyDelta, initialState["reflex___state____state.codechronos___components___breakout____breakout_state"])
  const [reflex___state____state__codechronos___components___calculator____calculator_state, dispatch_reflex___state____state__codechronos___components___calculator____calculator_state] = useReducer(applyDelta, initialState["reflex___state____state.codechronos___components___calculator____calculator_state"])
  const [reflex___state____state__codechronos___components___mac_draw____mac_draw_state, dispatch_reflex___state____state__codechronos___components___mac_draw____mac_draw_state] = useReducer(applyDelta, initialState["reflex___state____state.codechronos___components___mac_draw____mac_draw_state"])
  const [reflex___state____state__codechronos___components___notepad____notepad_state, dispatch_reflex___state____state__codechronos___components___notepad____notepad_state] = useReducer(applyDelta, initialState["reflex___state____state.codechronos___components___notepad____notepad_state"])
  const [reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state, dispatch_reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state] = useReducer(applyDelta, initialState["reflex___state____state.codechronos___components___vibe_prompt____vibe_prompt_state"])
  const [reflex___state____state__codechronos___pages___blockcode____block_code_state, dispatch_reflex___state____state__codechronos___pages___blockcode____block_code_state] = useReducer(applyDelta, initialState["reflex___state____state.codechronos___pages___blockcode____block_code_state"])
  const [reflex___state____state__codechronos___pages___home____home_state, dispatch_reflex___state____state__codechronos___pages___home____home_state] = useReducer(applyDelta, initialState["reflex___state____state.codechronos___pages___home____home_state"])
  const [reflex___state____state__codechronos___pages___maccode____mac_code_state, dispatch_reflex___state____state__codechronos___pages___maccode____mac_code_state] = useReducer(applyDelta, initialState["reflex___state____state.codechronos___pages___maccode____mac_code_state"])
  const [reflex___state____state__codechronos___pages___mutation_log____mutation_log_state, dispatch_reflex___state____state__codechronos___pages___mutation_log____mutation_log_state] = useReducer(applyDelta, initialState["reflex___state____state.codechronos___pages___mutation_log____mutation_log_state"])
  const [reflex___state____state__codechronos___pages___vibecode____vibe_code_state, dispatch_reflex___state____state__codechronos___pages___vibecode____vibe_code_state] = useReducer(applyDelta, initialState["reflex___state____state.codechronos___pages___vibecode____vibe_code_state"])
  const [reflex___state____state__reflex___state____frontend_event_exception_state, dispatch_reflex___state____state__reflex___state____frontend_event_exception_state] = useReducer(applyDelta, initialState["reflex___state____state.reflex___state____frontend_event_exception_state"])
  const [reflex___state____state__reflex___state____on_load_internal_state, dispatch_reflex___state____state__reflex___state____on_load_internal_state] = useReducer(applyDelta, initialState["reflex___state____state.reflex___state____on_load_internal_state"])
  const [reflex___state____state__reflex___state____update_vars_internal_state, dispatch_reflex___state____state__reflex___state____update_vars_internal_state] = useReducer(applyDelta, initialState["reflex___state____state.reflex___state____update_vars_internal_state"])
  const dispatchers = useMemo(() => {
    return {
      "reflex___state____state": dispatch_reflex___state____state,
      "reflex___state____state.codechronos___codechronos____state": dispatch_reflex___state____state__codechronos___codechronos____state,
      "reflex___state____state.codechronos___components___base_window____window_state": dispatch_reflex___state____state__codechronos___components___base_window____window_state,
      "reflex___state____state.codechronos___components___block_editor____block_editor_state": dispatch_reflex___state____state__codechronos___components___block_editor____block_editor_state,
      "reflex___state____state.codechronos___components___breakout____breakout_state": dispatch_reflex___state____state__codechronos___components___breakout____breakout_state,
      "reflex___state____state.codechronos___components___calculator____calculator_state": dispatch_reflex___state____state__codechronos___components___calculator____calculator_state,
      "reflex___state____state.codechronos___components___mac_draw____mac_draw_state": dispatch_reflex___state____state__codechronos___components___mac_draw____mac_draw_state,
      "reflex___state____state.codechronos___components___notepad____notepad_state": dispatch_reflex___state____state__codechronos___components___notepad____notepad_state,
      "reflex___state____state.codechronos___components___vibe_prompt____vibe_prompt_state": dispatch_reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state,
      "reflex___state____state.codechronos___pages___blockcode____block_code_state": dispatch_reflex___state____state__codechronos___pages___blockcode____block_code_state,
      "reflex___state____state.codechronos___pages___home____home_state": dispatch_reflex___state____state__codechronos___pages___home____home_state,
      "reflex___state____state.codechronos___pages___maccode____mac_code_state": dispatch_reflex___state____state__codechronos___pages___maccode____mac_code_state,
      "reflex___state____state.codechronos___pages___mutation_log____mutation_log_state": dispatch_reflex___state____state__codechronos___pages___mutation_log____mutation_log_state,
      "reflex___state____state.codechronos___pages___vibecode____vibe_code_state": dispatch_reflex___state____state__codechronos___pages___vibecode____vibe_code_state,
      "reflex___state____state.reflex___state____frontend_event_exception_state": dispatch_reflex___state____state__reflex___state____frontend_event_exception_state,
      "reflex___state____state.reflex___state____on_load_internal_state": dispatch_reflex___state____state__reflex___state____on_load_internal_state,
      "reflex___state____state.reflex___state____update_vars_internal_state": dispatch_reflex___state____state__reflex___state____update_vars_internal_state,
    }
  }, [])

  return (
    createElement(StateContexts.reflex___state____state,{value: reflex___state____state},
    createElement(StateContexts.reflex___state____state__codechronos___codechronos____state,{value: reflex___state____state__codechronos___codechronos____state},
    createElement(StateContexts.reflex___state____state__codechronos___components___base_window____window_state,{value: reflex___state____state__codechronos___components___base_window____window_state},
    createElement(StateContexts.reflex___state____state__codechronos___components___block_editor____block_editor_state,{value: reflex___state____state__codechronos___components___block_editor____block_editor_state},
    createElement(StateContexts.reflex___state____state__codechronos___components___breakout____breakout_state,{value: reflex___state____state__codechronos___components___breakout____breakout_state},
    createElement(StateContexts.reflex___state____state__codechronos___components___calculator____calculator_state,{value: reflex___state____state__codechronos___components___calculator____calculator_state},
    createElement(StateContexts.reflex___state____state__codechronos___components___mac_draw____mac_draw_state,{value: reflex___state____state__codechronos___components___mac_draw____mac_draw_state},
    createElement(StateContexts.reflex___state____state__codechronos___components___notepad____notepad_state,{value: reflex___state____state__codechronos___components___notepad____notepad_state},
    createElement(StateContexts.reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state,{value: reflex___state____state__codechronos___components___vibe_prompt____vibe_prompt_state},
    createElement(StateContexts.reflex___state____state__codechronos___pages___blockcode____block_code_state,{value: reflex___state____state__codechronos___pages___blockcode____block_code_state},
    createElement(StateContexts.reflex___state____state__codechronos___pages___home____home_state,{value: reflex___state____state__codechronos___pages___home____home_state},
    createElement(StateContexts.reflex___state____state__codechronos___pages___maccode____mac_code_state,{value: reflex___state____state__codechronos___pages___maccode____mac_code_state},
    createElement(StateContexts.reflex___state____state__codechronos___pages___mutation_log____mutation_log_state,{value: reflex___state____state__codechronos___pages___mutation_log____mutation_log_state},
    createElement(StateContexts.reflex___state____state__codechronos___pages___vibecode____vibe_code_state,{value: reflex___state____state__codechronos___pages___vibecode____vibe_code_state},
    createElement(StateContexts.reflex___state____state__reflex___state____frontend_event_exception_state,{value: reflex___state____state__reflex___state____frontend_event_exception_state},
    createElement(StateContexts.reflex___state____state__reflex___state____on_load_internal_state,{value: reflex___state____state__reflex___state____on_load_internal_state},
    createElement(StateContexts.reflex___state____state__reflex___state____update_vars_internal_state,{value: reflex___state____state__reflex___state____update_vars_internal_state},
    createElement(DispatchContext, {value: dispatchers}, children)
)))))))))))))))))  )
}